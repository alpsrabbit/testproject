package com.projectK.user.service.impl;

import com.projectK.framework.dao.CommDAO;
import com.projectK.framework.util.DataMap;
import com.projectK.user.service.CustCenterService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;


@Service("custCenterService")
public class CustCenterServiceImpl implements CustCenterService {

    private static final Logger logger = LoggerFactory.getLogger(CustCenterService.class);
    @Resource(name="commDAO")
    private CommDAO commDAO;

    /**
     * 공지사항 조회
     * @param params
     * @return
     * @throws Exception
     */
    @Transactional
    @Override
    public List<DataMap> noticeList(DataMap params) throws Exception {
        int intResult = commDAO.insert("user.asset.selectOuterAddr", params);

        params.put("boardId", "0000400001");        // 공지사항
        params.put("boardStatus", "000050002");     // 개시중

        List<DataMap> resultList = commDAO.selectList("common.selectBoardList", params);

        return resultList;
    }
}
