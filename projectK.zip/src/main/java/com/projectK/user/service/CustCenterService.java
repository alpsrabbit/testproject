package com.projectK.user.service;

import com.projectK.framework.util.DataMap;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface CustCenterService {

    /**
     * 공지사항 조회
     * @param params
     * @return
     * @throws Exception
     */
    @Transactional
    public List<DataMap> noticeList(DataMap params) throws Exception;
}
