package com.projectK.user.web;

import com.projectK.framework.annotation.ReqParam;
import com.projectK.framework.constant.Constants;
import com.projectK.framework.util.DataMap;
import com.projectK.user.service.CustCenterService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Locale;

@Controller
public class CustCenterController {
    private static final Logger logger = LoggerFactory.getLogger(CustCenterController.class);

    @Resource(name="custCenterService")
    private CustCenterService custCenterService;

    @RequestMapping(value="/user/cust/noticeList.do")
    public String noticeList(Locale locale, HttpServletRequest request, HttpServletResponse response, ModelMap model, @ReqParam DataMap params ) throws Exception {
        if(Constants.detailLog)logger.info("CustCenterController.noticeList] Request Params >>>> [{}]", params);
        List<DataMap> noticeList = custCenterService.noticeList(params);

        model.addAttribute("noticeList", noticeList);

        return "user/custCenter/notice";
    }
}
