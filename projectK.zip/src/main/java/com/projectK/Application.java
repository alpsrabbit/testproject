package com.projectK;

import com.projectK.framework.config.PropertyLoader;
import com.projectK.framework.constant.Constants;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import java.util.Properties;

@ServletComponentScan
@SpringBootApplication
@Configuration
@PropertySource(value = { "classpath:config/server.properties" })
public class Application {

	public static void main(String[] args) {
		for (String arg : args) {
			System.out.println(arg);
		}

		Properties props = PropertyLoader.getProperties();

		String strDetailLog = props.getProperty("detailLog");
		String strServerMode = props.getProperty(Constants.SERVER_MODE);
		String strDbMode = props.getProperty("db.mode");

		if (strDetailLog != null && "Y".equals(strDetailLog)) {
			Constants.detailLog = true;
		} else {
			Constants.detailLog = false;
		}

		if ( strServerMode != null ) {
			Constants.serverMode = strServerMode;
		}
		if ( strDbMode != null ) {
			Constants.DB_MODE = strDbMode;
		}
		SpringApplication.run(Application.class, args);
	}
}
