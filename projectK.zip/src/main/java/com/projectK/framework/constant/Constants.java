/**
 *
 */
package com.projectK.framework.constant;

import java.math.BigDecimal;

/**
 * Common global variable Class
 *
 * <p>
 * <수정이력> <br />
 * 1. 수정일: 수정자: 수정사유: <br />
 * <p>
 * @since 2021. 7. 1.
 * @version 1.0
 * @author Coder2
 */
public class Constants {
	public static final int SUCCESS_CODE = 0;
	public static final String SUCCESS_MSG = "정상처리되었습니다.";

	public static final int ERR_CODE = -9999;
	public static final String ERR_MSG = "서비스가 정상적으로 처리되지 않았습니다.\n문제가 지속적으로 발생할 경우 앱을 종료하고 다시 실행해 주세요.";

	public static final String HEADER_ACCEPT_APPLICATION_JSON = "application/json";
	public static final String JSON_STRING = "jsonString";

	// Server Mode
	public static final String SERVER_MODE = "server.mode";
	public static final String SERVER_MODE_REAL = "real";

	public static final String HTTP_METHOD_GET = "GET";
	public static final String HTTP_METHOD_POST = "POST";

	public static final String configFile = "config/config.properties";
	public static final String DATETIME_FULL_FORMAT = "yyyyMMddHHmmssSSS";
	public static final String DATETIME_MIN_FORMAT = "yyyyMMddHHmmss";

	// 암호화 관련 코드
	public static final String ENCRYPT_KEY = "LINCOLNMKZ.HYUNDAIPALISADE.HYUNDAIPALISADE.LINCOLNMKZ.56A5861241";
	public static final String ENCRYPT_IV = "LINCOLNMKZ.HYUNDAIPALISADE.20EC8";

	public static final int AMOUNT_SCALE = 8;

	public static final BigDecimal b100 = new BigDecimal(100);

	// 상세 로그
	public static boolean detailLog = true;
	public static String DB_MODE = "maria";
	public static String serverMode = SERVER_MODE_REAL;

	public static String walletHistoryQueryId = "common.maria.insertMemberWalletHistory";
	public static String insertMarketPriceQueryId = "common.maria.insertMarketPrice";
	public static String collectMiningResultQueryId = "common.maria.collectMiningResult";
	public static String insertAuthNumberQueryId = "common.maria.insertAuthNumber";

}
