/* ====================================================================
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
==================================================================== */

package com.projectK.framework.excel;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

import javax.servlet.http.HttpServletRequest;

import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFDataFormat;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.projectK.framework.util.CommFileUtil;
import com.projectK.framework.util.DataMap;

/**
 * 대용량 엑셀다운로드
 * @author
 * @since 2012. 8. 8.
 * @see
 * <pre>
 * == 개정이력(Modification Information) ==
 *
 * 수정일              수정자                 수정내용
 * ------------        ---------------        ---------------------------
 * </pre>
 */
public class BigExcelWriter {
	public String sheetRef = null;
	public Map<String, XSSFCellStyle> selectStyles = null;
    
    public BigExcelWriter(String sSheetNm, String sFilePath, String sFileTempNm) throws IOException{
    	
    	FileOutputStream os = null;

    	try{
    		// 엑셀 생성
	    	XSSFWorkbook wb = new XSSFWorkbook();
	    	
	        XSSFSheet sheet = wb.createSheet(sSheetNm);
	        
	        // 컬럼 스타일 속성 가져오기
	        selectStyles = this.createStyles(wb);
	        
	        //name of the zip entry holding sheet data, e.g. /xl/worksheets/sheet1.xml
	        sheetRef = sheet.getPackagePart().getPartName().getName();
	        
	        
	        // 디렉토리 없으면 생성.
	    	CommFileUtil.makeDirectory(sFilePath);
	    	// 템플릿 저장
	        os = new FileOutputStream(sFileTempNm);
	        wb.write(os);
	        os.close();
    	}catch(Exception e){
    		if(os != null){
    			os.close();
    		}
    	}
    	
    	
    }
    
    /**
     * 셀 스타일 정의
     * @param wb
     * @return
     */
    @SuppressWarnings("deprecation")
    public Map<String, XSSFCellStyle> createStyles(XSSFWorkbook wb){
        Map<String, XSSFCellStyle> styles = new HashMap<String, XSSFCellStyle>();
        XSSFDataFormat fmt = wb.createDataFormat();
        
        XSSFFont headerFont = wb.createFont();
        headerFont.setBold(true);
        headerFont.setColor(IndexedColors.WHITE.index);
        headerFont.setFontHeight(10);
        
        XSSFFont contentFont = wb.createFont();
        contentFont.setBold(true);
        contentFont.setColor(IndexedColors.BLACK.index);
        contentFont.setFontHeight(10);
        
        
        XSSFCellStyle style0 = wb.createCellStyle();
        style0.setFont(contentFont);
        style0.setAlignment(HorizontalAlignment.LEFT);
        style0.setBorderTop(BorderStyle.THIN);
        style0.setBorderBottom(BorderStyle.THIN);
        style0.setBorderLeft(BorderStyle.THIN);
        style0.setBorderRight(BorderStyle.THIN);
        style0.setTopBorderColor(IndexedColors.BLACK.index);
        style0.setBottomBorderColor(IndexedColors.BLACK.index);
        style0.setLeftBorderColor(IndexedColors.BLACK.index);
        style0.setRightBorderColor(IndexedColors.BLACK.index);
//        style0.setAlignment(XSSFCellStyle.ALIGN_LEFT);
//        style0.setBorderTop(HSSFCellStyle.BORDER_THIN);
//        style0.setBorderBottom(HSSFCellStyle.BORDER_THIN);
//        style0.setBorderLeft(HSSFCellStyle.BORDER_THIN);
//        style0.setBorderRight(HSSFCellStyle.BORDER_THIN);
//        style0.setTopBorderColor(HSSFColor.BLACK.index);
//        style0.setBottomBorderColor(HSSFColor.BLACK.index);
//        style0.setLeftBorderColor(HSSFColor.BLACK.index);
//        style0.setRightBorderColor(HSSFColor.BLACK.index);
        styles.put("normal", style0);
        
        XSSFCellStyle style1 = wb.createCellStyle();
        style1.setFont(contentFont);
        style1.setAlignment(HorizontalAlignment.RIGHT);
        style1.setDataFormat(fmt.getFormat("0.0%"));
        style1.setBorderTop(BorderStyle.THIN);
        style1.setBorderBottom(BorderStyle.THIN);
        style1.setBorderLeft(BorderStyle.THIN);
        style1.setBorderRight(BorderStyle.THIN);
        style1.setTopBorderColor(IndexedColors.BLACK.index);
        style1.setBottomBorderColor(IndexedColors.BLACK.index);
        style1.setLeftBorderColor(IndexedColors.BLACK.index);
        style1.setRightBorderColor(IndexedColors.BLACK.index);
//        style1.setAlignment(XSSFCellStyle.ALIGN_RIGHT);
//        style1.setDataFormat(fmt.getFormat("0.0%"));
//        style1.setBorderTop(HSSFCellStyle.BORDER_THIN);
//        style1.setBorderBottom(HSSFCellStyle.BORDER_THIN);
//        style1.setBorderLeft(HSSFCellStyle.BORDER_THIN);
//        style1.setBorderRight(HSSFCellStyle.BORDER_THIN);
//        style1.setTopBorderColor(HSSFColor.BLACK.index);
//        style1.setBottomBorderColor(HSSFColor.BLACK.index);
//        style1.setLeftBorderColor(HSSFColor.BLACK.index);
//        style1.setRightBorderColor(HSSFColor.BLACK.index);
        styles.put("percent", style1);

        XSSFCellStyle style2 = wb.createCellStyle();
        style2.setFont(contentFont);
        style2.setAlignment(HorizontalAlignment.CENTER);
        style2.setDataFormat(fmt.getFormat("0.0X"));
        style2.setBorderTop(BorderStyle.THIN);
        style2.setBorderBottom(BorderStyle.THIN);
        style2.setBorderLeft(BorderStyle.THIN);
        style2.setBorderRight(BorderStyle.THIN);
        style2.setTopBorderColor(IndexedColors.BLACK.index);
        style2.setBottomBorderColor(IndexedColors.BLACK.index);
        style2.setLeftBorderColor(IndexedColors.BLACK.index);
        style2.setRightBorderColor(IndexedColors.BLACK.index);
//        style2.setAlignment(XSSFCellStyle.ALIGN_CENTER);
//        style2.setDataFormat(fmt.getFormat("0.0X"));
//        style2.setBorderTop(HSSFCellStyle.BORDER_THIN);
//        style2.setBorderBottom(HSSFCellStyle.BORDER_THIN);
//        style2.setBorderLeft(HSSFCellStyle.BORDER_THIN);
//        style2.setBorderRight(HSSFCellStyle.BORDER_THIN);
//        style2.setTopBorderColor(HSSFColor.BLACK.index);
//        style2.setBottomBorderColor(HSSFColor.BLACK.index);
//        style2.setLeftBorderColor(HSSFColor.BLACK.index);
//        style2.setRightBorderColor(HSSFColor.BLACK.index);
        styles.put("coeff", style2);

        XSSFCellStyle style3 = wb.createCellStyle();
        style3.setFont(contentFont);
        style3.setAlignment(HorizontalAlignment.RIGHT);
        style3.setDataFormat(fmt.getFormat("$#,##0.00"));
        style3.setBorderTop(BorderStyle.THIN);
        style3.setBorderBottom(BorderStyle.THIN);
        style3.setBorderLeft(BorderStyle.THIN);
        style3.setBorderRight(BorderStyle.THIN);
        style3.setTopBorderColor(IndexedColors.BLACK.index);
        style3.setBottomBorderColor(IndexedColors.BLACK.index);
        style3.setLeftBorderColor(IndexedColors.BLACK.index);
        style3.setRightBorderColor(IndexedColors.BLACK.index);
//        style3.setAlignment(XSSFCellStyle.ALIGN_RIGHT);
//        style3.setDataFormat(fmt.getFormat("$#,##0.00"));
//        style3.setBorderTop(HSSFCellStyle.BORDER_THIN);
//        style3.setBorderBottom(HSSFCellStyle.BORDER_THIN);
//        style3.setBorderLeft(HSSFCellStyle.BORDER_THIN);
//        style3.setBorderRight(HSSFCellStyle.BORDER_THIN);
//        style3.setTopBorderColor(HSSFColor.BLACK.index);
//        style3.setBottomBorderColor(HSSFColor.BLACK.index);
//        style3.setLeftBorderColor(HSSFColor.BLACK.index);
//        style3.setRightBorderColor(HSSFColor.BLACK.index);
        styles.put("currency", style3);

        XSSFCellStyle style4 = wb.createCellStyle();
        style4.setFont(contentFont);
        style4.setAlignment(HorizontalAlignment.RIGHT);
        style4.setDataFormat(fmt.getFormat("mmm dd"));
        style4.setBorderTop(BorderStyle.THIN);
        style4.setBorderBottom(BorderStyle.THIN);
        style4.setBorderLeft(BorderStyle.THIN);
        style4.setBorderRight(BorderStyle.THIN);
        style4.setTopBorderColor(IndexedColors.BLACK.index);
        style4.setBottomBorderColor(IndexedColors.BLACK.index);
        style4.setLeftBorderColor(IndexedColors.BLACK.index);
        style4.setRightBorderColor(IndexedColors.BLACK.index);
//        style4.setAlignment(XSSFCellStyle.ALIGN_RIGHT);
//        style4.setDataFormat(fmt.getFormat("mmm dd"));
//        style4.setBorderTop(HSSFCellStyle.BORDER_THIN);
//        style4.setBorderBottom(HSSFCellStyle.BORDER_THIN);
//        style4.setBorderLeft(HSSFCellStyle.BORDER_THIN);
//        style4.setBorderRight(HSSFCellStyle.BORDER_THIN);
//        style4.setTopBorderColor(HSSFColor.BLACK.index);
//        style4.setBottomBorderColor(HSSFColor.BLACK.index);
//        style4.setLeftBorderColor(HSSFColor.BLACK.index);
//        style4.setRightBorderColor(HSSFColor.BLACK.index);
        styles.put("date", style4);

        XSSFCellStyle style5 = wb.createCellStyle();
        style5.setFont(headerFont);
        style5.setFillForegroundColor(IndexedColors.ROYAL_BLUE.getIndex());
        style5.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        style5.setAlignment(HorizontalAlignment.CENTER);
        style5.setVerticalAlignment(VerticalAlignment.CENTER);
        style5.setFont(headerFont);
        style5.setBorderTop(BorderStyle.THIN);
        style5.setBorderBottom(BorderStyle.THIN);
        style5.setBorderLeft(BorderStyle.THIN);
        style5.setBorderRight(BorderStyle.THIN);
        style5.setTopBorderColor(IndexedColors.BLACK.index);
        style5.setBottomBorderColor(IndexedColors.BLACK.index);
        style5.setLeftBorderColor(IndexedColors.BLACK.index);
        style5.setRightBorderColor(IndexedColors.BLACK.index);
        

        styles.put("header", style5);
        
        XSSFCellStyle style6 = wb.createCellStyle();
        style6.setFont(contentFont);
        style6.setAlignment(HorizontalAlignment.RIGHT);
        style6.setDataFormat(fmt.getFormat("#,##0.00"));
        style6.setBorderTop(BorderStyle.THIN);
        style6.setBorderBottom(BorderStyle.THIN);
        style6.setBorderLeft(BorderStyle.THIN);
        style6.setBorderRight(BorderStyle.THIN);
        style6.setTopBorderColor(IndexedColors.BLACK.index);
        style6.setBottomBorderColor(IndexedColors.BLACK.index);
        style6.setLeftBorderColor(IndexedColors.BLACK.index);
        style6.setRightBorderColor(IndexedColors.BLACK.index);
        
        styles.put("dotNumber2", style6);
        
        XSSFCellStyle style7 = wb.createCellStyle();
        style7.setFont(contentFont);
        style7.setAlignment(HorizontalAlignment.RIGHT);
        style7.setDataFormat(fmt.getFormat("#,##0"));
        style7.setBorderTop(BorderStyle.THIN);
        style7.setBorderBottom(BorderStyle.THIN);
        style7.setBorderLeft(BorderStyle.THIN);
        style7.setBorderRight(BorderStyle.THIN);
        style7.setTopBorderColor(IndexedColors.BLACK.index);
        style7.setBottomBorderColor(IndexedColors.BLACK.index);
        style7.setLeftBorderColor(IndexedColors.BLACK.index);
        style7.setRightBorderColor(IndexedColors.BLACK.index);
        styles.put("number", style7);
        
        XSSFCellStyle style8 = wb.createCellStyle();
        style8.setFont(contentFont);
        style8.setAlignment(HorizontalAlignment.RIGHT);
        style8.setDataFormat(fmt.getFormat("#,##0.000"));
        style8.setBorderTop(BorderStyle.THIN);
        style8.setBorderBottom(BorderStyle.THIN);
        style8.setBorderLeft(BorderStyle.THIN);
        style8.setBorderRight(BorderStyle.THIN);
        style8.setTopBorderColor(IndexedColors.BLACK.index);
        style8.setBottomBorderColor(IndexedColors.BLACK.index);
        style8.setLeftBorderColor(IndexedColors.BLACK.index);
        style8.setRightBorderColor(IndexedColors.BLACK.index);
        
        styles.put("dotNumber3", style8);
        
        /*
         * 2016-09-06 엑셀 타이틀 추가
         * <c t="inlineStr" s="10">  스타일 10번으로 사용
         */
        XSSFCellStyle style9 = wb.createCellStyle();
        XSSFFont titleFont = wb.createFont();
        titleFont.setBold(true);
        titleFont.setFontHeightInPoints((short)30);
        style9.setFont(titleFont);
        style9.setAlignment(HorizontalAlignment.CENTER);
        styles.put("titleStyle", style9);
        
        // 짝수줄에 적용할 스타일
        XSSFCellStyle style10 = wb.createCellStyle();
        style10.setFont(contentFont);
        style10.setFillForegroundColor(IndexedColors.LEMON_CHIFFON.index);
        style10.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        style10.setBorderTop(BorderStyle.THIN);
        style10.setBorderBottom(BorderStyle.THIN);
        style10.setBorderLeft(BorderStyle.THIN);
        style10.setBorderRight(BorderStyle.THIN);
        style10.setTopBorderColor(IndexedColors.BLACK.index);
        style10.setBottomBorderColor(IndexedColors.BLACK.index);
        style10.setLeftBorderColor(IndexedColors.BLACK.index);
        style10.setRightBorderColor(IndexedColors.BLACK.index);
        styles.put("evenLine", style10);
        
        return styles;
    }

    /**
     * 타이틀 생성
     * @param sTitle
     * @param sStyleType
     * @param sw
     * @throws Exception
     */
    public void generateHeader(String fileNm, String [] sTitle, String sStyleType, SpreadSheetWriter sw) throws Exception {
    	//첫번째 row에 전테 타이틀 추가
    	sw.insertRow(0);
    	if( fileNm.indexOf('_') > -1 ) fileNm = fileNm.substring(0,fileNm.indexOf('_'));
        sw.createTitleCell(0, fileNm);
        sw.endRow();
        
        //타이틀 후 1칸 띄우고 다음 row부터 헤더 작성
        sw.insertRow(2);
        int styleIndex = selectStyles.get(sStyleType).getIndex();
        
        //컬럼 갯수
      	int iTitleSize = sTitle.length;
      	
      	//컬럼갯수 만큼 타이틀 생성
        for (int i = 0; i < iTitleSize; i++) {
        	sw.createCell(i, sTitle[i], styleIndex);
        }
        
        sw.endRow();
    
    }
    
    /**
     * 내용 작성
     * @param iTitleField
     * @param sTitleField
     * @param iRowNum
     * @param rs
     * @param sStyleType
     * @param sw
     * @throws Exception
     */
    public void generateContent(HttpServletRequest request, int iTitleField, String [] sTitleField, int iRowNum, DataMap dataMap, String[] sStyleType, SpreadSheetWriter sw) throws Exception {
    	
    	//write data rows
        sw.insertRow(iRowNum);

        for (int j = 0; j < iTitleField; j++) {
        	if(selectStyles.get(sStyleType[j]) == null){
        		sStyleType[j] = "normal";
        	}
        	
        	if("number".equals(sStyleType[j]) || "dotNumber2".equals(sStyleType[j]) || "dotNumber3".equals(sStyleType[j])){
        		double dValue=0;
        		if(dataMap.get(sTitleField[j])!=null){
        			dValue=Double.parseDouble((String) dataMap.get(sTitleField[j]));
        		}
        		sw.createCell(j, dValue, selectStyles.get(sStyleType[j]).getIndex());
        	}
        	else if("normal".equals(sStyleType[j])){
        	    
        	    sw.createCell(j, dataMap.getString(sTitleField[j]), selectStyles.get(sStyleType[j]).getIndex());
        		
        	}
        	
        }
        sw.endRow();
    }

    /**
     * 템플릿 파일에 데이터 복사해서 만듬
     * @param zipfile 템플릿 파일
     * @param tmpfile 시트데이터를 가진 xml 파일
     * @param entry the name of the sheet entry to substitute, e.g. xl/worksheets/sheet1.xml
     * @param out 결과값에 대한 스트림
     */
    public void substitute(File zipfile, File tmpfile, OutputStream out) throws IOException {
    	
    	ZipFile zip = null;
    	InputStream is = null;
    	ZipOutputStream zos = null;
    	
    	try{
	        zip = new ZipFile(zipfile);
	
	        zos = new ZipOutputStream(out);
	        String entry = sheetRef.substring(1);
	        @SuppressWarnings("unchecked")
	        Enumeration<ZipEntry> en = (Enumeration<ZipEntry>) zip.entries();
	        while (en.hasMoreElements()) {
	            ZipEntry ze = en.nextElement();
	            if(!ze.getName().equals(entry)){
	                zos.putNextEntry(new ZipEntry(ze.getName()));
	                InputStream isze = zip.getInputStream(ze);
	                copyStream(isze, zos);
	                isze.close();
	            }
	        }
	        zos.putNextEntry(new ZipEntry(entry));
	        is = new FileInputStream(tmpfile);
	        copyStream(is, zos);
	        is.close();
	
	        zip.close();
	        zos.close();
    	}catch(Exception e){
    		if(zip != null){
    			zip.close();
    		}
    		
    		if(is != null){
    			is.close();
    		}
    		
    		if(zos != null){
    			zos.close();
    		}
    	}
    }

    /**
     * 파일복사
     * @param in
     * @param out
     * @throws IOException
     */
    private void copyStream(InputStream in, OutputStream out) throws IOException {
        byte[] chunk = new byte[1024];
        int count;
        while ((count = in.read(chunk)) >=0 ) {
        	out.write(chunk,0,count);
        }
    }
}