package com.projectK.framework.excel;

import java.io.IOException;
import java.io.Writer;
import java.util.Calendar;

import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.util.CellReference;

 /**
 * 엑셀 스프레드 시트 속성 클래스
 * @author
 * @since 2012. 8. 8.
 * @see
 * <pre>
 * == 개정이력(Modification Information) ==
 *
 * 수정일              수정자                 수정내용
 * ------------        ---------------        ---------------------------
 * </pre>
 */
public class SpreadSheetWriter {
	
	private final String XML_ENCODING = "UTF-8";
    private final Writer _out;
    private int _rownum;

    public SpreadSheetWriter(Writer out){
        _out = out;
    }

    public void beginSheet(String [] sTitle) throws IOException {
        _out.write("<?xml version=\"1.0\" encoding=\""+XML_ENCODING+"\"?>\n");
       
        _out.write("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">\n" );
        //컬럼조정하는것이 안되는 사용자가 있어서 주석처리
        /*
        _out.write("<fonts count=\"2\"><font /><font><b /></font></fonts>\n");
        
        _out.write("<cols>");
        for(int i = 1; i < sTitle.length+1; i++) {
        	_out.write("<col min=\""+ i +"\" max=\""+ i +"\" width=\"17\" custumWidth=\"1\"/>\n");
        }
        _out.write("</cols>");
        */
        _out.write("<sheetData>\n");
    }

    public void endSheet(int endLength) throws IOException {
        _out.write("</sheetData>");
        
        String endColumn = getExcelColumnName(endLength);
        
        _out.write("<mergeCells count=\"1\">");
        _out.write("<mergeCell ref=\"A1:" + endColumn + "1\"/>");
        _out.write("</mergeCells>");
        
        _out.write("</worksheet>");
    }

    /**
     * Insert a new row
     *
     * @param rownum 0-based row number
     */
    public void insertRow(int rownum) throws IOException {
        _out.write("<row r=\""+(rownum+1)+"\">\n");
        
        this._rownum = rownum;
    }

    /**
     * Insert row end marker
     */
    public void endRow() throws IOException {
        _out.write("</row>\n");
    }
    
    public void createTitleCell(int columnIndex, String value) throws IOException {
    	if(value == null){
    		value="";
    	}
    	
    	value = value.replaceAll("&", "&amp;");
    	value = value.replaceAll("<", "&lt;");
    	value = value.replaceAll(">", "&gt;");
    	
        _out.write("<c t=\"inlineStr\" s=\"10\" >");
        _out.write("<is><t>"+value+"</t></is>");
        _out.write("</c>");
    }
    
    public void createCell(int columnIndex, String value, int styleIndex) throws IOException {
    	if(value == null){
    		value="";
    	}
    	
    	value = value.replaceAll("&", "&amp;");
    	value = value.replaceAll("<", "&lt;");
    	value = value.replaceAll(">", "&gt;");
    	
        String ref = new CellReference(_rownum, columnIndex).formatAsString();
        
        _out.write("<c r=\""+ref+"\" t=\"inlineStr\"");
        
        if( _rownum > 3 &&  _rownum % 2 == 0 ){
        	_out.write(" s=\"11\"");
        }else{
        	if(styleIndex != -1) _out.write(" s=\""+styleIndex+"\"");
        }
        
        _out.write(">");
        _out.write("<is><t>"+value+"</t></is>");
        _out.write("</c>");
    }

    public void createCell(int columnIndex, String value) throws IOException {
        createCell(columnIndex, value, -1);
    }

    public void createCell(int columnIndex, double value, int styleIndex) throws IOException {
        String ref = new CellReference(_rownum, columnIndex).formatAsString();
        _out.write("<c r=\""+ref+"\" t=\"n\"");
        if(styleIndex != -1) _out.write(" s=\""+styleIndex+"\"");
        _out.write(">");
        _out.write("<v>"+value+"</v>");
        _out.write("</c>");
    }

    public void createCell(int columnIndex, double value) throws IOException {
        createCell(columnIndex, value, -1);
    }

    public void createCell(int columnIndex, Calendar value, int styleIndex) throws IOException {
        createCell(columnIndex, DateUtil.getExcelDate(value, false), styleIndex);
    }
    
    /*
    public static String getExcelColumnName(int number) {
    	final StringBuilder sb = new StringBuilder();
    	
    	int num = number-1;
    	while(num >= 0) {
    		int numChar = (num % 26) + 65;
    		sb.append((char)numChar);
    		num = (num / 26) - 1;
    	}
    	
    	return sb.reverse().toString();
    }
    */
    
    public static String getExcelColumnName(int number) {
    	StringBuilder sb = new StringBuilder();
    	while(number-- > 0) {
    		sb.append((char)('A' + number % 26));
    		number /= 26;
    	}
    	
    	return sb.reverse().toString();
    }
    
/*    public static void main(String [] args) {
    }*/
}
