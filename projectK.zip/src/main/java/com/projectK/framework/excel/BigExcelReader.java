package com.projectK.framework.excel;

import java.util.ArrayList;
import java.util.List;

import com.projectK.framework.context.SpringAppContext;
import com.projectK.framework.exception.CommonException;
import com.projectK.framework.service.CommExcelService;
import com.projectK.framework.util.DataMap;
import com.projectK.framework.util.PropertyFileUtil;
import org.apache.poi.ss.util.CellReference;
import org.apache.poi.xssf.eventusermodel.XSSFSheetXMLHandler;
import org.apache.poi.xssf.usermodel.XSSFComment;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;



/**
 * 
 * <p> 
 * <수정이력> <br /> 
 * 1. 수정일: 수정자: 수정사유: <br />
 * <p>
 * @since 2019. 9. 23.
 * @version 1.0
 * @author
 */
public class BigExcelReader implements XSSFSheetXMLHandler.SheetContentsHandler {

	private static final Logger logger = LoggerFactory.getLogger(BigExcelReader.class);

    //빈 값을 체크하기 위해 사용할 셀번호
    private int currentCol = -1;

    //현재 읽고 있는 Cell의 Col
    private int currRowNum = 1;
    
    private String[] colNms = null;
    private String queryId = "";
    private String userId = "";
    private String trainUnitEduSeq = "";
    
    private ApplicationContext context = null;
    private CommExcelService commExcelService = null;
    
    private int iCommitCnt = 0;
    private String traineeGbn = "";

    private final DataMap cmapInsert = new DataMap();
    private final List<DataMap> listInsertData = new ArrayList<DataMap>();
    private int listInsertDataIdx = 0;
    
    private final DataMap cmapParam = new DataMap();
    
    private final int iExcelTotCnt = 0;
    
	public BigExcelReader(DataMap dtaMap) {
    		
		this.colNms = (String[]) dtaMap.get("colNms");
    	this.queryId = dtaMap.getString("queryId");
    	this.traineeGbn = dtaMap.getString("traineeGbn");
    	this.userId = dtaMap.getString("userId");
    	this.trainUnitEduSeq = dtaMap.getString("trainUnitEduSeq");
    	
    	cmapParam.putAll(dtaMap);
    	cmapParam.remove("colNms");
    	cmapParam.remove("queryId");
    	cmapParam.remove("traineeGbn");
    	cmapParam.remove("userId");
    	cmapParam.remove("trainUnitEduSeq");
    		
    	context = SpringAppContext.getInstance().getApplicationContext();
    	commExcelService = context.getBean(CommExcelService.class);
    	
    	iCommitCnt = Integer.valueOf(PropertyFileUtil.getString("excel.upload.commit.cnt"));
    	
    	if(!"trainee".equals(traineeGbn)) {
    		
    		for(int i=0; i<iCommitCnt; i++) {
    			DataMap listMap = new DataMap();
    			listInsertData.add(listMap);
    		}
    	}
    	
    }
    
    public void startRow(int rowNum) {
        //empty 값을 체크하기 위한 초기 셋팅값
        this.currentCol = -1;
        this.currRowNum = rowNum;
    }
    
    public void endRow(int rowNum) {
    	
    	if(rowNum != 0 && !cmapInsert.isEmpty()) {
    		
	    	try {
    			listInsertData.get(listInsertDataIdx).putAll(cmapInsert);
    			listInsertData.get(listInsertDataIdx).putAll(cmapParam);
    			listInsertDataIdx++;
    			
				if(iCommitCnt == listInsertDataIdx) {
    				commExcelService.setExcelDatabase(listInsertData, queryId, listInsertDataIdx);
    				clearListData();
    			}
			} catch (Exception e) {
				e.printStackTrace();
				throw new CommonException("엑셀 DB 저장중 오류 발생");
			} 
    	}
    	
    	cmapInsert.clear();
    }

    public void cell(String columnName, String value, XSSFComment var3) {
    	
    	int iCol = (new CellReference(columnName)).getCol();
    	
    	for(int i=0; i<colNms.length; i++) {
    		
    		if(iCol == i) {
    			cmapInsert.put("regUser", this.userId);
    			cmapInsert.put("uptUser", this.userId);
    			cmapInsert.put(colNms[i], value);
    		}
    	}
    }
    
    public void endSheet() {
		if(listInsertDataIdx > 0) {
			try {
				commExcelService.setExcelDatabase(listInsertData, queryId, listInsertDataIdx);
				clearListData();
				listInsertData.clear();
			} catch (Exception e) {
				throw new CommonException("엑셀 DB 저장중 오류 발생");
			}
		}
    }
    
    public void clearListData() {
    	
    	for(int i=0; i<listInsertDataIdx; i++) {
    		listInsertData.get(i).clear();
    	}
    	
    	listInsertDataIdx = 0;
    }
    
    public int getExcelTotCnt() {
    	return iExcelTotCnt;
    }
}