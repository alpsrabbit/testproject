/**
 *   
 */
package com.projectK.framework.exception;

/**
 * Common Exception Class
 * 
 * <p> 
 * <수정이력> <br /> 
 * 1. 수정일: 수정자: 수정사유: <br />
 * <p>
 * @since 2021. 7. 1.
 * @version 1.0
 * @author   
 */
public class CommonException extends RuntimeException {
	
	private static final long serialVersionUID = 4295626046960299917L;
	private static final int DEFAULT_ERROR_CODE = -1;
	private int errorCode;
	private String errorMsg;
	
	public CommonException() { }
	
	public CommonException(String errorMsg) {
		this.errorCode = DEFAULT_ERROR_CODE; 
		this.errorMsg = errorMsg;
	}
	
	public CommonException(int errorCode, String errorMsg) {
		this.errorCode = errorCode;
		this.errorMsg = errorMsg;
	}
	
	public int getErrorCode() {
		return errorCode;
	}
	
	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
	
	public String getErrorMsg() {
		return errorMsg;
	}
	
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	
}
