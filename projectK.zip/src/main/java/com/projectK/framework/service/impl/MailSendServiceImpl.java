package com.projectK.framework.service.impl;

import com.projectK.framework.constant.Constants;
import com.projectK.framework.service.MailSendService;
import com.projectK.framework.util.DataMap;
import com.projectK.framework.util.PropertyFileUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.Properties;

@Service("mailSendService")
public class MailSendServiceImpl implements MailSendService {
    private static final Logger logger = LoggerFactory.getLogger(MailSendService.class);

    public void mailSend(DataMap params) throws Exception {
        if(Constants.detailLog) logger.info("mailSendService.mailSend] Request Params >>>> [{}]", params);

        // gmail 설정 : https://velog.io/@max9106/Spring-Boot-Gmail-SMTP-%EC%82%AC%EC%9A%A9%ED%95%98%EA%B8%B0%EB%A9%94%EC%9D%BC%EB%B3%B4%EB%82%B4%EA%B8%B0

        // 참조 : http://www.gnujava.com/board/article_view.jsp?article_no=5339&board_no=4&table_cd=EPAR01&table_no=01
        // 참조 : https://mkil.tistory.com/340
        /*
        mimeMessage.setSubject(MimeUtility.encodeText(subject,"EUC-KR", "B"));
        mimeMessage.setSubject(MimeUtility.encodeText(subject,"UTF-8", "B"));

        mimeMessage.setContent(content, "text/html;charset=UTF-8");
        mimeMessage.setContent(content, "text/html;charset=EUC-KR");
         */


        String username = PropertyFileUtil.getString("mail.account");
        String password = PropertyFileUtil.getString("mail.password");

        String mailHost = PropertyFileUtil.getString("mail.smtp.host");
        String mailPort = PropertyFileUtil.getString("mail.smtp.port");
        String mailAuthYn = PropertyFileUtil.getString("mail.smtp.auth");
        String mailTlsEnable = PropertyFileUtil.getString("mail.smtp.starttls.enable");


        /*
        String username = "buseo0224@gmail.com";
        String password = "fwdryawqjzgwuspc";

        String mailHost = "smtp.gmail.com";
        String mailPort = "587";
        String mailAuthYn = "true";
        String mailTlsEnable = "true";
        */

        String strMailType="text/html; charset=UTF-8";

        Properties prop = new Properties();
        prop.put("mail.smtp.host", mailHost);
        prop.put("mail.smtp.port", mailPort);
        prop.put("mail.smtp.auth", mailAuthYn);
        prop.put("mail.smtp.starttls.enable", mailTlsEnable);
        prop.put("mail.smtp.ssl.enable", "true");

        Session session = Session.getInstance(prop,
                new javax.mail.Authenticator() {
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(username, password);
                    }
                });

        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(username));
            message.setRecipients(
                    Message.RecipientType.TO,
                    InternetAddress.parse(params.getString("recAddr"))
            );
            message.setSubject(params.getString("title"));
//            message.setText("Dear Mail Crawler,"
//                    + "\n\n Please do not spam my email!");

            if(params.get("message") == null) {
                message.setContent("", strMailType);
            } else {
                message.setContent(params.getString("message"), strMailType);
            }
            Transport.send(message);

            if(Constants.detailLog)logger.info("MailSendService.senMail Send Message " );

        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }
}