package com.projectK.framework.service;

import com.projectK.framework.util.DataMap;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import java.util.List;

public interface FileUploadService {

    /**
     * file upload
     * @param multipartRequest
     * @param params
     * @return
     * @throws Exception
     */
    public List<DataMap> fileUpload(MultipartHttpServletRequest multipartRequest, DataMap params) throws Exception;
}
