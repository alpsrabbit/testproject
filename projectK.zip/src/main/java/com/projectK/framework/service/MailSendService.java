package com.projectK.framework.service;

import com.projectK.framework.util.DataMap;

public interface MailSendService {
    void mailSend(DataMap params) throws Exception;
}
