package com.projectK.framework.service;

import com.projectK.framework.util.DataMap;

import java.util.List;


public interface CommEncryptService {
	
	String encrypt(String targetString) throws Exception;
	String decrypt(String targetString) throws Exception;
	DataMap encryptDataMap(DataMap dataMap, List<String> listCol) throws Exception;
	DataMap decryptDataMap(DataMap dataMap, List<String> listCol) throws Exception;

}
