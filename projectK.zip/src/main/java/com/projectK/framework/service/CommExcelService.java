package com.projectK.framework.service;

import com.projectK.framework.util.DataMap;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



/**
*
* @ClassName   :  CommonExcelService
* @Description : 공통 엑셀 관련 인터페이스
* @author
* @since 2016. 7. 25.
* @version 1.0
* @see <pre>
* == 개정이력(Modification Information) ==
*
*       수정일          수정자                 수정내용
*  -----------    --------    -----------------------
*
* </pre>
*/
public interface CommExcelService {

    /**
     * Desc : 웹용 대량엑셀다운로드
     * @Method Name : selectCommonWebExcel
     * @param pcMap
     * @param request
     * @param response
     * @throws Exception
     */
    void selectCommonWebExcel(DataMap dataMap, HttpServletRequest request, HttpServletResponse response) throws Exception;
    
    /**
     * 엑셀업로드 처리
     * @since 2019. 9. 9. 
     * @param colNms
     * @param queryId
     * @param uploadFile
     * @return
     * @throws Exception 
     */
    DataMap insertExcelUpload(DataMap dataMap) throws Exception;
    
    /**
     * 엑셀 업로드 DB Insert
     * @since 2019. 9. 23. 
     * @param listData
     * @param queryId
     * @throws Exception 
     */
    void setExcelDatabase(List<DataMap> listData, String queryId, int listDataCnt) throws Exception;
}
