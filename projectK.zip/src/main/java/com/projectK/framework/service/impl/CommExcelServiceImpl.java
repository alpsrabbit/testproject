package com.projectK.framework.service.impl;

import java.io.File;
import java.io.InputStream;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.projectK.framework.constant.Constants;
import com.projectK.framework.dao.CommExcelDAO;
import com.projectK.framework.excel.BigExcelReader;
import com.projectK.framework.exception.CommonException;
import com.projectK.framework.service.CommEncryptService;
import com.projectK.framework.util.StringUtil;
import com.projectK.framework.vo.FileResultVO;
import org.apache.poi.ooxml.util.SAXHelper;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.xssf.eventusermodel.ReadOnlySharedStringsTable;
import org.apache.poi.xssf.eventusermodel.XSSFReader;
import org.apache.poi.xssf.eventusermodel.XSSFSheetXMLHandler;
import org.apache.poi.xssf.model.StylesTable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;


import com.projectK.framework.dao.CommDAO;
import com.projectK.framework.util.DataMap;
import com.projectK.framework.service.CommExcelService;

@Service("commExcelService")
public class CommExcelServiceImpl implements CommExcelService {
	
	private static final Logger logger = LoggerFactory.getLogger(CommExcelServiceImpl.class);
	
	@Autowired
	private CommExcelDAO commonExcelDAO;
	
	@Resource(name="commDAO")
	private CommDAO commDAO;

	@Resource(name = "commEncryptService")
	private CommEncryptService commEncryptService;
	
	/**
     * Desc : 웹용 대량엑셀다운로드
     * @Method Name : selectCommonWebExcel
     * @param pcMap
     * @param request
     * @param response
     * @throws Exception
     */
    public void selectCommonWebExcel(DataMap pcMap, HttpServletRequest request, HttpServletResponse response) throws Exception {
        
        String strQueryId = pcMap.getString("strQueryId");
        String strFileNm = pcMap.getString("strFileNm");
        
        DataMap cmapInput = StringUtil.sGetParamParse(pcMap, strFileNm , strQueryId);
		logger.info(">>>>>[{}]", cmapInput);
        
        commonExcelDAO.selectExcelDownload(strQueryId, cmapInput, request, response);
    }

	/* 
	 * 엑셀업로드 처리
	 * @since 2019. 9. 9.
	 * @see com.camp.cmmn.service.CommExcelService#insertExcelUpload(java.lang.String[], java.lang.String, java.io.File)
	 * @param colNms
	 * @param queryId
	 * @param uploadFile
	 * @return
	 * @throws Exception 
	 */
	@Override
	public DataMap insertExcelUpload(DataMap dataMap) throws Exception {
		
		List<FileResultVO> resultFile = (List<FileResultVO>) dataMap.get("resultFile");
		
		DataMap cmapReturn = new DataMap();
		cmapReturn.put("resultCd", Constants.SUCCESS_CODE);
		
		
		OPCPackage opcPackage = null;
		XSSFReader xssfReader = null;
		InputStream sheetStream = null;
		
		File uploadFile = null;
		
		try {
			BigExcelReader excelReader = new BigExcelReader(dataMap);
			uploadFile = new File(resultFile.get(0).getsFileFullPath() + resultFile.get(0).getsFileNm() + "." + resultFile.get(0).getsExtensionNm());

			opcPackage = OPCPackage.open(uploadFile);
			xssfReader = new XSSFReader(opcPackage);
			ReadOnlySharedStringsTable data = new ReadOnlySharedStringsTable(opcPackage);
			
			StylesTable styles = xssfReader.getStylesTable();
		
	        //엑셀의 첫번째 sheet정보만 읽어오기 위해 사용 만약 다중 sheet 처리를 위해서는 반복문 필요
		    sheetStream = xssfReader.getSheetsData().next();
		    InputSource sheetSource = new InputSource(sheetStream);
		    ContentHandler handler = new XSSFSheetXMLHandler(styles, data, excelReader, false);
		    
	        //SAX 형식의 XMLReader 생성
		    XMLReader sheetParser = SAXHelper.newXMLReader();
		
	        //XMLReader에 재정의하여 구현한 인터페이스 설정
		    sheetParser.setContentHandler(handler);
		
	        //파싱하여 처리
		    sheetParser.parse(sheetSource);
		    
		    cmapReturn.put("totCnt", excelReader.getExcelTotCnt());
		    
		} catch (Exception e) {
			e.printStackTrace();
			throw new CommonException("엑셀업로드 처리중 오류발생");
		}finally {
			
			sheetStream.close();
		    opcPackage.close();
		    
			uploadFile.delete();
		}
		
	    return cmapReturn;
	}

	/* 
	 * 엑셀 업로드 DB Insert
	 * @since 2019. 9. 23.
	 * @see com.camp.cmmn.service.CommExcelService#saveExcelDatabase(java.util.List, java.lang.String)
	 * @param listData
	 * @param queryId
	 * @throws Exception 
	 */
	@Override
	public void setExcelDatabase(List<DataMap> listData, String queryId, int listDataCnt) throws Exception {
		
		for(int i=0; i<listDataCnt; i++) {
			commDAO.insert(queryId, listData.get(i));
    	}
	}
}
