package com.projectK.framework.service.impl;

import java.util.List;

import com.projectK.framework.constant.Constants;
import com.projectK.framework.util.CommEncryptUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.projectK.framework.service.CommEncryptService;
import com.projectK.framework.util.DataMap;

@Service("commEncryptService")
public class CommEncryptServiceImpl implements CommEncryptService {

	private static final Logger logger = LoggerFactory.getLogger(CommEncryptServiceImpl.class);
	
	@Override
	public String encrypt(String targetString) throws Exception {
		
		String strReturn = targetString;
		
		strReturn = CommEncryptUtil.aesEncrypt(targetString, Constants.ENCRYPT_KEY, Constants.ENCRYPT_IV);
		
		return strReturn;
	}

	@Override
	public String decrypt(String targetString) throws Exception {

		String strReturn = targetString;
		
		strReturn = CommEncryptUtil.aesDecrypt(targetString, Constants.ENCRYPT_KEY, Constants.ENCRYPT_IV );
		
		return strReturn;
	}

	@Override
	public DataMap encryptDataMap(DataMap dataMap, List<String> listCol) throws Exception {
		
		DataMap cmapReturn = new DataMap();
		
		List<String> listKey = dataMap.keyList();
		
		String tarVal = "";
		
		for(int i=0; i<listKey.size(); i++) {
			
			for(int j=0; j<listCol.size(); j++) {
				tarVal = dataMap.getString(listKey.get(i));
				if(listKey.get(i).equals(listCol.get(j))){
					tarVal = encrypt(tarVal);
				}
			}
			
			cmapReturn.put(listKey.get(i), tarVal);
		}
		
		return cmapReturn;
	}

	@Override
	public DataMap decryptDataMap(DataMap dataMap, List<String> listCol) throws Exception {
		
		DataMap cmapReturn = new DataMap();
		
		List<String> listKey = dataMap.keyList();
		
		String tarVal = "";
		
		for(int i=0; i<listKey.size(); i++) {
			
			for(int j=0; j<listCol.size(); j++) {
				tarVal = dataMap.getString(listKey.get(i));
				if(listKey.get(i).equals(listCol.get(j))){
					tarVal = decrypt(tarVal);
				}
			}
			
			cmapReturn.put(listKey.get(i), tarVal);
		}
		
		return cmapReturn;
	}
	
	

}
