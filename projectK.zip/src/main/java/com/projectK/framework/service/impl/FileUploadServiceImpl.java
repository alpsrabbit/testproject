package com.projectK.framework.service.impl;

import com.projectK.framework.constant.Constants;
import com.projectK.framework.service.FileUploadService;
import com.projectK.framework.util.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Service("fileUploadService")
public class FileUploadServiceImpl implements FileUploadService {
    private static final Logger logger = LoggerFactory.getLogger(FileUploadService.class);



    /**
     * file upload
     * @param multipartRequest
     * @param params
     * @return
     * @throws Exception
     */
    public List<DataMap> fileUpload(MultipartHttpServletRequest multipartRequest, DataMap params) throws Exception {
        if (Constants.detailLog) logger.info("fileUploadService.fileUpload Params >>>> [{}]", params);

        List<DataMap> fileList = new ArrayList<DataMap>();

        String fileName = null;
        String saveName = null;
        String fileExt = null;

        long fileSize = 0;

        String sUploadPath = params.getString("uploadPath");

        File uploadPath = new File(sUploadPath);
        if ( !uploadPath.isDirectory()) {
            uploadPath.mkdirs();
        }

        Iterator<String> files = multipartRequest.getFileNames();

        MultipartFile mFile = null;
        logger.info(">>>>[{}]", files);
        logger.info(">>>>[{}]", files.hasNext());

        while ( files.hasNext() ) {
            DataMap map = new DataMap();

            mFile = multipartRequest.getFile(files.next());

            fileName = mFile.getOriginalFilename();
            fileSize = mFile.getSize();
            logger.info("fileName >>>> [{}]", fileName);

            if ( fileSize <= 0 ) {
                break;
            }

            fileExt = CommFileUtil.getExt(fileName);
            saveName = DateUtil.getToday(Constants.DATETIME_FULL_FORMAT).concat(StringUtil.getRandString(2)).concat(".").concat(fileExt);

            CommFileUtil.putFile( sUploadPath, saveName, mFile.getBytes(), false);

            map.put("filePath", sUploadPath);
            map.put("fileName", fileName);
            map.put("saveName", saveName);
            map.put("fileSize", fileSize);
            map.put("fileExt", fileExt);

            fileList.add(map);

        }
        return fileList;
    }

}
