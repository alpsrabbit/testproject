/**
 *   
 */
package com.projectK.framework.resolver;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.MethodParameter;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.support.WebDataBinderFactory;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.method.support.ModelAndViewContainer;
import org.springframework.web.servlet.LocaleResolver;

import com.projectK.framework.annotation.ReqParam;
import com.projectK.framework.util.DataMap;
import com.projectK.framework.util.SessionUtil;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.web.servlet.i18n.SessionLocaleResolver;

/**
 * Request 에 대한 파라미터의 데이터 변환을 위한  HandlerMethodArgumentResolver 이다.
 * 
 * <p> 
 * <수정이력> <br /> 
 * 1. 수정일: 수정자: 수정사유: <br />
 * <p>
 * @since 2021. 7. 1.
 * @version 1.0
 * @author   
 */
@Component
public class CustomHandlerMethodArgumentResolver implements HandlerMethodArgumentResolver {
	private static final Logger logger = LoggerFactory.getLogger(CustomHandlerMethodArgumentResolver.class);

	@Override
	public boolean supportsParameter(MethodParameter param) {
		if(isDefaultParameter(param)){
			return true;
		}else return isExtendedParameter(param);
    }
	
	@Override
	public Object resolveArgument(MethodParameter param, ModelAndViewContainer arg1, NativeWebRequest nativeWebRequest, WebDataBinderFactory arg3) throws Exception {
		if(param.getParameterAnnotation(ReqParam.class) != null){
			return setCommMap((HttpServletRequest) nativeWebRequest.getNativeRequest());
		}
		return null;
	}
	
	private boolean isDefaultParameter(MethodParameter param) {
/*	  Class paramClass = param.getParameterType();
		if(HttpServletRequest.class.equals(paramClass)){
			return true;
		}else if(HttpServletResponse.class.equals(paramClass)){
			return true;
		}else{
		} */
		return false;
	}
	
	private boolean isExtendedParameter(MethodParameter param) {
		if(param.getParameterAnnotation(ReqParam.class) != null){
			return true;
		}else{
			// nothing.
		}
		return false;
	}
	
	/**
	 * Request 파라미터값을 스트링 또는 스트링배열로 변환한다.
	 * 
	 * @param request
	 * @return
	 * @throws Exception 
	 */
	public DataMap setCommMap(HttpServletRequest request) throws Exception {
		DataMap dataMap = new DataMap();
		
		try{
			String strMgrId = "";
			HttpSession session = request.getSession();
			try{
				strMgrId = SessionUtil.getSession(session).getString("mgr_id");
			}catch(Exception e){ } 
			
			if(!"".equals(strMgrId)){ 
				dataMap.put("upduser", strMgrId);
			}
			
			String sMethod = request.getMethod();
			
			Enumeration<?> names = request.getParameterNames();
			
			// Post 방식으로 넘어온 파라메터만 셋팅
			int iValuesLng = 0;
			String value = null;
			String req = request.getCharacterEncoding();
			String name = null;
			String[] values = null;
			
			if(req == null){req = "";}
			
			String strReqContentType = request.getContentType();
			
			if(sMethod != null){
				
				if(strReqContentType != null && strReqContentType.indexOf("application/json") > -1){
					
					BufferedReader br = request.getReader();
					StringBuffer sb = new StringBuffer();
					String strLine = null;
					
					while((strLine = br.readLine()) != null){
						sb.append(strLine);
					}
					
					br.close();
					
					ObjectMapper om = new ObjectMapper();
					DataMap dmapJson = om.readValue(sb.toString(), DataMap.class);
					dataMap.putAll(dmapJson);
				
				}else{

					while(names.hasMoreElements()){
						name = (String) names.nextElement();
						values = request.getParameterValues(name);
						
						if(values != null && values.length > 1){
							iValuesLng = values.length;
							
							//utf-8이 아닐경우 utf-8로 변환
							if(!req.equals("UTF-8")){
								for(int i=0;i<iValuesLng;i++){
									values[i] = getCharSet(values[i], "8859_1", "UTF-8");
								}
							}
							dataMap.put(name, values);
						}else{
							//utf-8이 아닐경우 utf-8로 변환
							if(!req.equals("UTF-8")){
								value = getCharSet(request.getParameter(name), "8859_1", "UTF-8");
							}else{
								value = request.getParameter(name);
							}
							dataMap.put(name, value);
						}
					}
				}
			} 

		}catch(Exception e){
			e.printStackTrace();
		}
		
		/*
		String userAgent = request.getHeader("User-Agent").toUpperCase();
		String strDeviceDiv = "Pw";
		if(userAgent.indexOf("MOBILE") > -1) {
			strDeviceDiv = "Mw";
		}
		dataMap.put("deviceDiv", strDeviceDiv);
		*/

		LocaleResolver localeResolver = new SessionLocaleResolver();

		String locale = localeResolver.resolveLocale(request).toString();
		logger.debug("locale >>>> [{}]", locale);

		dataMap.put("locale", locale);

		return dataMap;
	}
	
	/**
	 * Desc : chatset값
	 * @Method Name : getCharSet
	 * @param sText
	 * @param fromCharSet
	 * @param toCharSet
	 * @return
	 */
	public String getCharSet(String sText, String fromCharSet, String toCharSet) {
		String sResult = null;
		try{
			if(sText == null) return sResult;
			sResult = new String(sText.getBytes(fromCharSet),toCharSet);
			return sResult;
		}catch(Exception e) {
			return "";
		}
	}

	public static String getBody(HttpServletRequest request) throws IOException {
		String body = null;
		StringBuilder stringBuilder = new StringBuilder();
		BufferedReader bufferedReader = null;
 
		try{
			InputStream inputStream = request.getInputStream();
			if (inputStream != null) {
				bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
				char[] charBuffer = new char[128];
				int bytesRead = -1;
				while ((bytesRead = bufferedReader.read(charBuffer)) > 0){
					stringBuilder.append(charBuffer, 0, bytesRead);
				}
			}
		}catch(IOException e){
			throw e;
		}finally{
			if (bufferedReader != null){
				try {
					bufferedReader.close();
				}catch(IOException e){
					throw e;
				}
			}
		}
 
		body = stringBuilder.toString();
		return body;
	}
	
	/**
	 * Desc : 해당 입력 문구에 대하여 필터치리함
	 * @Method Name : getFilterString
	 * @param strInputValue
	 * @return
	 */
	public String getFilterString(String strInputValue) { 
		
		strInputValue = strInputValue.replaceAll("<", "& lt;").replaceAll(">", "& gt;");
		strInputValue = strInputValue.replaceAll("\\(", "& #40;").replaceAll("\\)", "& #41;");
		strInputValue = strInputValue.replaceAll("'", "& #39;");
		strInputValue = strInputValue.replaceAll("eval\\((.*)\\)", "");
		strInputValue = strInputValue.replaceAll("[\\\"\\'][\\s]*javascript:(.*)[\\\"\\']", "\"\"");
		
		strInputValue = strInputValue.replaceAll("iframe", "");
		strInputValue = strInputValue.replaceAll("script", "");
		strInputValue = strInputValue.replaceAll("eval", "");
		
		ArrayList<String> filterList = new ArrayList<String>();
		filterList.add("SELECT");
		filterList.add("UPDATE");
		filterList.add("INSERT");
		filterList.add("DELETE");
		filterList.add("CREATE");
		filterList.add("ALTER");
		filterList.add("CRTEAE");
		filterList.add("EXEC");
		
		for(int i = 0 ; i < filterList.size() ; i++){
			if(strInputValue.toUpperCase().contains(filterList.get(i))){
				strInputValue = strInputValue.replaceAll(filterList.get(i), "");
				strInputValue = strInputValue.replaceAll(filterList.get(i).toLowerCase(), "");
			}
		} 
		
		return strInputValue;
		
	}
}
