package com.projectK.framework.dao;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.projectK.framework.constant.Constants;
import com.projectK.framework.util.*;
import com.projectK.framework.vo.FileDownloadInputVO;
import org.apache.ibatis.session.ResultHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.projectK.framework.excel.BigExcelWriter;
import com.projectK.framework.excel.SpreadSheetWriter;
import com.projectK.framework.handler.ExcelMybatisRowHandler;
//import com.projectA.framework.service.CommPropertyService;

/**
*
* @ClassName   :  CommonExcelDAO
* @Description : 공통 데이터 접근 클래스
* @author 
* @since 2016. 7. 25.
* @version 1.0
* @see <pre>
* == 개정이력(Modification Information) ==
*
*       수정일          수정자                 수정내용
*  -----------    --------    -----------------------
*
* </pre>
*/
@Repository("commExcelDAO")
public class CommExcelDAO {
	
	private static final Logger logger = LoggerFactory.getLogger(CommExcelDAO.class);

	@Autowired
	private CommDAO commDAO;
	
    /**
     * Desc : 대량엑셀다운로드 처리
     * @Method Name : selectExcelDownload
     * @param strQueryId
     * @param DataMap
     * @param request
     * @param response
     * @param
     * @param
     * @throws Exception
     */
    public void selectExcelDownload(String strQueryId, DataMap DataMap, HttpServletRequest request, HttpServletResponse response) throws Exception {
        
        Writer fw = null;
        FileOutputStream out = null;
        
        String sFilePath = "";
        String sFileNm = "";
        String sFileTempNm = "";
        
//        String encKey = PropertyFileUtil.getString("db.encrypt.key");
//		String encIv = PropertyFileUtil.getString("db.encrypt.iv");

		String encKey = Constants.ENCRYPT_KEY;
		String encIv = Constants.ENCRYPT_IV;

		DataMap.put("encKey", encKey);
		DataMap.put("encIv", encIv);
		
		File tmp = null;
		
        try{
            // 임시업로드 경로
//            sFilePath = CommFileUtil.getExcelTmp(PropertyFileUtil.getString("file.path"));
			sFilePath = CommFileUtil.getExcelTmp(PropertyFileUtil.getString("file.path"));
			//String sFilePath = "/tmp/";
            // 파일명
            sFileNm = DataMap.getString("fileNm");
            // 임시경로 + 파일명
//            String sFileFullNm = sFilePath + sFileNm;
            // 임시경로 + xml변환용 템플릿
//            String sFileTempNm = "/fslog/kat_dev/katad2/web/excel/template.xlsx";
            sFileTempNm = sFilePath + "/template.xlsx";
            // 시트명
            String sSheetNm = DataMap.getString("sheetNm");

            String sFileExt = ".xlsx";
            
            String [] sTitle =  (String[]) DataMap.get("sTitle");
            
            if (!sFileNm.endsWith(".js") && !sFileNm.endsWith(".asp") && !sFileNm.endsWith(".jsp")) {
            
	            // 대용량 엑셀 컨트롤 클래스 호출
	            BigExcelWriter bigExcelWriter = new BigExcelWriter(sSheetNm, sFilePath, sFileTempNm);
	    
	            // xml타입을 위한 템플릿 파일 생성
	            tmp = File.createTempFile("sheet", ".xml");
//	            fw = new OutputStreamWriter(new FileOutputStream(tmp), propertiesService.getString("excel.charset")); //주석처리 2018.06.14
	            fw = new OutputStreamWriter(new FileOutputStream(tmp), StandardCharsets.UTF_8);
	                        
	            // 엑셀 row및 cell 관리하는 클래스 호출
	            SpreadSheetWriter sw = new SpreadSheetWriter(fw);
	            
	            // 시트만들기 시작
	            sw.beginSheet(sTitle);
	                        
	            // 타이틀 생성
	            bigExcelWriter.generateHeader(sFileNm, sTitle, "header", sw);
	            
	            ResultHandler resultHandler = new ExcelMybatisRowHandler(request, DataMap, bigExcelWriter, sw);
	
	            commDAO.selectLargeData(strQueryId, (DataMap)DataMap.get("param"), resultHandler);
	            
	            // 시트만들기 끝
	            sw.endSheet(sTitle.length);
	            fw.close();
	                        
	            // generated 데이터를 가지고 템플릿에 Substitute한다.
	            int idx = sFileNm.indexOf(".");
	            
	            if(idx > -1){
	            	sFileNm = sFileNm.substring(0, idx);
	            }

	            sFileNm = sFileNm.replaceAll("/", "");
	            sFileNm = sFileNm.replaceAll("\\\\", "");
	            sFileNm = sFileNm.replaceAll("[.]", "");
	            sFileNm = sFileNm.replaceAll("&", "");
	            
	            sFileNm = sFileNm + sFileExt;
	            
	            out = new FileOutputStream(sFilePath + sFileNm);
	            bigExcelWriter.substitute(new File(sFileTempNm), tmp, out);
	            out.close();
	                    
	            FileDownload fileDownload = new DirFileDownload();
	            
	            FileDownloadInputVO fileDownloadInputVO = new FileDownloadInputVO();
	            
	            fileDownloadInputVO.setsRealFileNm(sFileNm);
	            fileDownloadInputVO.setsFileNm(sFileNm);
	            fileDownloadInputVO.setsFilePath(sFilePath);
	            fileDownloadInputVO.setsFileFullNm(sFilePath + sFileNm);
	            fileDownloadInputVO.setlFileSize(CommFileUtil.getFileSize(sFilePath, sFileNm));
	            
	            logger.info("sFileNm : " + sFileNm);
	            logger.info("sFilePath : " + sFilePath);
	            logger.info("size : " + CommFileUtil.getFileSize(sFilePath, sFileNm));
	            
	            fileDownload.excutefileDownload(request, response, fileDownloadInputVO);
            }
        }catch(Exception e){
            e.printStackTrace();
            if(out != null) out.close();
        }finally {
        	// 파일다운로드후 파일삭제
            CommFileUtil.deleteFile(sFilePath, sFileNm);
            // 템플릿파일 삭제
            CommFileUtil.deleteFile(sFileTempNm);
            
            if(tmp.exists()) tmp.delete();
		}
    }

    /**
     * 웹용 대량엑셀다운로드 - 쿼리ID 실행이 아닌 가공한 데이터를 사용해 다운로드 해야 하는 경우
     * @param strQueryId
     * @param DataMap
     * @param request
     * @param response
     * @throws Exception
     */
	public void selectExcelDownloadListMake(String strQueryId, DataMap DataMap, HttpServletRequest request, HttpServletResponse response) throws Exception {
        
        Writer fw = null;
        FileOutputStream out = null;
        
        try{
        	
            // 임시업로드 경로
            String sFilePath = CommFileUtil.getExcelTmp(PropertyFileUtil.getString("file.path"));
            //String sFilePath = "/tmp/";
            // 파일명
            String sFileNm = DataMap.getString("fileNm");
            // 임시경로 + 파일명
//            String sFileFullNm = sFilePath + sFileNm;
            // 임시경로 + xml변환용 템플릿
//            String sFileTempNm = "/fslog/kat_dev/katad2/web/excel/template.xlsx";
            String sFileTempNm = sFilePath + "/template.xlsx";
            // 시트명
            String sSheetNm = DataMap.getString("sheetNm");

            String sFileExt = ".xlsx";
            
            logger.info(" 196 line pcMap ===> " + DataMap);
            String [] sTitle =  (String[]) DataMap.get("sTitle");
            String [] sTitleField =  (String[]) DataMap.get("sTitleField");
            
            if (!sFileNm.endsWith(".js") && !sFileNm.endsWith(".asp") && !sFileNm.endsWith(".jsp")) {
            
	            // 대용량 엑셀 컨트롤 클래스 호출
	            BigExcelWriter bigExcelWriter = new BigExcelWriter(sSheetNm, sFilePath, sFileTempNm);
	    
	            // xml타입을 위한 템플릿 파일 생성
	            File tmp = File.createTempFile("sheet", ".xml");
//	            fw = new OutputStreamWriter(new FileOutputStream(tmp), propertiesService.getString("excel.charset")); //주석처리 2018.06.14
	            fw = new OutputStreamWriter(new FileOutputStream(tmp), StandardCharsets.UTF_8);
	                        
	            // 엑셀 row및 cell 관리하는 클래스 호출
	            SpreadSheetWriter sw = new SpreadSheetWriter(fw);
	            
	            // 시트만들기 시작
	            sw.beginSheet(sTitle);
	            
	            logger.info("stitle ===> " + sTitle);
	            for(int k = 0; k < sTitle.length; k++) {
	            	logger.info("stitle[] ===> " + sTitle[k]);
	            }
                
			    // 타이틀 생성
			    bigExcelWriter.generateHeader(sFileNm, sTitle, "header", sw);
                
			    int iTitleField = sTitleField.length;
			    String[] sStyleType = (String[]) DataMap.get("sStyleType");
			    
			    // 엑셀에 집어 넣을 목록 데이터 조회
			    List<DataMap> listData = (List<DataMap>) DataMap.get("list");
			    logger.info("listData ===> " + listData);
	            
	            int iAutoCnt = listData.size();
	            
	            for(int iRowNum=0; iRowNum<iAutoCnt; iRowNum++){
	            	
	            	// 화면에서 넘긴 DB필드로 로우 데이터 세팅
	            	for(int fieldCnt = 0; fieldCnt < sTitleField.length; fieldCnt++) {
		            	DataMap.put(sTitleField[fieldCnt], listData.get(iRowNum).getString(sTitleField[fieldCnt]));
	            	}
	            	
	            	logger.info("iRowNum ===> ["+iRowNum+"]"+ listData.get(iRowNum));
	            	 
	            	bigExcelWriter.generateContent(request, iTitleField, sTitleField, (iRowNum+3), DataMap, sStyleType, sw);
	            	
	            }
	            
	            // 시트만들기 끝
	            sw.endSheet(sTitle.length);
	            fw.close();
	                        
	            // generated 데이터를 가지고 템플릿에 Substitute한다.
	            int idx = sFileNm.indexOf(".");
	            
	            if(idx > -1){
	            	sFileNm = sFileNm.substring(0, idx);
	            }

	            sFileNm = sFileNm.replaceAll("/", "");
	            sFileNm = sFileNm.replaceAll("\\\\", "");
	            sFileNm = sFileNm.replaceAll("[.]", "");
	            sFileNm = sFileNm.replaceAll("&", "");
	            
	            sFileNm = sFileNm + sFileExt;
	            
	            out = new FileOutputStream(sFilePath + sFileNm);
	            bigExcelWriter.substitute(new File(sFileTempNm), tmp, out);
	            out.close();
	                    
	            FileDownload fileDownload = new DirFileDownload();
	            
	            FileDownloadInputVO fileDownloadInputVO = new FileDownloadInputVO();
	            
	            fileDownloadInputVO.setsRealFileNm(sFileNm);
	            fileDownloadInputVO.setsFileNm(sFileNm);
	            fileDownloadInputVO.setsFilePath(sFilePath);
	            fileDownloadInputVO.setsFileFullNm(sFilePath + sFileNm);
	            fileDownloadInputVO.setlFileSize(CommFileUtil.getFileSize(sFilePath, sFileNm));
	            
	            logger.info("sFileNm : " + sFileNm);
	            logger.info("sFilePath : " + sFilePath);
	            logger.info("size : " + CommFileUtil.getFileSize(sFilePath, sFileNm));
	            
	            fileDownload.excutefileDownload(request, response, fileDownloadInputVO);
	                        
	            // 파일다운로드후 파일삭제
	            CommFileUtil.deleteFile(sFilePath, sFileNm);
	            // 템플릿파일 삭제
	            CommFileUtil.deleteFile(sFileTempNm);
            }
        }catch(Exception e){
            e.printStackTrace();
            if(out != null) out.close();
        }
	}    
    
}
