package com.projectK.framework.dao;

import java.util.HashMap;
import java.util.List;

import com.projectK.framework.util.DataMap;
import org.apache.ibatis.session.ResultHandler;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


/**
*
* @ClassName   :  CommonDAO
* @Description : 공통 데이터 접근 클래스
* @author 
* @since 2016. 7. 25.
* @version 1.0
* @see <pre>
* == 개정이력(Modification Information) ==
*
*       수정일          수정자                 수정내용
*  -----------    --------    -----------------------
*
* </pre>
*/
@Repository("commDAO")
public class CommDAO {

	@Autowired
    SqlSessionTemplate sqlSession;
	
	public DataMap selectByDataMap(String queryId, Object parameterObject) {
    	return sqlSession.selectOne(queryId, parameterObject);
    }
	
    public Object selectByPk(String queryId) {
        return sqlSession.selectOne(queryId);
    }
	
	public Object selectByPk(String queryId, Object parameterObject) {
        return sqlSession.selectOne(queryId, parameterObject);
    }
	
	public List<DataMap> selectList(String strQueryId, Object parameterObject) throws Exception {
		
		return sqlSession.selectList(strQueryId, parameterObject);
	}
	
    public List<DataMap> selectList(String strQueryId, DataMap DataMap) throws Exception {

        return sqlSession.selectList(strQueryId, DataMap);
    }

    public List<DataMap> selectList(String strQueryId) throws Exception {

        return sqlSession.selectList(strQueryId);
    }
    
    public List<String> selectListStr(String strQueryId, DataMap DataMap) throws Exception {
        
        return sqlSession.selectList(strQueryId, DataMap);
    }
    
    public List<String> selectListStr(String strQueryId) throws Exception {

        return sqlSession.selectList(strQueryId);
    }

    public int insert(String strQueryId, DataMap DataMap) throws Exception {
        
        return sqlSession.insert(strQueryId, DataMap);
    }

    public int delete(String strQueryId) {
        
        return sqlSession.delete(strQueryId);
    }    
    
    public int delete(String strQueryId, DataMap DataMap) throws Exception {
        
        return sqlSession.delete(strQueryId, DataMap);
    }

    public int update(String strQueryId, DataMap DataMap) throws Exception {

        return sqlSession.update(strQueryId, DataMap);
    }

    public void selectLargeData(String strQueryId, DataMap DataMap, ResultHandler resultHandler) throws Exception {
        
    	sqlSession.select(strQueryId, DataMap, resultHandler);
    }
	
    public List<HashMap<String,Object>> selectListByHashMap(String strQueryId, DataMap DataMap) throws Exception {
        return sqlSession.selectList(strQueryId, DataMap);
    }
    
	public HashMap<String,Object> selectByHashMap(String queryId, Object parameterObject) {
    	return sqlSession.selectOne(queryId, parameterObject);
    }
    
}
