/**
 *
 */
package com.projectK.framework.vo;

import java.io.Serializable;

import com.projectK.framework.util.DataMap;
import com.projectK.framework.util.StringUtil;
import net.sf.json.JSONObject;

/**
 * Result VO Entity 선언 Class
 *
 * <p>
 * <수정이력> <br />
 * 1. 수정일: 수정자: 수정사유: <br />
 * <p>
 * @since 2021. 7. 1.
 * @version 1.0
 * @author
 */
public class ResultVO implements Serializable{

	private static final long serialVersionUID = 4492729647685028740L;

	private int errorCode;
	private String errorMsg = "";
	private Object resultData = null;

	public ResultVO(){ }

	public ResultVO(int errorCode, String errorMsg) {
		this.errorCode = errorCode;
		this.errorMsg = StringUtil.sNull(errorMsg);
	}

	public ResultVO(int errorCode, String errorMsg, Object resultData) {
		this.errorCode = errorCode;
		this.errorMsg = StringUtil.sNull(errorMsg);
		this.resultData = resultData;
	}

	public ResultVO(DataMap dataMap){
		this.errorCode = (int)dataMap.get("errorCode");
		this.errorMsg = dataMap.getString("errorMsg");

		if (dataMap.containsKey("resultData")){
			this.resultData = dataMap.get("resultData");
		}
	}

	public int getErrorCode(){
		return errorCode;
	}

	public void setErrorCode(int errorCode){
		this.errorCode = errorCode;
	}

	public String getErrorMsg(){
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg){
		this.errorMsg = errorMsg;
	}

	public Object getResultData() {
		return resultData;
	}

	public void setResultData(Object resultData){
		this.resultData = resultData;
	}

	@Override
	public String toString(){
		JSONObject jObj = new JSONObject();
		try {
			jObj.put("errorCode", errorCode);
			jObj.put("errorMsg", errorMsg);
			if (resultData != null) {
				jObj.put("resultData", resultData);
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return jObj.toString();
	}

	public DataMap getDataMap(){
		DataMap dataMap = new DataMap();
		dataMap.put("errorCode", errorCode);
		dataMap.put("errorMsg", errorMsg);

		if(resultData != null){
			dataMap.put("resultData", resultData);
		}

		return dataMap;
	}

}
