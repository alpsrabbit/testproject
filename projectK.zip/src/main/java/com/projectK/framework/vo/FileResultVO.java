package com.projectK.framework.vo;

/**
 * 파일결과를 담는 VO
 * @author
 * @since 2012. 8. 8.
 * @see
 * <pre>
 * == 개정이력(Modification Information) ==
 *
 * 수정일              수정자                 수정내용
 * ------------        ---------------        ---------------------------
 * </pre>
 */
public class FileResultVO {

	// 저장된 파일명
	private String sFileNm = null;
	// 절대파일경로
	private String sRootPath = null;
	// 파일경로(기본경로 제외)
	private String sFilePath = null;
	//파일전체경로
	private String sFileFullPath;
	// 실제 파일명
	private String sRealFileNm = null;
	// 확장자명
	private String sExtensionNm = null;
	// 파일타입
	private String sFileType = null;
	// 썸네일여부
	private String sThumbnailYn = null;
	// 파일사이즈(크기)
	private long lFileSize;

	public String getsFileNm() {
		return sFileNm;
	}

	public void setsFileNm(String sFileNm) {
		this.sFileNm = sFileNm;
	}

	public String getsRootPath() {
		return sRootPath;
	}

	public void setsRootPath(String sRootPath) {
		this.sRootPath = sRootPath;
	}
	
	public String getsFilePath() {
		return sFilePath;
	}
	
	public void setsFilePath(String sFilePath) {
		this.sFilePath = sFilePath;
	}
	public String getsFileFullPath() {
		return sFileFullPath;
	}

	public void setsFileFullPath(String sFileFullPath) {
		this.sFileFullPath = sFileFullPath;
	}
	public String getsRealFileNm() {
		return sRealFileNm;
	}

	public void setsRealFileNm(String sRealFileNm) {
		this.sRealFileNm = sRealFileNm;
	}

	public String getsExtensionNm() {
		return sExtensionNm;
	}

	public void setsExtensionNm(String sExtensionNm) {
		this.sExtensionNm = sExtensionNm;
	}
	public String getsFileType() {
		return sFileType;
	}

	public void setsFileType(String sFileType) {
		this.sFileType = sFileType;
	}
	public String getsThumbnailYn() {
		return sThumbnailYn;
	}

	public void setsThumbnailYn(String sThumbnailYn) {
		this.sThumbnailYn = sThumbnailYn;
	}
	public long getlFileSize() {
		return lFileSize;
	}

	public void setlFileSize(long lFileSize) {
		this.lFileSize = lFileSize;
	}
	
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("FileResultVO [");
		if (sFileNm != null) {
			builder.append("sFileNm=");
			builder.append(sFileNm);
			builder.append(", ");
		}
		if (sRootPath != null) {
			builder.append("sRootPath=");
			builder.append(sRootPath);
			builder.append(", ");
		}
		if (sFilePath != null) {
			builder.append("sFilePath=");
			builder.append(sFilePath);
			builder.append(", ");
		}
		if (sFileFullPath != null) {
			builder.append("sFileFullPath=");
			builder.append(sFileFullPath);
			builder.append(", ");
		}
		if (sRealFileNm != null) {
			builder.append("sRealFileNm=");
			builder.append(sRealFileNm);
			builder.append(", ");
		}
		if (sExtensionNm != null) {
			builder.append("sExtensionNm=");
			builder.append(sExtensionNm);
			builder.append(", ");
		}
		if (sFileType != null) {
			builder.append("sFileType=");
			builder.append(sFileType);
			builder.append(", ");
		}
		if (sThumbnailYn != null) {
			builder.append("sThumbnailYn=");
			builder.append(sThumbnailYn);
			builder.append(", ");
		}
		builder.append("lFileSize=");
		builder.append(lFileSize);
		builder.append("]");
		return builder.toString();
	}

}
