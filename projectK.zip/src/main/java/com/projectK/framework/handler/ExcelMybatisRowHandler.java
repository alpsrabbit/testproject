package com.projectK.framework.handler;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.ResultContext;
import org.apache.ibatis.session.ResultHandler;

import com.projectK.framework.util.DataMap;
import com.projectK.framework.excel.SpreadSheetWriter;
import com.projectK.framework.excel.BigExcelWriter;
import com.projectK.framework.util.CommEncryptUtil;

 /**
 * @ClassName   :  NexacroExcelMybatisRowHandler
 * @Description : 대량엑셀다운로드 핸들러
 * @author 김병찬
 * @since 2016. 10. 31.
 * @version 1.0
 * @see <pre>
 * == 개정이력(Modification Information) ==
 *
 *       수정일          수정자                 수정내용
 *  -----------    --------    -----------------------
 *   2016. 10. 31.    김병찬                 최초 생성
 *
 * </pre>
 */
public class ExcelMybatisRowHandler implements ResultHandler {
    
    protected DataMap dataMap = null;
    
    protected String[] sStyleType;        // 셀 스타일
    protected int iRowNum = 3;            // 엑셀 등록 로우번호
    protected int iTitleField;            // 타이틀 갯수
    protected String[] sTitleField;       // 타이틀이 담긴 배열
    protected String[] sMaskingArray = null;       // 마스킹정보 배열
    protected String[] sDecryptArray;       // 복호화정보 배열
    protected SpreadSheetWriter sw;
    
    protected BigExcelWriter bigExcelWriter;
    protected HttpServletRequest request;
    
    protected String encKey = "";
	protected String encIv = "";
    
    public ExcelMybatisRowHandler(HttpServletRequest request, DataMap dataMap, BigExcelWriter bigExcelWriter, SpreadSheetWriter sw) {
        this.request = request;
        this.bigExcelWriter = bigExcelWriter;
        this.sw = sw;
        
        sTitleField = (String[]) dataMap.get("sTitleField");
        iTitleField = sTitleField.length;
        sStyleType = (String[]) dataMap.get("sStyleType");
        encKey = dataMap.getString("encKey");
        encIv = dataMap.getString("encIv");
        
        //마스킹처리======================
        DataMap param = (DataMap)dataMap.get("param");
        if(param.get("masking") != null && !"".equals(param.getString("masking"))) {
        	sMaskingArray = param.getString("masking").split("\\|");
        }
        //마스킹처리======================

        //복호화처리======================
        if(param.get("decrypt") != null && !"".equals(param.getString("decrypt"))) {
        	sDecryptArray = param.getString("decrypt").split("\\|");
        }
        //복호화처리======================
    }

    public void handleResult(ResultContext context) {
        
    	dataMap = (DataMap) context.getResultObject();
    	
    	//복호화처리======================
    	if(sDecryptArray != null && sDecryptArray.length > 0) {
    		
    		String strDecResult = "";
    		
			for(int i=0; i<sDecryptArray.length; i++){
				
    			try {
    				if(!"".equals(dataMap.getString(sDecryptArray[i]))) {
    					strDecResult = CommEncryptUtil.aesDecrypt(dataMap.getString(sDecryptArray[i]), encKey, encIv);
    					dataMap.put(sDecryptArray[i], strDecResult);
    				}
    			} catch (Exception e) {
    				e.printStackTrace();
    				dataMap.put(sDecryptArray[i], "복호화 오류");
    			}
			}
    	}
    	//복호화처리======================

//    	//마스킹처리======================
//    	if(sMaskingArray != null && sMaskingArray.length > 0) {
//    		for(int i=0; i<sMaskingArray.length; i++){
//    			String[] dataArray = sMaskingArray[i].split(":");
//    			dataMap.put(dataArray[0], MaskingUtil.masking((String)dataMap.get(dataArray[0]), dataArray[1]));
//    		}
//    	}
//    	//마스킹처리======================
    	
        try {
            bigExcelWriter.generateContent(request, iTitleField, sTitleField, iRowNum, dataMap, sStyleType, sw);
            
            dataMap.clear();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        iRowNum++;
    }
    
    

}
