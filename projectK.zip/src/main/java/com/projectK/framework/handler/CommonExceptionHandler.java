/**
 *   
 */
package com.projectK.framework.handler;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.ModelAndView;

import com.projectK.framework.constant.Constants;
import com.projectK.framework.exception.CommonException;
import com.projectK.framework.util.StringUtil;
import com.projectK.framework.vo.ResultVO;

/**
 * Common Exception Handler Class
 * 
 * <p> 
 * <수정이력> <br /> 
 * 1. 수정일: 수정자: 수정사유: <br />
 * <p>
 * @since 2021. 7. 1.
 * @version 1.0
 * @author   
 */
@ControllerAdvice
public class CommonExceptionHandler {
	private static final Logger logger = LoggerFactory.getLogger(CommonExceptionHandler.class);
	
	@ExceptionHandler(Exception.class)
	public ModelAndView defaultErrorHandler(HttpServletRequest request, HttpServletResponse response, Exception ex) throws Exception {
		logger.info("CommonExceptionHandler defaultErrorHandler - s");
		
		ResultVO resultVO = null;
		
		ModelAndView mav = new ModelAndView();
		if(AnnotationUtils.findAnnotation(ex.getClass(), ResponseStatus.class) != null){
			ResponseStatus rs = AnnotationUtils.findAnnotation(ex.getClass(), ResponseStatus.class);
			if((request.getHeader("Accept") != null && request.getHeader("Accept").contains(Constants.HEADER_ACCEPT_APPLICATION_JSON)) ||
			   (request.getContentType() != null && request.getContentType().contains(Constants.HEADER_ACCEPT_APPLICATION_JSON))
			  ){
				if(HttpStatus.NOT_FOUND.equals(rs.value())){
					resultVO = new ResultVO(-404, "(Annotation) 잘못된 URL에 접근하였습니다.");
					mav.getModelMap().put("jsonString", resultVO.toString());
					mav.setViewName("/error/errJson");
					response.setStatus(HttpStatus.NOT_FOUND.value());
				}else if(HttpStatus.SERVICE_UNAVAILABLE.equals(rs.value())){
					resultVO = new ResultVO(-503, "(Annotation) 시스템의 일시적인 장애가 발생하였습니다.");
					mav.getModelMap().put("jsonString", resultVO.toString());
					mav.setViewName("/error/errJson");
					response.setStatus(HttpStatus.SERVICE_UNAVAILABLE.value());
				}
			}else{
				if(HttpStatus.NOT_FOUND.equals(rs.value())){
					resultVO = new ResultVO(-404, "(Annotation) defaultErrorHandler");
					response.setStatus(HttpStatus.NOT_FOUND.value());
					mav.setViewName("error/err404");
				}else if(HttpStatus.SERVICE_UNAVAILABLE.equals(rs.value())){
					resultVO = new ResultVO(-503, "(Annotation) defaultErrorHandler");
					response.setStatus(HttpStatus.SERVICE_UNAVAILABLE.value());
					mav.setViewName("error/err503");
				}
			}
		}

		if((request.getHeader("Accept") != null && request.getHeader("Accept").contains(Constants.HEADER_ACCEPT_APPLICATION_JSON)) || 
		   (request.getContentType() != null && request.getContentType().contains(Constants.HEADER_ACCEPT_APPLICATION_JSON))
		  ){
			if(ex instanceof CommonException){
				if(((CommonException) ex).getErrorCode() == -9999){
					resultVO = new ResultVO(-9999, ((CommonException) ex).getErrorMsg());
					mav.getModelMap().put("jsonString", resultVO.toString());
					mav.setViewName("/error/errJson");
					response.setStatus(HttpStatus.UNAUTHORIZED.value());
				}else if(((CommonException) ex).getErrorCode() == -404){
					resultVO = new ResultVO(-404, "잘못된 URL에 접근하였습니다.");
					mav.getModelMap().put("jsonString", resultVO.toString());
					mav.setViewName("/error/errJson");
					response.setStatus(HttpStatus.NOT_FOUND.value());
				}else if(((CommonException) ex).getErrorCode() == -503){
					resultVO = new ResultVO(-503, "시스템의 일시적인 장애가 발생하였습니다.");
					mav.getModelMap().put("jsonString", resultVO.toString());
					mav.setViewName("/error/errJson");
					response.setStatus(HttpStatus.SERVICE_UNAVAILABLE.value());
				}else if(((CommonException) ex).getErrorCode() == -1){ 
					resultVO = new ResultVO(-1, ((CommonException) ex).getErrorMsg());
					mav.getModelMap().put("jsonString", resultVO.toString());
					mav.setViewName("/error/errJson");
				}else{
					resultVO = new ResultVO(-500, "시스템 오류가 발생하였습니다. 다시한번 확인하여 주세요.");
					mav.getModelMap().put("jsonString", resultVO.toString());
					mav.setViewName("/error/errJson");
					response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());						
				}
			}else{
				resultVO = new ResultVO(-500, "시스템 오류가 발생하였습니다. 다시한번 확인하여 주세요.");
				mav.getModelMap().put("jsonString", resultVO.toString());
				mav.setViewName("/error/errJson");
				response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
			}
		}else{
			if(ex instanceof CommonException){
				if(((CommonException) ex).getErrorCode() == -9999){
					resultVO = new ResultVO(-500, "(CommonException) sessionInvalidate");
					mav.setViewName("/error/sessionInvalidate"); // 웹 접근시
				}else{
					resultVO = new ResultVO(-500, "(CommonException) defaultErrorHandler No Json");
					response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
					mav.setViewName("error/err500");						
				}
            }else{
				resultVO = new ResultVO(-500, "defaultErrorHandler No Json");
				response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
				mav.setViewName("error/err500");
			}
		}
		
		if(resultVO != null){
			logger.error("CommonExceptionHandler defaultErrorHandler :" + resultVO);
		}
		
		logger.error(StringUtil.getPrintStackTrace(ex));
		
		logger.info("CommonExceptionHandler defaultErrorHandler - e");
		return mav;
	}
	
}
