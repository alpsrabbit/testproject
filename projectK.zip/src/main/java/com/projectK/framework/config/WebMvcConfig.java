/**
 *   
 */
package com.projectK.framework.config;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import com.projectK.framework.interceptor.SessionInterceptor;
import com.projectK.framework.resolver.CustomHandlerMethodArgumentResolver;
import org.apache.catalina.Context;
import org.apache.tomcat.util.scan.StandardJarScanFilter;
import org.apache.tomcat.util.scan.StandardJarScanner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.util.StringUtils;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.i18n.LocaleChangeInterceptor;
import org.springframework.web.servlet.i18n.SessionLocaleResolver;
import org.springframework.web.servlet.view.json.MappingJackson2JsonView;

//import com.itku.makeblacklist.common.interceptor.SessionInterceptor;
//import com.itku.makeblacklist.framework.resolver.CustomHandlerMethodArgumentResolver;

/**
 * Web Mvc 관련 Config
 * 
 * <p> 
 * <수정이력> <br /> 
 * 1. 수정일: 수정자: 수정사유: <br />
 * <p>
 * @since 2021. 7. 1.
 * @version 1.0
 * @author   
 */
@Configuration
public class WebMvcConfig implements WebMvcConfigurer {

	@Autowired
	private CustomHandlerMethodArgumentResolver customHandlerMethodArgumentResolver;

	@Value("${spring.webservice.intro}")
	private String introPage;

	/* 
	 * xml : spring-servlet.xml
	 * Request 에 대한 파라미터의 데이터 변환을 위한  HandlerMethodArgumentResolver Config
	 * 
	 * @since 2021. 7. 1.
	 * @see org.springframework.web.servlet.config.annotation.WebMvcConfigurer#addArgumentResolvers(java.util.List)
	 * @param argumentResolvers 
	 * @author   
	 */
	@Override
	public void addArgumentResolvers(List<HandlerMethodArgumentResolver> argumentResolvers) {
		argumentResolvers.add(customHandlerMethodArgumentResolver);
	}
	
	/* 
	 * xml : spring-servlet.xml
	 * Add Interceptor
	 * - Session Interceptor
	 * - 언어 변경을 위한 Interceptor
	 * 
	 * @since 2021. 7. 1.
	 * @see org.springframework.web.servlet.config.annotation.WebMvcConfigurer#addInterceptors(org.springframework.web.servlet.config.annotation.InterceptorRegistry)
	 * @param registry 
	 * @author   
	 */
	@Override
	public void addInterceptors(InterceptorRegistry registry){
		registry.addInterceptor(sessionInterceptor())
		.addPathPatterns("/**/*.do");
		
		registry.addInterceptor(localeChangeInterceptor());
	}

	@Bean
	public SessionInterceptor sessionInterceptor() {
		return new SessionInterceptor();
	}

	@Override
	public void addViewControllers(ViewControllerRegistry registry) {
		registry.addRedirectViewController("/", introPage);
	}
	
	/* PropertiesConfig - s */
	
	/**
	 * 메세지 소스를 생성한다.
	 * 
	 * @since 2021. 7. 1.
	 * @author   
	 * @return 
	 */
	@Bean
	public ReloadableResourceBundleMessageSource messageSource() {
		ReloadableResourceBundleMessageSource source = new ReloadableResourceBundleMessageSource();
		source.setBasename("classpath:/properties/message");
		source.setDefaultEncoding("UTF-8");	    // 기본 인코딩을 지정한다.
		source.setCacheSeconds(30);			    // 프로퍼티 파일의 변경을 감지할 시간 간격을 지정한다.
		source.setUseCodeAsDefaultMessage(true); // 없는 메세지일 경우 예외를 발생시키는 대신 코드를 기본 메세지로 한다.

		Locale.setDefault(Locale.KOREA);
		return source;
	}
	
	/**
	 * 변경된 언어 정보를 기억할 로케일 리졸버를 생성한다.
	 * 여기서는 세션에 저장하는 방식을 사용한다.
	 * 
	 * @since 2021. 7. 1.
	 * @author   
	 * @return 
	 */
	@Bean
	public SessionLocaleResolver localeResolver() {
		SessionLocaleResolver slr = new SessionLocaleResolver();
		slr.setDefaultLocale(Locale.KOREA);
		return slr;
	}
	
	/**
	 * 언어 변경을 위한 인터셉터를 생성한다.
	 * 
	 * @since 2021. 7. 1.
	 * @author   
	 * @return 
	 */
	@Bean
	public LocaleChangeInterceptor localeChangeInterceptor() {
		LocaleChangeInterceptor interceptor = new LocaleChangeInterceptor();
		interceptor.setParamName("lang");
		return interceptor;
	}
	
	/* PropertiesConfig - e */
	
	/**
	 * xml : spring-servlet.xml
	 * Controller에서 return할 ModelAndView를 생성 할 때 View를 "jsonView"로 설정하면  json 형식으로 반환된다.
	 * ModelAndView mv = new ModelAndView("jsonView");
	 * mv.addObject("data", userList);
	 * 
	 * @since 2021. 7. 1.
	 * @author   
	 * @return 
	 */
	@Bean
	public MappingJackson2JsonView jsonView() {
		return new MappingJackson2JsonView();
	}
	
	/**
	 *
	 * @since 2021. 7. 1.
	 * @author
	 * @return
	 */

	@Bean
    public TomcatServletWebServerFactory tomcatFactory() {
        return new TomcatServletWebServerFactory() {
            @Override
            protected void postProcessContext(Context context) {
      	        ((StandardJarScanner) context.getJarScanner()).setScanManifest(false);

                Set<String> pattern = new LinkedHashSet<>();
                //pattern.add("jstl*.jar");
                //pattern.add("spring-webmvc*.jar");
                StandardJarScanFilter filter = new StandardJarScanFilter();
                filter.setTldSkip(StringUtils.collectionToCommaDelimitedString(pattern));
                context.getJarScanner().setJarScanFilter(filter);
            }
        };
    }

}
