package com.projectK.framework.config;

import com.projectK.framework.constant.Constants;
import com.projectK.framework.util.PropertyFileUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.FileInputStream;
import java.util.Properties;

/**
 * 실시간 properties file read
 */
@Component
public class PropertyLoader {
    private static final Logger logger = LoggerFactory.getLogger(PropertyLoader.class);

    public static Properties getProperties(String filePath) {
        Properties prop = new Properties();

        FileInputStream fis = null;
        try {
            fis = new FileInputStream(filePath);

            prop.load(fis);
        } catch ( Exception e ) {
            logger.info("Property File loading Fail >>>> [{}]", filePath);
            prop = PropertyFileUtil.getProperties(Constants.configFile);
        } finally {
            if ( fis != null ) {
                try{fis.close();} catch ( Exception e) {}
            }
        }

        return prop;
    }

    public static Properties getProperties() {
        String filePath = "config/config.properties";

        return getProperties(filePath);
    }


}
