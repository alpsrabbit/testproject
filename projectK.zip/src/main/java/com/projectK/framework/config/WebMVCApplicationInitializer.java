/**
 *   
 */
package com.projectK.framework.config;

import javax.servlet.FilterRegistration;
import javax.servlet.ServletContext;
import javax.servlet.ServletContextListener;
import javax.servlet.ServletException;
import javax.servlet.ServletRegistration;

import org.springframework.web.WebApplicationInitializer;
import org.springframework.web.context.ContextLoaderListener;
import org.springframework.web.filter.CharacterEncodingFilter;
import org.springframework.web.servlet.DispatcherServlet;

/**
 * Web Mvc Application Initializer 관련 Config
 * 
 * <p> 
 * <수정이력> <br /> 
 * 1. 수정일: 수정자: 수정사유: <br />
 * <p>
 * @since 2021. 7. 1.
 * @version 1.0
 * @author   
 */
public class WebMVCApplicationInitializer implements WebApplicationInitializer {

	/* 
	 * 
	 * @since 2021. 10. 22.
	 * @see org.springframework.web.WebApplicationInitializer#onStartup(javax.servlet.ServletContext)
	 * @param servletContext
	 * @throws ServletException 
	 */
	@Override
	public void onStartup(ServletContext servletContext) throws ServletException {
		addRootContext(servletContext);
		addWebContext(servletContext);
		addFilters(servletContext);
	}
	
	/**
	 * 
	 * @since 2021. 7. 1.
	 * @param servletContext 
	 * @author   
	 */
	private void addRootContext(ServletContext servletContext) {
		ServletContextListener listener = new ContextLoaderListener();
		servletContext.addListener(listener);
	}
	
	/**
	 * 
	 * @since 2021. 7. 1.
	 * @param servletContext 
	 * @author   
	 */
	private void addWebContext(ServletContext servletContext) {
		ServletRegistration.Dynamic registration = servletContext.addServlet("dispatcher", new DispatcherServlet()); // new DispatcherServlet(appContext));
		registration.setLoadOnStartup(1);
		registration.addMapping("*.do");
	}
	
	/**
	 * 
	 * @since 2021. 7. 1.
	 * @param servletContext 
	 * @author   
	 */
	private void addFilters(ServletContext servletContext) {
		FilterRegistration.Dynamic characterEncoding = servletContext.addFilter("encodingFilter", new CharacterEncodingFilter());
		characterEncoding.setInitParameter("encoding", "UTF-8");
		characterEncoding.setInitParameter("forceEncoding", "true");
		characterEncoding.addMappingForUrlPatterns(null, false, "/*");
	}
	
}
