/**
 *   
 */
package com.projectK.framework.util;

import java.util.List;

import org.apache.commons.collections.map.ListOrderedMap;
//import org.apache.ibatis.type.Alias;

/**
 * Data Map 정의
 * 
 * <p> 
 * <수정이력> <br /> 
 * 1. 수정일: 수정자: 수정사유: <br />
 * <p>
 * @since 2021. 7. 1.
 * @version 1.0
 * @author   
 */
//@Alias("dataMap")
public class DataMap extends ListOrderedMap {
	
	private static final long serialVersionUID = 8782930361630966236L;
	
	String strImgKey = "";
	
	public DataMap() { }
	
	/** 
	 * 전달받은 맵에서 키값들만 복사 또는 설정 하는 생성자
	 * 
	 * new DataMap(new DataMap(), "key1,key2=222,key3=abc,key5=가나다")
	 * 
	 * @param params 복사할 맵
	 * @param keys 복사대상 key
	 */
	public DataMap(DataMap params, String keys) {
		if(params != null && keys != null){
			keys = keys.trim();
			if(!keys.equals("")){
				if(keys.contains(",")){
					for(String key : keys.split(",")){
						if(key.contains("=")) {
							String[] tmp = key.split("=");
							super.put(StringUtil.toCamelCase(tmp[0]), tmp[1]);
						}else{
							super.put(StringUtil.toCamelCase(key), params.getString(key));
						}
					}
				}else{
					if(keys.contains("=")){
						String[] tmp = keys.split("=");
						super.put(StringUtil.toCamelCase(tmp[0]), tmp[1]);
					}else{
						super.put(StringUtil.toCamelCase(keys), params.getString(keys));
					}
				}
			}
		}
	}

	/**
	 * key 에 대하여 super.put (ListOrderedMap) 을 호출한다.
	 *
	 * @param key '_' 가 포함된 변수명
	 * @param value 명시된 key 에 대한 값 (변경 없음)
	 * @return previous value associated with specified key, or null if there was no mapping for key
	 */
	@Override
	public Object put(Object key, Object value) {
		Object resultObject = null;
		resultObject = super.put(StringUtil.toCamelCase((String)key), value);
		return resultObject;
	}
	/**
	 * key에 해당하는 boolean 형의 값으로 리턴하며, null인 경우 false 로 바꾸는 메서드
	 */
	public boolean getBoolean(Object key) {
		try{
			return super.get(key).equals(true) || getString(key).equals("true");
		}catch(Exception e){
			return false;
		}
	}
	
	/**
	 * key에 해당하는 스트링 형의 값으로 리턴하며, null인 경우 "" 로 바꾸는 메서드
	 */	
	public String getString(Object key) {
		String string = "";
		Object object = super.get(key);		
		
		if(object != null){
			string = object.toString().trim();
		}
		return string;
	}
	
	/**
	 * key에 해당하는 int 형의 값으로 리턴하며, 예외상황 발생 시 0으로 리턴
	 */
	public int getInt(Object key) {
		try{
			return Integer.parseInt(this.getString(key));
		}catch(Exception e){
			return 0;
		}
	}

	/**
	 * key에 해당하는 int 형의 값으로 리턴하며, 예외상황 발생 시 -1으로 리턴
	 */
	public int getOrgInt(Object key) {
		try{
			return Integer.parseInt(this.getString(key));
		}catch(Exception e){
			return -1;
		}
	}

	/**
	 * key에 해당하는 long 형의 값으로 리턴하며, 예외상황 발생 시 0으로 리턴
	 */
	public long getLong(Object key) {
		try{
			return Long.parseLong(this.getString(key));
		}catch(Exception e){
			return 0;
		}
	}
	
	/**
	 * key에 해당하는 float 형의 값으로 리턴하며, 예외상황 발생 시 0.0으로 리턴
	 */
	public float getFloat(Object key) {
		try{
			return Float.parseFloat(this.getString(key));
		}catch(Exception e){
			return 0;
		}
	}
	
	/**
	 * key에 해당하는 double 형의 값으로 리턴하며, 예외상황 발생 시 0.0으로 리턴
	 */
	public double getDouble(Object key) {
		try{
			return Double.parseDouble(this.getString(key));
		}catch(Exception e){
			return 0;
		}
	}
	
	/**
	 * key에 해당하는 List 형으로 변환하여 리턴
	 */	
	public List<?> getList(Object key) {
		return  (List<?>)super.get(key);	
	}		
	
	public Object getKeyInt(Object key) {
		return super.get(key);
	}
	
}
