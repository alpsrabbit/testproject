/**
 *   
 */
package com.projectK.framework.util;

import java.io.File;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.Random;
import java.util.function.IntPredicate;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpServletRequest;

/**
 * 문자 관련 Common Util
 * 
 * <p> 
 * <수정이력> <br /> 
 * 1. 수정일: 수정자: 수정사유: <br />
 * <p>
 * @since 2021. 7. 1.
 * @version 1.0
 * @author   
 */
public class StringUtil {
	private static final Logger logger = LoggerFactory.getLogger(StringUtil.class);

	/*
	 * 참고
	 * 
	 * &nbsp;  " " : 공백(스페이스 한 칸)을 의미
	 * &lt;	      부등호(<)
	 * &gt;    부등호(>)
	 * &amp;   앰퍼샌드(&)
	 * &quot;  쌍따옴표(")
	 * &#035;  sharp(#)
	 * &#039;  따옴표(')
	 */
	
	/**
	 * 입력받은 문자열의 NULL 또는 빈 문자열을 체크 후 boolean 반환.
	 * - flag 값이 true 일 경우 공백제거 후 체크
	 * - flag 값이 false 일 경우 공백제거 없이 체크
	 * 
	 * StringUtil.isNull(null)      = true
	 * StringUtil.isNull("")        = true
	 * StringUtil.isNull("bob")     = false
	 * StringUtil.isNull("  bob  ") = false
	 * 
	 * true
	 * StringUtil.isNull(" ") = true
	 *  
	 * false
	 * StringUtil.isNull(" ") = false
	 * 
	 * @param str 입력받은 문자열
	 * @param flag 입력받은 문자열의 공백 제거 여부 (true:공백제거, false:원본 문자열)
	 * @return 
	 */
	public static boolean isNull(String str, boolean flag) {
		if(flag){
			return str == null || str.trim().length() == 0;
		}else{
			return str == null || str.length() == 0;
		}
	}

	/**
	 * 숫자 데이터만 추출
	 *
	 * StringUtil.numberChar(null)       = null;
	 * StringUtil.numberChar("")         = "";
	 * StringUtil.numberChar("a12a33'ad") = "1233"
	 *
	 * @param str 원본 문자열
	 * @return 변환 문자열
	 */
	public static String numberChar(String str) {
		if ( isEmpty(str) ) {
			return str;
		}
		if ( isNull(str) ) {
			return str;
		}
		int strLen = str.length();
		StringBuilder buff = new StringBuilder(strLen);
		for ( int ii = 0 ; ii < strLen ; ii++ ) {
			char chr = str.charAt(ii);
			if ( chr >= '0' && chr <= '9' ) {
				buff.append(chr);
			}

		}
		return buff.toString();
	}
	/**
	 * 숫자 데이터만 추출
	 *
	 * StringUtil.numberChar(null)       = null;
	 * StringUtil.numberChar("")         = "";
	 * StringUtil.numberChar("a12a33'ad") = "1233"
	 *
	 * @param str 원본 문자열
	 * @return 변환 문자열
	 */
	public static String numChar(String str) {
		if ( isEmpty(str) ) {
			return str;
		}
		if ( isNull(str) ) {
			return str;
		}
		int strLen = str.length();
		StringBuilder buff = new StringBuilder(strLen);
		for ( int ii = 0 ; ii < strLen ; ii++ ) {
			char chr = str.charAt(ii);
			if ( chr >= '0' && chr <= '9' ) {
				buff.append(chr);
			} else if ( chr == '.' ) {
				buff.append(chr);
			}

		}
		return buff.toString();
	}
	
	/**
	 * 입력받은 문자열의 NULL 또는 빈 문자열을 체크 후 boolean 반환.
	 * - 공백제거 없이 체크
	 * 
	 * StringUtil.isNull(null)      = true
	 * StringUtil.isNull("")        = true
	 * StringUtil.isNull("bob")     = false
	 * StringUtil.isNull("  bob  ") = false
	 * StringUtil.isNull(" ")       = false
	 * 
	 * @param str
	 * @return 
	 */
	public static boolean isEmpty(String str){
		return isNull(str, false);
	}
	
	/**
	 * 입력받은 문자열의 NULL 또는 빈 문자열을 체크 후 boolean 반환.
	 * - 공백제거 후 체크
	 * 
	 * StringUtil.isNull(null)      = true
	 * StringUtil.isNull("")        = true
	 * StringUtil.isNull("bob")     = false
	 * StringUtil.isNull("  bob  ") = false
	 * StringUtil.isNull(" ")       = true
	 * 
	 * @param str
	 * @return 
	 */
	public static boolean isNull(String str){
		return isNull(str, true);
	}
	
	/**
	 * 입력받은 객체의 NULL 또는 빈 객체를 체크 후 boolean 반환.
	 * - 공백제거 후 체크
	 * 
	 * StringUtil.isNull(null)      = true
	 * StringUtil.isNull("")        = true
	 * StringUtil.isNull("bob")     = false
	 * StringUtil.isNull("  bob  ") = false
	 * StringUtil.isNull(" ")       = true
	 * 
	 * @param obj
	 * @return 
	 */
	public static boolean isNull(Object obj){
		return StringUtil.sNull(obj).length() == 0;
	}
	
	/**
	 * 입력받은 문자열이 NULL 인 경우 빈값("")으로 치환 후 반환.
	 * - flag 값이 true 일 경우 좌우 공백제거 후 체크
	 *   빈값이 아닐 경우 입력받은 문자열의 좌우 공백을 제거하고 반환.
	 * - flag 값이 false 일 경우 좌우 공백제거 없이 체크 
	 *   빈값이 아닐 경우 입력받은 문자열을 그대로 반환.
	 * 
	 * StringUtil.sNull(null);    = ""
	 * StringUtil.sNull("");      = ""
	 * StringUtil.sNull("aa");    = "aa"
	 * 
	 * true
	 * StringUtil.sNull(" ");     = ""
	 * StringUtil.sNull("  aa "); = "aa"
	 * 
	 * false
	 * StringUtil.sNull(" ");     = " "
	 * StringUtil.sNull("  aa "); = "  aa "
	 * 
	 * @param str 입력받은 문자열
	 * @param flag 입력받은 문자열의 공백 제거 여부 (true:좌우공백제거, false:원본 문자열)
	 * @return 
	 */
	public static String sNull(String str, boolean flag) {
		if(flag){
			if(str == null || str.trim().length() == 0){ return ""; }else{ return str.trim(); }
		}else{
			if(str == null || str.length() == 0){ return ""; }else{ return str; }
		}
	}
	
	/**
	 * 입력받은 문자열이 NULL 인 경우 빈값("")으로 치환 후 반환.
	 * - flag 값이 true 일 경우 좌우 공백제거 후 체크
	 *   빈값이 아닐 경우 입력받은 문자열의 좌우 공백을 제거하고 반환.
	 * 
	 * StringUtil.sNull(null);    = ""
	 * StringUtil.sNull("");      = ""
	 * StringUtil.sNull("aa");    = "aa"
	 * StringUtil.sNull(" ");     = ""
	 * StringUtil.sNull("  aa "); = "aa"
	 * 
	 * @param str 입력받은 문자열
	 * @return 
	 */
	public static String sNull(String str) {
		return sNull(str, true);
	}
	
	/**
	 * 입력받은 객체가 NULL 인 경우 빈값("")으로 치환 후 반환.
	 * - flag 값이 true 일 경우 좌우 공백제거 후 체크
	 *   빈값이 아닐 경우 입력받은 객체의 좌우 공백을 제거하고 반환.
	 * 
	 * StringUtil.sNull(null);    = ""
	 * StringUtil.sNull("");      = ""
	 * StringUtil.sNull("aa");    = "aa"
	 * StringUtil.sNull(" ");     = ""
	 * StringUtil.sNull("  aa "); = "aa"
	 * 
	 * @param obj 입력받은 객체
	 * @return 
	 */
	public static String sNull(Object obj) {
		if(obj != null){ return obj.toString().trim(); }else{ return ""; }
	}
	
	/**
	 * 입력받은 문자열이 NULL 이거나 빈값("")인 경우 원하는 문자열로 치환 후 반환.
	 * - flag 값이 true 일 경우 좌우 공백제거 후 체크
	 *   빈값이 아닐 경우 입력받은 문자열의 좌우 공백을 제거하고 반환.
	 * - flag 값이 false 일 경우 좌우 공백제거 없이 체크 
	 *   빈값이 아닐 경우 입력받은 문자열을 그대로 반환.
	 * 
	 * StringUtil.sNullConvert(null, convert, true/false); = convert
	 * StringUtil.sNullConvert("", convert, true/false);   = convert
	 * StringUtil.sNullConvert("aa", convert, true/false); = "aa"
	 * 
	 * true
	 * StringUtil.sNullConvert(" ", convert, true);        = convert
	 * StringUtil.sNullConvert("  aa ", convert, true);    = "aa"
	 * 
	 * false
	 * StringUtil.sNullConvert(" ", convert, false);       = " "
	 * StringUtil.sNullConvert("  aa ", convert, false);   = "  aa "
	 * 
	 * @param str 입력받은 문자열
	 * @param convert 치환될 문자열
	 * @param flag 입력받은 문자열의 공백 제거 여부 (true:공백제거, false:원본 문자열)
	 * @return 
	 */
	public static String sNullConvert(String str, String convert, boolean flag) {
		if(flag){
			if(str == null || "null".equals(str) || str.trim().length() == 0){ return convert; }else{ return str.trim(); }
		}else{
			if(str == null || "null".equals(str) || str.length() == 0){ return convert; }else{ return str; }
		}
	}
	
	/**
	 * 입력받은 문자열이 NULL 이거나 빈값("")인 경우 원하는 문자열("")로 치환 후 반환.
	 * - flag 값이 true 일 경우 좌우 공백제거 후 체크
	 *   빈값이 아닐 경우 입력받은 문자열의 좌우 공백을 제거하고 반환.
	 * 
	 * StringUtil.sNullConvert(null, convert, true/false); = convert("")
	 * StringUtil.sNullConvert("", convert, true/false);   = convert("")
	 * StringUtil.sNullConvert("aa", convert, true/false); = "aa"
	 * StringUtil.sNullConvert(" ", convert, true);        = convert("")
	 * StringUtil.sNullConvert("  aa ", convert, true);    = "aa"
	 * 
	 * @param str 입력받은 문자열
	 * @return 
	 */
	public static String sNullConvert(String str) {
		return sNullConvert(str, "", true);
	}
	
	/**
	 * 입력받은 문자열이 NULL 이거나 빈값("")인 경우 원하는 문자열로 치환 후 반환.
	 * - flag 값이 true 일 경우 좌우 공백제거 후 체크
	 *   빈값이 아닐 경우 입력받은 문자열의 좌우 공백을 제거하고 반환.
	 * 
	 * StringUtil.sNullConvert(null, convert, true/false); = convert
	 * StringUtil.sNullConvert("", convert, true/false);   = convert
	 * StringUtil.sNullConvert("aa", convert, true/false); = "aa"
	 * StringUtil.sNullConvert(" ", convert, true);        = convert
	 * StringUtil.sNullConvert("  aa ", convert, true);    = "aa"
	 * 
	 * @param str 입력받은 문자열
	 * @param convert 치환될 문자열
	 * @return 
	 */
	public static String sNullConvert(String str, String convert) {
		return sNullConvert(str, convert, true);
	}
	
	/**
	 * 입력받은 문자열이 NULL 이거나 빈값("")인 경우 0 으로 반환.
	 * 
	 * StringUtil.sNullConvertZero(null);    = 0
	 * StringUtil.sNullConvertZero("");      = 0
	 * StringUtil.sNullConvertZero("12");    = 12
	 * StringUtil.sNullConvertZero(" ");     = 0
	 * StringUtil.sNullConvertZero("  12 "); = 12
	 * 
	 * @param str 입력받은 문자열
	 * @return 
	 */
	public static int sNullConvertZero(String str) {
		if(str==null || str.equals("null") || "".equals(str.trim())){
			return 0;
		}else{
			return Integer.parseInt(str.trim());
		}
	}
	
	/**
	 * 입력받은 객체가 NULL 이거나 빈값("")인 경우 0 으로 반환.
	 * 
	 * StringUtil.sNullConvertZero(null);    = 0
	 * StringUtil.sNullConvertZero("");      = 0
	 * StringUtil.sNullConvertZero("12");    = 12
	 * StringUtil.sNullConvertZero(" ");     = 0
	 * StringUtil.sNullConvertZero("  12 "); = 12
	 * 
	 * @param obj
	 * @return 
	 */
	public static int sNullConvertZero(Object obj) {
		if(obj==null || obj.equals("null") || "".equals(obj.toString().trim())){
			return 0;
		}else{
			return Integer.parseInt(((String) obj).trim());
		}
	}
	
	/**
	 * 입력받은 객체가 NULL 이거나 빈값("")인 경우 원하는 문자열로 치환 후 반환.
	 * - 좌우 공백제거 후 체크
	 *   빈값이 아닐 경우 입력받은 객체의 좌우 공백을 제거하고 반환.
	 *   
	 * @param obj 입력받은 객체
	 * @param convert 치환될 문자열
	 * @return 
	 */
	public static String sNullConvert(Object obj, String convert) {
		
		if(obj != null && obj.getClass().getName().equals("java.math.BigDecimal")){
			if(obj != null && obj instanceof BigDecimal){
			  return obj.toString();
			}
		}
		
		if(obj == null || "null".equals(obj) || obj.toString().trim().length() == 0){ 
			return convert; 
		}else{
			return obj.toString().trim();
		}
	}
	
	/**
	 * 입력받은 문자열에서 원하는 위치의 문자열을 반환.
	 * 
	 * StringUtil.sSubstring("abcdefghijklm", 2, 10); = "cdefghij"
	 * 
	 * @param str 입력받은 문자열
	 * @param start 시작 위치
	 * @param end  끝나는 위치
	 * @return 
	 */
	public static String sSubstring(String str, int start, int end){
		if(str != null && str.length() >= end){
			return str.substring(start,end);
		}
		return str;
	}

	/**
	 * 입력받은 문자열에서 원하는 위치의 문자열을 반환.
	 * 
	 * StringUtil.sSubstring("abcdefghijklm", 10); = "cdefghij"
	 * 
	 * @param str 입력받은 문자열
	 * @param end 끝나는 위치
	 * @return 
	 */
	public static String sSubstring(String str, int end){
		return sSubstring(str, 0, end);
	}
	
	/**
	 * 입력받은 문자열을 지정한 크기 만큼 오른쪽 문자열을 반환.
	 * 
	 * StringUtil.sRight("1234567890" , 3) = "890"
	 * StringUtil.sRight("1234567890" , 5) = "67890"
	 * 
	 * @param  str 입력받는 문자열
	 * @param  size 자릿수
	 * @return 
	 */
	public static String sRight(String str, int size) {
		if(str != null && str.length() >= size){
			return str.substring(str.length() - size);
		}
		return str;
	}
	
	/**
	 * 입력받은 문자열을 지정한 크기 만큼 왼쪽 문자열을 반환.
	 * 
	 * StringUtil.sLeft("1234567890" , 3) = "123"
	 * StringUtil.sLeft("1234567890" , 5) = "12345"
	 *
	 * @param str 입력받는 문자열
	 * @param size 자릿수
	 * @return 
	 */
	public static String sLeft(String str, int size) {
		if(str != null && str.length() >= size){
			return str.substring(0, size);
		}
		return str;
	}
	
	/**
	 * 입력받은 문자열 좌측에 원하는 문자열을 채우고 반환.
	 *  
	 * StringUtil.sLpad("abc", 5, "^")       = "^^abc"
	 * StringUtil.sLpad(null, 5, "^")        = "^^^^^"
	 * 
	 * true
	 * StringUtil.sLpad("abcdefghi", 5, "^") = "abcde"
	 * 
	 * false
	 * StringUtil.sLpad("abcdefghi", 5, "^") = "abcdefghi"
	 * 
	 * @param str  문자열
	 * @param len  원하는 문자열 길이
	 * @param pad  채울 문자
	 * @param flag 문자열이 원하는 문자열 길이 보다  (같거나) 클 때 리턴 구분 false:원본 문자열, true:원하는 문자열 길이
	 * @return 
	 */
	public static String sLpad(String str, int len, String pad, boolean flag) {
		String result = str;
		if(str.length() < len){
			for(int i = (len - str.length()); i>0; i--){
				result = pad + result;
			}
		}else{
			if(flag){ result = str.substring(0, len); }
		}
		return result;
	}
	
	/**
	 * 입력받은 문자열 좌측에 원하는 문자열을 채우고 반환.
	 * - 입력받은 문자열이 원하는 문자열 보다 길 경우 원본 문자열 반환.
	 * 
	 * @param str
	 * @param len
	 * @param pad
	 * @return 
	 */
	public static String sLpad(String str, int len, String pad) {
		return sLpad(str, len, pad, false);
	}
	
	/**
	 * 입력받은 문자열 우측에 원하는 문자열을 채우고 반환.
	 * 
	 * StringUtil.sRpad("abc", 5, "^")       = "abc^^"
	 * StringUtil.sRpad(null, 5, "^")        = "^^^^^"
	 * 
	 * true
	 * StringUtil.sRpad("abcdefghi", 5, "^") = "abcde"
	 * 
	 * false
	 * StringUtil.sRpad("abcdefghi", 5, "^") = "abcdefghi"
	 * 
	 * @param str  문자열
	 * @param len  원하는 문자열 길이
	 * @param pad  채울 문자
	 * @param flag 문자열이 원하는 문자열 길이 보다  (같거나) 클 때 리턴 구분 false:원본 문자열, true:원하는 문자열 길이
	 * @return 
	 */
	public static String sRpad(String str, int len, String pad, boolean flag) {
		String result = str;
		if(str.length() < len){
			for(int i = (len - str.length()); i>0; i--){
				result = result + pad;
			}
		}else{
			if(flag){ result = str.substring(0, len); }
		}
		return result;
	}
	
	/**
	 * 입력받은 문자열 우측에 원하는 문자열을 채우고 반환.
	 * - 입력받은 문자열이 원하는 문자열 보다 길 경우 원본 문자열 반환.
	 * 
	 * @param str
	 * @param len
	 * @param pad
	 * @return 
	 */
	public static String sRpad(String str, int len, String pad) {
		return sRpad(str, len, pad, false);
	}
	
	/**
	 * 입력받은 문자열에 포함된 대상 문자(char)를 모두 제거하고 반환.
	 * - 입력받은 문자열이 null 인 경우 null 반환.
	 * 
	 * StringUtil.sRemove(null, '*')     = null
	 * StringUtil.sRemove("", '*')       = ""
	 * StringUtil.sRemove(" ", ' ')      = ""
	 * StringUtil.sRemove(" ", '*')      = " "
	 * StringUtil.sRemove("queued", 'u') = "qeed"
	 * StringUtil.sRemove("queued", 'z') = "queued"
	 * 
	 * @param  String str 입력받는 기준 문자열
	 * @param  char   remove 입력받는 문자열에서 제거할 대상 문자열
	 * @return 
	 */
	public static String sRemove(String str, char remove) {
		if(isEmpty(str) || str.indexOf(remove) == -1){
			return str;
		}
		char[] chars = str.toCharArray();
		int pos = 0;
		for(int i=0; i<chars.length; i++){
			if(chars[i] != remove){
				chars[pos++] = chars[i];
			}
		}
		return new String(chars, 0, pos);
	}

	/**
	 * 입력받은 문자열에서 search 의 시작(index) 위치를 반환.
	 * 입력받은 문자열이 null 인 경우 -1 을 반환.
	 * 
	 * StringUtil.indexOf(null, *)          = -1
	 * StringUtil.indexOf(*, null)          = -1
	 * StringUtil.indexOf("", "")           =  0
	 * StringUtil.indexOf("aabaabaa", "a")  =  0
	 * StringUtil.indexOf("aabaabaa", "b")  =  2
	 * StringUtil.indexOf("aabaabaa", "ab") =  1
	 * StringUtil.indexOf("aabaabaa", "")   =  0
	 * 
	 * @param  str 검색 문자열
	 * @param  search 검색 대상문자열
	 * @return
	 */
	public static int indexOf(String str, String search) {
		if(str==null || search==null){ return -1; }
		return str.indexOf(search);
	}
	
	/**
	 * 입력받은 문자열을 지정한 분리자에 의해 배열로 반환.
	 * 
	 * @param  str 원본 문자열
	 * @param  separator 분리자
	 * @return 
	 */
	public static String[] split(String str, String separator) throws NullPointerException {
		String[] rtnStr = {};
		if(str==null){
			return rtnStr;
		}
		return str.split(separator);
	}

	/**
	 * 입력받은 문자열을 소문자로 변환 후 반환.
	 * - 입력받은 문자열이 null 인 경우 null 반환.
	 * 
	 * StringUtil.lowerCase(null)  = null
	 * StringUtil.lowerCase("")    = ""
	 * StringUtil.lowerCase(" ")   = " "
	 * StringUtil.lowerCase("aBc") = "abc"
	 *
	 * @param  str 소문자로 변환되어야 할 문자열
	 * @return
	 */
	public static String lowerCase(String str) {
		if(str==null){return null;}
		return str.toLowerCase();
	}
	
	/**
	 * 입력받은 문자열을 대문자로 변환.
	 * - 입력받은 문자열이 null 인 경우 null 반환.
	 * 
	 * StringUtil.upperCase(null)  = null
	 * StringUtil.upperCase("")    = ""
	 * StringUtil.upperCase(" ")   = " "
	 * StringUtil.upperCase("aBc") = "ABC"
	 *
	 * @param  str 대문자로 변환되어야 할 문자열
	 * @return
	 */
	public static String upperCase(String str) {
		if(str==null){return null;}
		return str.toUpperCase();
	}
	
	/**
	 * 문자열을 다양한 문자셋(EUC-KR[KSC5601],UTF-8..)을 사용하여 인코딩하는 기능 역으로 디코딩하여 원래의 문자열을
	 * 복원하는 기능을 제공함 String temp = new String(문자열.getBytes("바꾸기전 인코딩"),"바꿀 인코딩");
	 * 
	 * String temp = new String(문자열.getBytes("8859_1"),"KSC5601");
	 * => UTF-8 에서 EUC-KR
	 * 
	 * @param  str	문자열
	 * @param  oldCharset 원본 Charset
	 * @param  newCharset 수정 Charset
	 * @return 인코딩 문자열
	 * @exception MyException - UnsupportedEncodingException
	 */
	public static String getEncoding(String str, String oldCharset, String newCharset) {
		String rtnStr = null;
		if(str == null){return null;}
		
		try{
			rtnStr = new String(str.getBytes(oldCharset), newCharset);
		}catch(UnsupportedEncodingException e){
			rtnStr = null;
		}
		return rtnStr;
	}
	
	/**
	 * HTML 태그의 기호를  특수문자로 치환 처리('<' -> '&lt;')
	 * 즉, 태그 코드가 들어간 문서를 표시할 때 태그에 손상 없이 보이기 위한 메서드.
	 * 
	 * @param  str
	 * @return HTML 태그를 치환한 문자열
	 */
	public static String sHtmlCnvrView(String str) {
		String rtnStr = "";
		try{
			StringBuffer sb = new StringBuffer();
	
			char buff;
			int len = str.length();
			
			for(int i=0; i<len; i++){
				buff = str.charAt(i);
				switch(buff){
					case '<':  sb.append("&lt;");   break;
					case '>':  sb.append("&gt;");   break;
					case '&':  sb.append("&amp;");  break;
//					case '"':  sb.append("&quot;"); break;
//					case ' ':  sb.append("&nbsp;"); break;
//					case 10:   sb.append("<br>");   break;
					default:   sb.append(buff);
				}
			}
			rtnStr = sb.toString();
		}catch(Exception e){
			if(logger.isDebugEnabled()){logger.info("{}",e);}
		}
		return rtnStr;
	}

	/**
	 * HTML 태그의 특수문자를 기호로 치환 처리('&lt;' -> '<')
	 * 
	 * @param  str
	 * @return HTML 특수문자를 치환한 문자열
	 */
	public static String sHtmlCnvr(String str) {
		String tmpStr = str;
		tmpStr = tmpStr.replaceAll("&lt;", "<");
		tmpStr = tmpStr.replaceAll("&gt;", ">");
		tmpStr = tmpStr.replaceAll("&amp;", "&");
		tmpStr = tmpStr.replaceAll("&nbsp;", " ");
		tmpStr = tmpStr.replaceAll("&apos;", "'");
		tmpStr = tmpStr.replaceAll("&quot;", "\"");
		return tmpStr;
	}
	
	/**
	 * 넘겨받은 문자열을 지정한 포맷으로 문자열을 리턴한다.
	 * 포맷보다 문자열이 길어지면 포맷만큼 리턴되고
	 * 포맷보다 문자열이 작아지면 문자열만큼 리턴된다.
	 * #은 문자열을 의미하며 #을 제외한 문자열은 구분자로 인식된다.
	 * 
	 * StringUtil.sFormat("1234567890",  "###-##-#####") = "123-56-67890"
	 * StringUtil.sFormat("12345678901", "###-##-#####") = "123-56-67890"
	 * StringUtil.sFormat("123456789",   "###-##-#####") = "123-56-6789"
	 *
	 * @param  str 입력받는 휴대전화번호
	 * @return 넘겨받은 문자열을 지정한 포맷으로 문자열을 리턴한다
	 */
	public static String sFormat(String str, String format) {
		StringBuffer sb = new StringBuffer();
		
		for(int i=0, j=0; i<format.length(); i++){
			char c = format.charAt(i);
			if(c == '#'){
				try{
					sb.append(str.charAt(j++));
				}catch(Exception e){
					//ignore
				}
			}else{
				sb.append(format.charAt(i));
			}
		}
		return sb.toString();
	}
	
	/**
	 * 이메일 입력값 체크 후 boolean 반환.
	 * 
	 * @since 2020. 11. 18. 
	 * @param sEmail
	 * @return 
	 */
	public static boolean emailPtrnChk(String sEmail){

		boolean resultChk = true;
		int nIndexOfAt = sEmail.indexOf("@");
		int nIndexOfDot = sEmail.indexOf(".");
		int nLength = sEmail.length();

		// "@" 이 하나도 없거나 맨 끝에 위치한  경우
		if(nIndexOfAt <= 0 || nIndexOfAt == nLength){
			resultChk = false;
		}

		// "." 이 하나도 없거나 맨 끝에 위치한 경우
		if(nIndexOfDot <= 0 || nIndexOfDot == nLength){
			resultChk = false;
		}

		// "@"이 두개 이상 존재하는 경우
		if(sEmail.indexOf("@", nIndexOfAt + 1) != -1){
			resultChk = false;
		}

		// ".@" 인 경우 또는 "@."인 경우
		if(nIndexOfAt > 0){
			if(".".equals(sEmail.substring(nIndexOfAt - 1, nIndexOfAt)) || ".".equals(sEmail.substring(nIndexOfAt + 1, nIndexOfAt + 2))){
				resultChk = false;
			}
		}

		// "@" 이후에 "."이 존재하지 않는 경우
		if(sEmail.indexOf(".", (nIndexOfAt + 2)) == -1){
			resultChk = false;
		}

		// "@" 이후에 ".."이 존재하는 경우
		if(sEmail.indexOf("..", (nIndexOfAt + 2)) != -1){
			resultChk = false;
		}

		// 공백문자가 존재하는 경우
		if(sEmail.indexOf(" ") != -1){
			resultChk = false;
		}

		return resultChk;
	}
	
	/**
	 * 문자열(String)을 카멜표기법으로 치환 후 반환.
	 * 
	 * StringUtils.camelString("ITEM_CODE", true)  = "ItemCode"
	 * StringUtils.camelString("ITEM_CODE", false) = "itemCode"
	 * 
	 * @param str 문자열
	 * @param firstCharacterUppercase 첫문자열을 대문자로 할지 여부
	 * @return 카멜표기법으로 표현환 문자열
	 */
	public static String camelString(String str, boolean firstCharacterUppercase) {
		if(str==null){return null;}

		if(str.indexOf("_") < 1){
			if(str.matches("^[A-Z0-9]*$")){
				return str.toLowerCase();
			}else{
				return str;
			}
		}
		
		StringBuffer sb = new StringBuffer();
		
		boolean nextUpperCase = false;
		for(int i = 0; i < str.length(); i++){
			char c = str.charAt(i);
			
			if(isWordSeparator(c)){
				if(sb.length() > 0){ nextUpperCase = true; }
			}else{
				if(nextUpperCase){
					sb.append(Character.toUpperCase(c));
					nextUpperCase = false;
				}else{
					sb.append(Character.toLowerCase(c));
				}
			}
		}
		
		if(firstCharacterUppercase){
			sb.setCharAt(0, Character.toUpperCase(sb.charAt(0)));
		}
		return sb.toString();
	}
	
	/**
	 * 문자(char)가 단어 구분자('_', '-', '@', '$', '#', ' ') 인지 체크 후 boolean 반환.
	 * 
	 * @param  (char) c 문자
	 * @return
	 */
	public static boolean isWordSeparator(char c) {
		char[] WORD_SEPARATORS = {'_', '-', '@', '$', '#', ' '};
		
		for(int i = 0; i < WORD_SEPARATORS.length; i++){
			if(WORD_SEPARATORS[i] == c){
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Byte 를 String 으로 변환.
	 * 
	 * @param data
	 * @return 
	 */
	public static String byteToHexString(byte[] data) {
		StringBuilder sb = new StringBuilder();
		for(byte b : data){
			sb.append(Integer.toString((b & 0xff) + 0x100, 16).substring(1));
		}
		return sb.toString();
	}

	/**
	 * 2자리의 HexString 을 Byte 배열로 변환.
	 * 
	 * @param str
	 * @return
	 */
	public static byte[] hexStringToByteArray(String str) {
		int len = str.length();
		byte[] data = new byte[len/2];

		for(int i = 0; i < len; i+=2){
			data[i/2] = (byte) ((Character.digit(str.charAt(i), 16) << 4) + Character.digit(str.charAt(i+1), 16));
		}

		return data;
	}
	
	/**
	 * JSON 에서 유니코드로 들어온 부분을 변경하여 반환.
	 * 
	 * @param  str
	 * @return
	 */
	public static String unicodeConvert(String str) {
		try{ 
			StringBuilder sb = new StringBuilder();
			char ch;
			int len = str.length();
			for(int i = 0; i < len; i++){
				ch = str.charAt(i);
				if(ch == '\\' && str.charAt(i+1) == 'u'){
					sb.append((char) Integer.parseInt(str.substring(i+2, i+6), 16));
					i+=5;
					continue;
				}
				sb.append(ch);
			}
			return sb.toString();			
		}catch(Exception e){ 
			e.printStackTrace();
			return "";
		}
	}	
	
	/**
	 * Exception printStackTrace -> toString.
	 * 
	 * @param e
	 * @return 
	 */
	public static String getPrintStackTrace(Exception e) {
		StringWriter errors = new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		return errors.toString();
	}
	
	/**
	 * 입력받은 문자열이 숫자인지 체크 후 boolean 반환.
	 * 
	 * @param str
	 * @return 
	 */
	public static boolean isValidNum(String str) {
        return str.matches("^[0-9]*$");
    }
	
	/**
	 * 입력받은 문자열이 영문인지 체크 후 boolean 반환.
	 * 
	 * @param str
	 * @return 
	 */
	public static boolean isValidEng(String str) {
        return str.matches("^[a-zA-Z]*$");
    }
	
	/**
	 * 입력받은 문자열이 숫자영문인지 체크 후 boolean 반환.
	 * 
	 * StringUtil.isValidNumEng("123") = true
	 * StringUtil.isValidNumEng("abc") = true
	 * StringUtil.isValidNumEng("123abc") = true
	 * StringUtil.isValidNumEng("abc123") = true
	 * 
	 * @param str
	 * @return 
	 */
	public static boolean isValidNumEng(String str) {
        return str.matches("^[0-9a-zA-Z]*$");
    }
	
	public static String encodeBase64(String sDecode) throws Exception {
		byte[] encrypted = sDecode.getBytes(StandardCharsets.UTF_8);
		return new String(Base64.encodeBase64(encrypted));
	}
	
	public static String decodeBase64(String sEncode) throws Exception {
		return new String(Base64.decodeBase64(sEncode));
	}

	public static boolean isFileDb(String sPath) {
		File file = new File(sPath);
		boolean isFile = file.exists();
		
		if(!isFile){
			logger.info(sPath + " File DB does not exist.");
			return false;
		}
		return true;
	}

	public static String getRandNumChar(int len) {
		int leftLimit = 90; // 97 == letter 'a', a <= 97 add number
		int rightLimit = 122; // letter 'z'

		Random random = new Random();
		StringBuilder buffer = new StringBuilder(len);

		for (int i = 0; i < len; i++) {
			int randomLimitedInt = leftLimit + (int)
					(random.nextFloat() * (rightLimit - leftLimit + 1));
			if ( randomLimitedInt <= 96 || i < 2) {
				int r = new Random().nextInt(9);
				buffer.append(r);
			} else {
				buffer.append((char) randomLimitedInt);
			}
		}
		String generatedString = buffer.toString();

		return generatedString;
	}
	
	
	public static String getRandString(int len ) {
		int leftLimit = 97; // letter 'a'
		int rightLimit = 122; // letter 'z'

		Random random = new Random();
		StringBuilder buffer = new StringBuilder(len);
		
		for (int i = 0; i < len; i++) {
		    int randomLimitedInt = leftLimit + (int)
		            (random.nextFloat() * (rightLimit - leftLimit + 1));
		    buffer.append((char) randomLimitedInt);
		}
		String generatedString = buffer.toString();
		
		return generatedString;
	}

	public static String generateRandomPassword(int len) {
		final String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

		SecureRandom random = new SecureRandom();
		StringBuilder sb = new StringBuilder();

		for (int i = 0; i < len; i++)
		{
			int randomIndex = random.nextInt(chars.length());
			sb.append(chars.charAt(randomIndex));
		}

		return sb.toString();
	}
	
	public static String chkSeparator(String path) {
		if(!path.endsWith(File.separator)){
			path = path.concat(File.separator);
		}
		return path;
	}


	/**
	 * Desc : 엑셀대량다운로드용 파싱
	 * @Method Name : sGetParamParse
	 * @param cmapInput
	 * @param fileNm
	 * @param sQueryId
	 * @return
	 */
	public static DataMap sGetParamParse(DataMap cmapInput, String fileNm, String sQueryId)
	{
		String colId = (String)cmapInput.get("colId");
		String colName = (String)cmapInput.get("colName");

		String[] sTitle = split(colName, "\\|");
		int colIdsArrayLen = sTitle.length;

		String[] sTitleField = split(colId, "\\|");

		String[] sStyleType = new String[colIdsArrayLen];

		for(int i=0;i<colIdsArrayLen;i++){
			sStyleType[i] = "normal";
		}

		DataMap commMap = new DataMap();

		commMap.put("sTitle", sTitle);  //엑셀 타이틀
		commMap.put("sTitleField", sTitleField);  //쿼리 컬럼명
		commMap.put("sStyleType", sStyleType);  //셀스타일
		commMap.put("fileNm", fileNm + "_" + DateUtil.getToday("yyyyMMddHHmmss") + ".xlsx");  //파일명
		commMap.put("sheetNm", fileNm);  //시트명
		commMap.put("sQueryId", sQueryId);  //호출쿼리아이디
		commMap.put("param", cmapInput);

		return commMap;
	}

	/**
	 * <pre>
	 * 인자로 받은 String이 null일 경우 &quot;0&quot;로 리턴한다.
	 * &#064;param src null값일 가능성이 있는 String 값.
	 * &#064;return 만약 String이 null 값일 경우 &quot;0&quot;로 바꾼 String 값.
	 * </pre>
	 */
	public static int zeroConvert(Object src) {

		if (src == null || src.equals("null") || src.equals("")) {
			return 0;
		} else {
			return Integer.parseInt(((String) src).trim());
		}
	}

	//아이피가 ipv6으로 가져올수도 있으므로 VM argments에서 제일 마지막에 -Djava.net.preferIPv4Stack=true를 추가한다.
	public static String getClientIP(HttpServletRequest request) {
		String ip = request.getHeader("X-Forwarded-For");

		if (ip == null) {
			ip = request.getHeader("Proxy-Client-IP");
		}
		if (ip == null) {
			ip = request.getHeader("WL-Proxy-Client-IP");
		}
		if (ip == null) {
			ip = request.getHeader("HTTP_CLIENT_IP");
		}
		if (ip == null) {
			ip = request.getHeader("HTTP_X_FORWARDED_FOR");
		}
		if (ip == null) {
			ip = request.getRemoteAddr();
		}

		return ip;
	}

	public static String toProperCase ( String s, boolean isCapital) {
		String rtnValue = "";
		if ( isCapital) {
			rtnValue = s.substring(0,1).toUpperCase() + s.substring(1).toLowerCase();
		} else {
			rtnValue = s.toLowerCase();
		}
		return rtnValue;
	}

	public static String toCamelCase(String s ) {
		// s = s.toLowerCase();

		// Client 에서 전송된 데이터가 camelCase인 경우 Parameter 를 소문자로 변경하는 문제가 있어서
		// 추가함
		if ( s.contains("_") ) {
			s = s.toLowerCase();
		}
		if ( containsUpperCase(s) && containsLowerCase(s) ) {
			return s;
		} else {
			s = s.toLowerCase();
		}


		String[] parts = s.split("_");
		StringBuilder camelCaseString = new StringBuilder();

		for ( int idx = 0 ; idx < parts.length ; idx++ ) {
			String part = parts[idx];
			camelCaseString.append(toProperCase( part, (idx != 0) ) );
		}
		return camelCaseString.toString();
	}

	public static boolean containsLowerCase(String value ) {
		return contains(value, i->Character.isLetter(i) && Character.isLowerCase(i));
	}
	public static boolean containsUpperCase(String value ) {
		return contains(value, i->Character.isLetter(i) && Character.isUpperCase(i));
	}
	public static boolean containsNumber ( String value ) {
		return contains(value, Character::isDigit);
	}
	public static boolean contains(String value, IntPredicate predicate ) {
		return value.chars().anyMatch(predicate);
	}

}