/**
 *   
 */
package com.projectK.framework.util;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import net.sf.jxls.transformer.XLSTransformer;

/**
 * 액셀다운 관련 Common Util
 * 
 * <p> 
 * <수정이력> <br /> 
 * 1. 수정일: 수정자: 수정사유: <br />
 * <p>
 * @since 2021. 7. 1.
 * @version 1.0
 * @author   
 */
@Service
public class ExcelDownService {
	
	/**
	 * 엑셀다운로드 .
	 * - 샘플 엑셀 파일을 이용한 엑셀다운로드.
	 * - 자동 줄 맞춤, 파일명 한글 깨짐 현상 처리, 쿠키 이용을 통해 속도 향상.
	 * 
	 * @param  request
	 * @param  response
	 * @param  dbmap : print data
	 * @param  fileName : download file name
	 * @param  templateFile : template excel File
	 * @throws Exception 
	 */
	public void excelDownload(HttpServletRequest request, HttpServletResponse response, DataMap dbmap, String fileName, String templateFile) throws Exception{
		try{
			
			String excel_download_path = "/template/excel/"+templateFile;
			InputStream is = new ClassPathResource(excel_download_path).getInputStream();
			XLSTransformer xls = new XLSTransformer();
			Workbook workbook = xls.transformXLS(is, dbmap);
			
			Row row;
			Sheet sheet;
			
			for(int i=0; i< workbook.getNumberOfSheets(); i++){
				sheet =  workbook.getSheetAt(i);
				if(sheet == null) continue;
				for(int j=sheet.getFirstRowNum(); j <= sheet.getLastRowNum(); j++){
					row = sheet.getRow(j);
					if(row == null) continue;
					for(int k=row.getFirstCellNum(); k <=row.getLastCellNum(); k++){
						sheet.autoSizeColumn(k);
					}
				}
			}
			
			String header = request.getHeader("User-Agent");
			if(header.contains("MSIE") || header.contains("Trident")){
				fileName = URLEncoder.encode(fileName, StandardCharsets.UTF_8).replaceAll("\\+", "%20");
			}else{
				fileName = new String(fileName.getBytes(StandardCharsets.UTF_8), StandardCharsets.ISO_8859_1);
			}
			
			response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + ".xlsx\"");
			OutputStream os = response.getOutputStream();
			
			Cookie cookie = new Cookie("excelDownload", "complete");
			cookie.setPath("/");
			cookie.setMaxAge(24*60*60);
			response.addCookie(cookie);
			
			workbook.write(os);
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
}