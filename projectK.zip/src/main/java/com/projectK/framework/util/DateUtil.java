/**
 *   
 */
package com.projectK.framework.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 날짜 관련 Common Util
 * 
 * <p> 
 * <수정이력> <br /> 
 * 1. 수정일: 수정자: 수정사유: <br />
 * <p>
 * @since 2021. 7. 1.
 * @version 1.0
 * @author   
 */
public class DateUtil {
	private static final Logger logger = LoggerFactory.getLogger(DateUtil.class);
	
	/**
	 * 현재시간을 기준으로 년월일 등 날짜를 더하고 빼기.
	 * - default format : yyyyMMddHHmmss
	 * 
	 * DateUtil.addDate(1,  1, "") = 20211119175159 - 년
	 * DateUtil.addDate(2,  1, "") = 20201219175159 - 월
	 * DateUtil.addDate(5,  1, "") = 20201120175159 - 일
	 * DateUtil.addDate(11, 1, "") = 20201119185159 - 시
	 * DateUtil.addDate(12, 1, "") = 20201119175259 - 분
	 * DateUtil.addDate(13, 1, "") = 20201119175200 - 초
	 *  
	 * @param calendarType
	 * @param val
	 * @return 
	 */
	public static String addDate(int calendarType, int val) {
		return addDate(calendarType, val, "yyyyMMddHHmmss");
	}
	
	/**
	 * 현재시간을 기준으로 년월일 등 날짜를 더하고 빼기.
	 * - default format : yyyyMMddHHmmss
	 * 
	 * DateUtil.addDate(1,  1, "") = 20211119175159 - 년
	 * DateUtil.addDate(2,  1, "") = 20201219175159 - 월
	 * DateUtil.addDate(5,  1, "") = 20201120175159 - 일
	 * DateUtil.addDate(11, 1, "") = 20201119185159 - 시
	 * DateUtil.addDate(12, 1, "") = 20201119175259 - 분
	 * DateUtil.addDate(13, 1, "") = 20201119175200 - 초
	 * 
	 * DateUtil.addDate(5,  1, "yyyyMMddHHmmss") = 20201120175159
	 * DateUtil.addDate(5,  1, "yyyy-MM-dd HH:mm:ss") = 2020-11-20 17:51:59
	 * DateUtil.addDate(5,  1, "yyyy-MM-dd HH:mm:ss.SSS") = 2020-11-20 17:51:59.999
	 * 
	 * @param calendarType
	 * @param val
	 * @param fm
	 * @return 
	 */
	public static String addDate(int calendarType, int val, String fm) {
		return addDate(new Date(), calendarType, val, fm);
	}
	
	/**
	 * 입력받은 시간을 기준으로 년월일 등 날짜를 더하고 빼기.
	 * - default format : yyyyMMdd
	 * 
	 * DateUtil.addDate("20201119", 1,  1) = 20211119 - 년
	 * DateUtil.addDate("20201119", 2,  1) = 20201219 - 월
	 * DateUtil.addDate("20201119", 5,  1) = 20201120 - 일
	 * DateUtil.addDate("20201119", 11, 1) = 20201119 - 시
	 * DateUtil.addDate("20201119", 12, 1) = 20201119 - 분
	 * DateUtil.addDate("20201119", 13, 1) = 20201119 - 초
	 * 
	 * @param sDate
	 * @param calendarType
	 * @param val
	 * @param fm
	 * @return 
	 */
	public static String addDate(String sDate, int calendarType, int val) {
		return addDate(sDate, calendarType, val, "yyyyMMdd");
	}
	
	/**
	 * 입력받은 시간을 기준으로 년월일 등 날짜를 더하고 빼기.
	 * - default format : yyyyMMdd
	 * 
	 * DateUtil.addDate("20201119", 1,  1, "yyyyMMdd") = 20211119 - 년
	 * DateUtil.addDate("20201119", 2,  1, "yyyyMMdd") = 20201219 - 월
	 * DateUtil.addDate("20201119", 5,  1, "yyyyMMdd") = 20201120 - 일
	 * DateUtil.addDate("20201119", 11, 1, "yyyyMMdd") = 20201119 - 시
	 * DateUtil.addDate("20201119", 12, 1, "yyyyMMdd") = 20201119 - 분
	 * DateUtil.addDate("20201119", 13, 1, "yyyyMMdd") = 20201119 - 초
	 * 
	 * 입력시간과 포멧이 맞아야 함.
	 * DateUtil.addDate("20201119162555",  5, 1, "yyyyMMddHHmmss") = 20201120162555
	 * DateUtil.addDate("2020-11-19 16:25:55",  5, 1, "yyyy-MM-dd HH:mm:ss") = 2020-11-20 16:25:55
	 * DateUtil.addDate("2020-11-19 16:25:55.999",  5, 1, "yyyy-MM-dd HH:mm:ss.SSS") = 2020-11-20 16:25:55.999
	 * 
	 * @param sDate
	 *		yyyyMMddHHmmssSSS
	 *		format > date : 에러
	 *		format <= date : 성공
	 *		format 이 날짜 형식이 아닐 경우 : 에러
	 * @param calendarType
	 * @param val
	 * @param fm
	 * @return 
	 */
	public static String addDate(String sDate, int calendarType, int val, String fm) {
		if(StringUtil.isNull(fm)){ fm = "yyyyMMdd"; }
		
		SimpleDateFormat sdf = new SimpleDateFormat(fm); 
		sdf.setLenient(false);
		
		//if(sDate.length() < fm.length()){ return ""; }
		//if(sDate.length() != 8){ throw new IllegalArgumentException("Invalid date format: " + sDate + "|" + fm); }
		
		Date date = null;
		try{
			date = sdf.parse(sDate);
		}catch(ParseException e){
			//return "";
			throw new IllegalArgumentException("Invalid date format: " + sDate + "|" + fm);
		}
		
		return addDate(date, calendarType, val, fm);
	}
	
	/**
	 * 원하는 시간을 기준으로 년월일 등 날짜를 더하고 빼기.
	 * 
	 * Calendar Type
	 * YEAR=1, MONTH=2, DATE=5, HOUR=10, HOUR_OF_DAY=11, MINUTE=12, SECOND=13, MILLISECOND=14
	 * 
	 * WEEK_OF_YEAR=3, WEEK_OF_MONTH=4
	 * DAY_OF_MONTH=5, DAY_OF_YEAR=6, DAY_OF_WEEK=7, DAY_OF_WEEK_IN_MONTH=8 
	 * AM_PM=9, ZONE_OFFSET=15, DST_OFFSET=16, FIELD_COUNT=17 
	 * SUNDAY=1, MONDAY=2, TUESDAY=3, WEDNESDAY=4, THURSDAY=5, FRIDAY=6, SATURDAY=7
	 * 
	 * @param date 기준 날짜
	 * @param calendarType : 변경할 Calendar Type
	 * @param val 변경할 값
	 * @param fm 포멧
	 * @return 
	 */
	public static String addDate(Date date, int calendarType, int val, String fm) {
		String sRtn = null;
		if(StringUtil.isNull(fm)){ fm = "yyyyMMddHHmmss"; }
		
		SimpleDateFormat sdf = new SimpleDateFormat(fm); 
		sdf.setLenient(false);
		
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(calendarType, val);
		sRtn = sdf.format(cal.getTime());
		return sRtn;
	}
	
	/**
	 * DateUtil.addDate 사용 권장
	 * 날짜 형식의 문자열을 입력 받아 년, 월, 일을 증감한다.
	 * 년, 월, 일은 가감할 수를 의미하며, 음수를 입력할 경우 감한다.
	 * 
	 * 
	 * DateUtil.addYearMonthDay("19810828", 0, 0, 19)  = "19810916"
	 * DateUtil.addYearMonthDay("20060228", 0, 0, -10) = "20060218"
	 * DateUtil.addYearMonthDay("20060228", 0, 0, 10)  = "20060310"
	 * DateUtil.addYearMonthDay("20060228", 0, 0, 32)  = "20060401"
	 * DateUtil.addYearMonthDay("20050331", 0, -1, 0)  = "20050228"
	 * DateUtil.addYearMonthDay("20050301", 0, 2, 30)  = "20050531"
	 * DateUtil.addYearMonthDay("20050301", 1, 2, 30)  = "20060531"
	 * DateUtil.addYearMonthDay("20040301", 2, 0, 0)   = "20060301"
	 * DateUtil.addYearMonthDay("20040229", 2, 0, 0)   = "20060228"
	 * DateUtil.addYearMonthDay("20040229", 2, 0, 1)   = "20060301"
	 * 
	 * @param  sDate	날짜 문자열(yyyyMMdd, yyyy-MM-dd의 형식)
	 * @param  year	 가감할 년. 0이 입력될 경우 가감이 없다
	 * @param  month	가감할 월. 0이 입력될 경우 가감이 없다
	 * @param  day	  가감할 일. 0이 입력될 경우 가감이 없다
	 * @return yyyyMMdd 형식의 날짜 문자열
	 * @throws IllegalArgumentException 날짜 포맷이 정해진 바와 다를 경우. 입력 값이 null인 경우.
	 */
	public static String addYearMonthDay(String sDate, int year, int month, int day) {
		
		sDate = StringUtil.sRemove(sDate,'-');
		sDate = StringUtil.sRemove(sDate,'.');
		
		//if(sDate.length() != 8){ return ""; }
		if(sDate.length() != 8){ throw new IllegalArgumentException("Invalid date format: " + sDate); }
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd", Locale.getDefault());
		sdf.setLenient(false);
		
		Calendar cal = Calendar.getInstance();
		
		try{
			cal.setTime(sdf.parse(sDate));
		}catch (ParseException e){
			throw new IllegalArgumentException("Invalid date format: " + sDate);
		}
		
		if(year != 0) {cal.add(Calendar.YEAR, year);}
		if(month != 0){cal.add(Calendar.MONTH, month);}
		if(day != 0)  {cal.add(Calendar.DATE, day);}
		
		return sdf.format(cal.getTime());
	}
	
	/**
	 * 현재 날짜정보를 얻는다.
	 * 
  	 * DateUtil.getToday() = 20201120
	 *
	 * @return String yyyymmdd형태의 현재 한국시간.
	 */
	public static String getToday() {
		return getToday("yyyyMMdd");
	}
	
	/**
	 * 입력받은 포멧으로 현재 날짜시간 정보를 리턴한다.
	 * 
  	 * DateUtil.getToday("yyyyMMdd")            = 20201120 
  	 * DateUtil.getToday("yyyyMMddHHmm")        = 202011201137
  	 * DateUtil.getToday("yyyy-MM-dd HH:mm")    = 2020-11-20 11:37
  	 * DateUtil.getToday("yyyy-MM-dd HH:mm:ss") = 2020-11-20 11:37:18
  	 * DateUtil.getToday("HHmm")                = 1137
  	 * DateUtil.getToday("E")                   = 금
  	 * DateUtil.getToday("EEEE")                = 금요일
	 * 
	 * @param  sFormat 입력받는 포맷
	 * @return 넘겨받은 포맷으로 현재 날짜시간 정보를 문자열로 리턴한다
	 */
	public static String getToday(String sFormat) {
		return new SimpleDateFormat(sFormat).format(Calendar.getInstance().getTime());
	}
	
	/**
	 * 현재 해당하는 월의 마지막 날짜 정보를 리턴한다.
	 * 
	 * DateUtil.getTodayLastDay() = 20201123 > 31
	 * 
	 * @return 현재 해당하는 월의 마지막 날짜 정보를 문자열로 리턴한다
	 */
	public static String getTodayLastDay() {
		return Integer.toString(Calendar.getInstance().getMaximum(Calendar.DAY_OF_MONTH));
	}
	
	/**
	 * 입력받은 문자열의 타입 변경 String -> Date. 
	 * 
	 * DateUtil.getDate("20201022065432111") = Thu Oct 22 06:54:32 KST 2020
	 * 
	 * @param sDate
	 * @return 
	 */
	public static Date getDate(String sDate) {
		return getDate(sDate, "yyyyMMddHHmmssSSS");
	}
	
	/**
	 * 입력받은 문자열의 타입 변경 String -> Date. 
	 * 
	 * DateUtil.getDate("20201022065432111") = Thu Oct 22 06:54:32 KST 2020
	 * 
	 * @param sDate
	 * @param sFormat 입력문자열과 포멧은 동일한 형태여야 한다.
	 * @return 
	 */
	public static Date getDate(String sDate, String sFormat) {
		if(StringUtil.isNull(sFormat)){ sFormat = "yyyyMMddHHmmssSSS"; }
		
		SimpleDateFormat sdf = new SimpleDateFormat(sFormat);
		Date date;
		try{
			date = sdf.parse(sDate);
		}catch(ParseException e){
			date = null;
		}
		return date;
	}
	
	/**
	 * 입력받은 날짜를 Millisecond 시간으로 표시
	 * 
	 * DateUtil.getTime("2020-10-22 06:54:32","") = 1603317272000
	 * DateUtil.getTime("20201022065432","yyyyMMddHHmmss") = 1603317272000
	 * 
	 * @param sDate
	 * @return 
	 */
	public static long getTime(String sDate) {
		return getTime(sDate, "yyyy-MM-dd HH:mm:ss");
	}
	
	/**
	 * 입력받은 날짜를 Millisecond 시간으로 표시
	 * 
	 * DateUtil.getTime("2020-10-22 06:54:32","") = 1603317272000
	 * DateUtil.getTime("20201022065432","yyyyMMddHHmmss") = 1603317272000
	 * 
	 * @param sDate
	 * @param sFormat
	 * @return 
	 */
	public static long getTime(String sDate, String sFormat) {
		if(StringUtil.isNull(sFormat)){ sFormat = "yyyy-MM-dd HH:mm:ss"; }
		
		SimpleDateFormat sdf = new SimpleDateFormat(sFormat);
		Date date = null;
		try{
			date = sdf.parse(sDate);
		}catch(ParseException e){ }
		long ldate = date.getTime();
		return ldate;
	}
	
	/**
	 * 입력받은 날짜를 날짜형태의 String의 날짜 포맷만을 변경해 주는 메서드.
	 * 
	 * DateUtil.convertDate("20201123", "yyyy-MM-dd HH:mm:ss.SSS") = 2020-11-23 00:00:00.000
	 * 
	 * @param  sDate   날짜
	 * @param  sFormat 포멧 스트링 문자열
	 * @return 지정한 날짜/시간을 지정한 포맷으로 출력
	 */
	public static String convertDate(String sDate, String sFormat) {
		if(StringUtil.isNull(sFormat)){ sFormat = "yyyy-MM-dd HH:mm:ss"; }
		
		sDate = StringUtil.sRemove(sDate, '-');
		sDate = StringUtil.sRemove(sDate, '.');
		sDate = StringUtil.sRemove(sDate, ':');
		sDate = StringUtil.sRemove(sDate, ' ');
		sDate = sDate.trim();
		
		int len = sDate.length();
		if(!(len == 6 || len == 8 || len == 10 || len == 12 || len == 14 || len == 15 || len == 16 || len == 17)){
			return "";
		}
			
		if(sDate.length() ==  6){ sDate = sDate + "01000000000"; }
		if(sDate.length() ==  8){ sDate = sDate + "000000000"; }
		if(sDate.length() == 10){ sDate = sDate + "0000000"; }
		if(sDate.length() == 12){ sDate = sDate + "00000"; }
		if(sDate.length() == 14){ sDate = sDate + "000"; }
		
		Calendar cal = null;
		cal = Calendar.getInstance();
		
		cal.set(Calendar.YEAR, Integer.parseInt(sDate.substring(0, 4)));
		cal.set(Calendar.MONTH, Integer.parseInt(sDate.substring(4, 6)) - 1);
		cal.set(Calendar.DATE, Integer.parseInt(sDate.substring(6, 8)));
		cal.set(Calendar.HOUR_OF_DAY, Integer.parseInt(sDate.substring(8, 10)));
		cal.set(Calendar.MINUTE, Integer.parseInt(sDate.substring(10, 12)));
		cal.set(Calendar.SECOND, Integer.parseInt(sDate.substring(12, 14)));
		cal.set(Calendar.MILLISECOND, Integer.parseInt(sDate.substring(14, 17)));
		
		SimpleDateFormat sdf = new SimpleDateFormat(sFormat, Locale.getDefault());
		return sdf.format(cal.getTime());
	}

	/**
	 * 날짜형태의 String의 날짜 포맷 및 TimeZone을 변경해 주는 메서드
	 * 
	 * @param  sDate	 바꿀 날짜 String
	 * @param  oldFormat 기존의 날짜 형태
	 * @param  newFormat 원하는 날짜 형태
	 * @return 소스 String의 날짜 포맷을 변경한 String
	 */
	public static String convertDate(String sDate, String oldFormat, String newFormat) {
		return convertDate(sDate, oldFormat, newFormat, null);
	}
	
	/**
	 * 날짜형태의 String의 날짜 포맷 및 TimeZone을 변경해 주는 메서드
	 * 
	 * @param  sDate	 바꿀 날짜 String
	 * @param  oldFormat 기존의 날짜 형태
	 * @param  newFormat 원하는 날짜 형태
	 * @param  sTimeZone 표준시간
	 * @return 소스 String의 날짜 포맷을 변경한 String
	 */
	public static String convertDate(String sDate, String oldFormat, String newFormat, String sTimeZone) {
		SimpleDateFormat sdf = null;
		Date date = null;
		
		if(StringUtil.sNull(sDate).trim().equals("")){ return ""; }
		if(StringUtil.sNull(oldFormat).trim().equals("")){ oldFormat = "yyyyMMddHHmmss"; }
		if(StringUtil.sNull(newFormat).trim().equals("")){ newFormat = "yyyy-MM-dd HH:mm:ss"; }
		
		try{
			sdf = new SimpleDateFormat(oldFormat, Locale.getDefault());
			date = sdf.parse(sDate);
			
			if(!StringUtil.isNull(sTimeZone)){
				sdf.setTimeZone(TimeZone.getTimeZone(sTimeZone));
			}
			
			sdf = new SimpleDateFormat(newFormat, Locale.getDefault());
		}catch(ParseException exception){
			logger.info("{}", exception);
		}
		
		if(sdf != null && sdf.format(date) != null){
			return sdf.format(date);
		}else{
			return "";
		}
	}

	/**
	 * 입력받은 두 날짜 차이를 반환. 
	 * end - start
	 * 
	 * DateUtil.diffDate("20201122", "20201123") =  1
	 * DateUtil.diffDate("20201123", "20201123") =  0
	 * DateUtil.diffDate("20201124", "20201123") =  1
	 * 
	 * @param s
	 * @param e
	 * @param flag
	 * @return 
	 */
	public static int diffDate(String s, String e) {
		return diffDate(s, e, true);
	}
	
	/**
	 * 입력받은 두 날짜 차이를 반환. 
	 * end - start
	 * 
	 * DateUtil.diffDate("20201122", "20201123") =  1
	 * DateUtil.diffDate("20201123", "20201123") =  0
	 * DateUtil.diffDate("20201124", "20201123") = -1 : 만약 flag 값이 true 이면 1 리턴
	 * 
	 * @param s
	 * @param e
	 * @param flag
	 * @return 
	 */
	public static int diffDate(String s, String e, boolean flag) {
		int iCnt = 0;
		//String s = DateUtil.addYear(DateUtil.getToday(), -1);
		//String e = DateUtil.getToday();
		
		s = s.replaceAll("-", "");
		s = s.replaceAll("\\.", "");
		e = e.replaceAll("-", "");
		e = e.replaceAll("\\.", "");
		
		// String Type을 Date Type으로 캐스팅하면서 생기는 예외로 인해 여기서 예외처리 해주지 않으면 컴파일러에서 에러가 발생해서 컴파일을 할 수 없다.
		try{
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			// date1, date2 두 날짜를 parse()를 통해 Date형으로 변환.
			Date sdt = sdf.parse(s);
			Date edt = sdf.parse(e);
			
			// Date로 변환된 두 날짜를 계산한 뒤 그 리턴값으로 long type 변수를 초기화 하고 있다.
			// 연산결과 -950400000. long type 으로 return 된다.
			long calDate = edt.getTime() - sdt.getTime(); 
			
			// Date.getTime() 은 해당날짜를 기준으로1970년 00:00:00 부터 몇 초가 흘렀는지를 반환해준다. 
			// 이제 24*60*60*1000(각 시간값에 따른 차이점) 을 나눠주면 일수가 나온다.
			long calDateDays = calDate / ( 24*60*60*1000); 
			
			if(flag){ calDateDays = Math.abs(calDateDays); }
			
			iCnt = (int) calDateDays;
			
		}catch(ParseException e1){ }
		
		return iCnt;
	}

	/**
	 * 입력받은 두 날짜 차이를 반환. (초단위) 
	 * end - start
	 * 
	 * @param s
	 * @param e
	 * @param flag
	 * @return 
	 */
	public static int diffDateTime(String s, String e) {
		return diffDateTime(s, e, true);
	}
	
    /**
	 * 입력받은 두 날짜 차이를 반환. (초단위) 
	 * end - start
	 * 
	 * @param s
	 * @param e
	 * @param flag
	 * @return 
	 */
	public static int diffDateTime(String s, String e, boolean flag) {
		int iCnt = 0;
		
		s = s.replaceAll("-", "");
		s = s.replaceAll("\\.", "");
		s = s.replaceAll(" ", "");
		s = s.replaceAll(":", "");
		e = e.replaceAll("-", "");
		e = e.replaceAll("\\.", "");
		e = e.replaceAll(" ", "");
		e = e.replaceAll(":", "");
		
		// String Type을 Date Type으로 캐스팅하면서 생기는 예외로 인해 여기서 예외처리 해주지 않으면 컴파일러에서 에러가 발생해서 컴파일을 할 수 없다.
		try{
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
			// date1, date2 두 날짜를 parse()를 통해 Date형으로 변환.
			Date sdt = sdf.parse(s);
			Date edt = sdf.parse(e);

			// Date로 변환된 두 날짜를 계산한 뒤 그 리턴값으로 long type 변수를 초기화 하고 있다.
			// 연산결과 -950400000. long type 으로 return 된다.
			long calDate = edt.getTime() - sdt.getTime(); 

			// Date.getTime() 은 해당날짜를 기준으로1970년 00:00:00 부터 몇 초가 흘렀는지를 반환해준다. 
			// 이제 24*60*60*1000(각 시간값에 따른 차이점) 을 나눠주면 일수가 나온다.
			long calDateDays = calDate / (1000);

			if(flag){ calDateDays = Math.abs(calDateDays); }
			
			iCnt = (int) calDateDays;
			
		}catch(ParseException e1){ }
		
		return iCnt;
	}


	/**
	 * 현재날짜가 시작일자와 종료일자 사이에 있는지 확인
	 * end - start
	 *
	 * @param s
	 * @param e
	 * @param flag
	 * @return
	 */
	public static boolean compareDate(String startDt, String endDt) throws Exception {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

		Date currentTime = new Date();
		String today = format.format(currentTime);

		String st = "";

		Date startDate = format.parse(startDt);
		Date endDate = format.parse(endDt);

		Date toDate = format.parse(today);

		int compare1 = toDate.compareTo(startDate);
		int compare2 = endDate.compareTo(toDate);

		if(compare1 >= 0 && compare2 >=0) {
			return true;
		} else {
			return false;
		}
	}
	
}