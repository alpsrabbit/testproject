package com.projectK.framework.util;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.util.Iterator;
import java.util.UUID;

import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 * 
 * @ClassName   : PcFileUtil
 * @Description : 파일 업로드  Util 클래스
 * @author 윤재환
 * @since 2016. 8. 2.
 * @version 1.0
 * @see <pre>
 * == 개정이력(Modification Information) ==
 *
 *       수정일          수정자                 수정내용
 *  -----------    --------    -----------------------
 *   2016.  8.  2.    윤재환                 최초 생성
 *
 * </pre>
 */

@Service
public class CommFileUtil {
    
    public static final String PATH_IMG_THUMBNAIL = "thumb";
    public static final String PATH_IMG_ORIGINAL = "original";
    
    private static final Logger logger = LoggerFactory.getLogger(CommFileUtil.class);


    public static String getUploadPath( String sType ) {
        String sUploadPath = null;
        sUploadPath = PropertyFileUtil.getString("file.path.image");

        if ( !sUploadPath.endsWith(File.separator) ) {
            sUploadPath = sUploadPath.concat(File.separator);
        }
        sUploadPath = sUploadPath.concat(sType);

        if ( !sUploadPath.endsWith(File.separator) ) {
            sUploadPath = sUploadPath.concat(File.separator);
        }
        return sUploadPath;
    }

    public static void loadImage(HttpServletResponse response, String imgPath ) throws Exception {
        response.setContentType("image/jpg");
        ServletOutputStream bout = response.getOutputStream();

        String sUploadPath = null;
        sUploadPath = PropertyFileUtil.getString("file.path.image");
        if ( !sUploadPath.endsWith("/") ) {
            sUploadPath = sUploadPath.concat("/");
        }
        imgPath = sUploadPath.concat(imgPath);

        FileInputStream f = new FileInputStream(imgPath);
        int length;
        byte[] buffer = new byte[1024];

        while((length = f.read(buffer)) != -1 ) {
            bout.write(buffer,0,length);
        }
        f.close();
    }

    public static String base64LoadImage(HttpServletResponse response, String imgPath ) throws Exception {
        response.setContentType("image/jpg");
        ByteArrayOutputStream byteOutStream = null;

        String sUploadPath = null;
        sUploadPath = PropertyFileUtil.getString("file.path.image");
        if ( !sUploadPath.endsWith("/") ) {
            sUploadPath = sUploadPath.concat("/");
        }
        imgPath = sUploadPath.concat(imgPath);

        String strBase64 = "";
        File f = new File(imgPath);
        if (f.exists() && f.isFile() && f.length() > 0) {
            byte[] bt = new byte[(int) f.length()];
            FileInputStream fis = null;

            try {
                fis = new FileInputStream(f);
                fis.read(bt);
                strBase64 = new String(Base64.encodeBase64(bt));


            } catch (Exception e) {
                throw e;

            } finally {
                try {
                    if (fis != null) {
                        fis.close();
                    }
                } catch (IOException e) {
                } catch (Exception e) {
                }
            }
        }

        //strBase64 = "data:image/png;base64," + strBase64;

        return strBase64;
    }
    

    /**
     * 
     */
    public static boolean deleteFile(String filePath, String fileName) {
        logger.debug("CommFileUtil.deleteFile >>>> [{}][{}]", filePath, fileName);

        File file = null;

        if (fileName != null && !"".equals(fileName)) {

            logger.debug("fileName >>>> [{}]", fileName);

            file = new File(filePath + fileName);
            logger.debug("file is exists >>>> [{}]\nfile is file >>>> [{}]", file.exists(), file.isFile());

            if (!file.exists()) {
                return false;
            }

            if (!file.isFile()) {
                return false;
            }
        } else {
            logger.debug("file name is null or file name is blank");
            return false;
        }
        logger.debug("try to delete >>>> [{}]", file.getAbsolutePath());
        return file.delete();
    }

    /**
     * 파일 삭제.
     * @since 2010. 8. 9. 
     * @param sFile 
     */
    public static boolean deleteFile(String sFile){
        return new File(sFile).delete();
    }
    
    /**
     * 
     * @param filePath
     * @return
     */
    public static int getFileCount(String filePath) {
        if (logger.isInfoEnabled()) {
            logger.info("start file path: " + "/fsfile" + filePath);
        }
        
        File file = new File(filePath);
        if (!file.exists()) {
            //TODO 존재하지 않는 파일
            logger.error("존재하지 않는 경로");
            return -1;
        }
        
        if (!file.isDirectory()) {
            //TODO 디렉토리가 아님
            logger.error("디렉토리가 아님");
            return -1;
        }
        
        return file.list().length;
    }
    
    /**
     * 해당위치의 파일을 가지고 온다.
     */
    public static byte[] getFile(String filePath, String fileName) {
        if (logger.isInfoEnabled()) {
            logger.info("start file path: " + "/fsfile" + filePath + ", file name: " + fileName);
        }
        
        int readLength = 0;
        byte[] byteBuffer = new byte[1024];

        String fileFullPath = filePath;

        File file = new File("/fsfile" + fileFullPath + File.separator + fileName);
        if (!file.exists()) {
            //TODO error 처리
            logger.error("존재하지 않는 파일");
        }
        
        try {
            FileInputStream fis = new FileInputStream(file);
            ByteArrayOutputStream baos = new ByteArrayOutputStream(fis.available());
            try {
                while ((readLength = fis.read(byteBuffer)) != -1) {          
                    baos.write(byteBuffer, 0, readLength);
                }
                
                return baos.toByteArray();
            } finally {
                fis.close();
                baos.close();
            }
        } catch (Exception e) {
            //TODO error처리
            
            e.printStackTrace();
            return null;
        }
        
    }
    
    
    /**
     * 해당 위치에 파일 저장
     */
    public static void putFile(String fileFullPath, String fileName, byte[] byteArray, boolean isOverwrite) {
        if (logger.isInfoEnabled()) {
            logger.info("start file path: " + fileFullPath + ", file name: " + fileName);
        }

        int readLength = 0;
        byte[] byteBuffer = new byte[1024];

        FileOutputStream fos      = null;
        ByteArrayInputStream bais = null;
        try {
            File dir = new File (fileFullPath);
            
            if (isOverwrite && dir.isFile() && dir.exists()) {
                logger.info("isOverwrite && dir.isFile() && dir.exists()");
            }

            if (dir.isDirectory() ) {

            } else {
                if (!dir.mkdirs()) {
                    logger.error("폴더 생성에 실패하였습니다...");
                }
            }
            
            fos  = new FileOutputStream(fileFullPath + "/" + fileName);
            bais = new ByteArrayInputStream(byteArray);
            while ((readLength = bais.read(byteBuffer)) != -1) {
                fos.write(byteBuffer, 0, readLength);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally{
            if(bais !=null){
                try {
                    bais.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            
            if(fos !=null){
                try {
                    fos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * zip 압축파일을 풀어서  동일한 경로에 놓는다.
     */
    /*
    @SuppressWarnings("unchecked")
    public void putZipFile(String filePath,
                           String fileName,
                           byte[] byteArray,
                           boolean isOverwrite) {
        
        if (LOGGER.isInfoEnabled()) {
            LOGGER.info("start file path: " + filePath + ", file name: " + fileName);
        }

        String detailFileBaseDir = "";
        
        String fileFullPath = filePath;
        
        FileOutputStream      fos   = null;
        ByteArrayOutputStream baos  = null;
        ByteArrayInputStream  bais  = null;
        FileOutputStream      zeFos = null;
        try {
            new File (fileFullPath).mkdirs();
            fos = new FileOutputStream(fileFullPath + "/" + fileName);
            fos.write(byteArray);
            
            ZipFile zipFile = new ZipFile(fileFullPath + "/" + fileName, "utf-8");
            Enumeration<ZipEntry> zeEnum = (Enumeration<ZipEntry>) zipFile.getEntries();
            
            
            while (zeEnum.hasMoreElements()) {
                ZipEntry ze = zeEnum.nextElement();
                String zeName = ze.getName();
                zeName = zeName.replace("\\", "/");
               
                if (ze.isDirectory()) {
                    File zeDirectory = new File(fileFullPath + "/" + detailFileBaseDir + "/" + zeName);
                    zeDirectory.mkdirs();
                } else {
                    int pathIndex = zeName.lastIndexOf("/");
                    if (pathIndex > -1) {
                        String zePath = zeName.substring(0, pathIndex);
                    
                        File detailFileDirectory =
                            new File(fileFullPath +
                                    "/" +
                                     detailFileBaseDir +
                                     "/" +
                                     zePath);
                        detailFileDirectory.mkdirs();
                    }

                    InputStream is = zipFile.getInputStream(ze);
                    baos = new ByteArrayOutputStream();
                    
                    while ((readLength = is.read(byteBuffer)) != -1) {
                        baos.write(byteBuffer, 0, readLength);
                    }
                    is.close();
                    
                    byte[] byteData = baos.toByteArray();
                    baos.close();
                    
                    zeFos =
                        new FileOutputStream(fileFullPath +
                                detailFileBaseDir +
                                "/" +
                                zeName);
                    
                    bais       = new ByteArrayInputStream(byteData);
                    
                    while ((readLength = bais.read(byteBuffer)) != -1) {
                        zeFos.write(byteBuffer, 0, readLength);
                    }
                    zeFos.flush();
                    zeFos.close();
                }
            }
            
        } catch (Exception e) {
            //TODO error 처리
            e.printStackTrace();
        } finally {
            if(zeFos !=null){
                try {
                    zeFos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            
            if(bais !=null){
                try {
                    bais.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            
            if(baos !=null){
                try {
                    baos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            
            if(fos !=null){
                try {
                    fos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    */
    
    /**
     * 디렉토리가 존재하지 않으면 디렉토리 생성
     */
    public static void makeDirectory(String src) {
        File path = new File(src);

        if(!path.exists()) {
            path.mkdirs();
        }        
    }

    @SuppressWarnings("resource")
    public static void copyFile(File sourceFile, File destFile) throws IOException {
        long writedSize = 0;
        long sourceSize = sourceFile.length();
        if (!destFile.exists()) {
            destFile.createNewFile();
        }

        FileChannel source = null;
        FileChannel destination = null;
        try {
            source = new FileInputStream(sourceFile).getChannel();
            destination = new FileOutputStream(destFile).getChannel();
            while (writedSize < sourceSize) {
                writedSize += destination.transferFrom(source, writedSize, sourceSize - writedSize);
            }
        } finally {
            if (source != null) {
                source.close();
            }
            if (destination != null) {
                destination.close();
            }
        }
    }

    public static boolean isFileUsed(File file) {
        
        if(file == null) { return false; }
        
        if(file.isHidden()) {
            return false;
        }
        else if(!file.exists()) {
            return false;
        }
        else return file.canRead();

    }
    
    /**
     * Desc : ContentType이 이미지이면 true 아니면 false
     * @Method Name : isImage
     * @param ctntType
     * @return boolean
     */
    public static boolean isImage(String ctntType) {
        return "image/jpeg".equals(ctntType) || "image/jpg".equals(ctntType) || "image/png".equals(ctntType) || "image/gif".equals(ctntType) || "image/bmp".equals(ctntType) || "image/tiff".equals(ctntType);
    }
    
    /**
     * 엑셀 템프파일명
     * @since 2010. 9. 25. 
     * @param sUserId 로그인아이디
     * @param sUploadDir 상대경로
     * @return 
     */
    public static String getExcelTmp(String sUploadRoot) {
        // 파일업로드 기본 경로
        String sFilePath = sUploadRoot + "/" + DateUtil.getToday() + "/" + DateUtil.getToday("HH") + "/" + UUID.randomUUID().toString().replace("-", "") + "/";
        return sFilePath;
    }
    
    /**
     * 파일사이즈 구하기
     * @since 2010. 9. 25. 
     * @param sUserId 로그인아이디
     * @param sUploadDir 상대경로
     * @return 
     */
    public static long getFileSize(String sFilePath, String sFileNm) {

    	File oFile = null;
    	long lFileSize = 0;
    	
    	if(sFileNm != null && !"".equals(sFileNm)){
    		
    		int idx = sFileNm.indexOf(".");
            
            if(idx > -1){
            	sFileNm = sFileNm.substring(0, idx);
            }
    		
    		sFileNm = sFileNm.replaceAll("/", "");
    		sFileNm = sFileNm.replaceAll("\\\\", "");
    		sFileNm = sFileNm.replaceAll("[.]", "");
    		sFileNm = sFileNm.replaceAll("&", "");
    	
	    	if (!sFileNm.endsWith(".js") && !sFileNm.endsWith(".asp") && !sFileNm.endsWith(".jsp")) {
	    		
//	    		oFile = new File("/fsfile/kqta/tmp_excel/" + sFileNm + ".xlsx");
	    		oFile = new File(sFilePath + sFileNm + ".xlsx");
	    	}
	
	        if (oFile.exists()) {
	            lFileSize = oFile.length();
	        }
    	}
    	
        return lFileSize;
    }
    
    /**
     * Desc : 이미지 Read가능 여부
     * @Method Name : canReadExtension
     * @param fileExt
     * @return
     */
    public static boolean canReadExtension(String fileExt) {
        Iterator<ImageReader> iter = ImageIO.getImageReadersBySuffix(fileExt);
        return iter.hasNext();
    }
    
    /**
	 * 시스템시간 + 상대경로
	 * @since 2010. 9. 25. 
	 * @param sUserId 로그인아이디
	 * @return 
	 */
	public static String getTimeDir(String sUploadDir, String sUserId) {

		//시스템 날짜
		String getToday = DateUtil.getToday("yyyyMMdd");
		
//		String sFilePath = File.separator + getToday + sUploadDir;
		String sFilePath =  sUploadDir + "/" + getToday + "/" + sUserId + "/";
		
		return sFilePath;
	}
	
	/**
	 * 파일의 확장자 반환. 
	 * @since 2010. 5. 31.
	 * @param sFileNm
	 * @return String
	 */
	public static String getExt(String sFileNm) {
		String sExtType = "";
		int m;
		int iFileLength = sFileNm.length() - 1; 
		for (m=iFileLength;m>0;m--){
			char cNowChar = sFileNm.charAt(m);
			if (cNowChar=='.') break;
			sExtType = cNowChar + sExtType;
		}
		return sExtType;
	}
	
	public static byte[] imgFileReadByte(String strFIleNm) throws Exception {
		
		byte[] imageBytes = null;
		
		File file = new File(strFIleNm);
		
		if(file.exists()) {
			FileInputStream fis = new FileInputStream(file);

			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			
			byte[] buf = new byte[1024];
			
			try {
		       for (int readNum; (readNum = fis.read(buf)) != -1;) {
		           bos.write(buf, 0, readNum); 
		       }
			} catch (Exception ex) {
				logger.error("file read error");
				fis.close();
    			bos.close();
    			
    			return null;
			}
			
			imageBytes = bos.toByteArray();
			
			fis.close();
			bos.close();
		}
		
		return imageBytes;
	}
}