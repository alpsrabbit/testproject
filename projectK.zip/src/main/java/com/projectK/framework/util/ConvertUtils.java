/**
 *   
 */
package com.projectK.framework.util;

import java.nio.ByteBuffer;

/**
 * Convert 관련 Common Util
 *  
 * <p> 
 * <수정이력> <br /> 
 * 1. 수정일: 수정자: 수정사유: <br />
 * <p>
 * @since 2021. 7. 1.
 * @version 1.0
 * @author   
 */
public class ConvertUtils {
	private static final String PADDING_STRING = "0000000000000000";
	
	/**
	 * int -> byte, hex -> byte
	 * @param value : int 10진수 decimal int (-128~127)
	 */
	public static Byte toByte(String value, Byte defaultVal){
		try{
			if(value==null){return defaultVal;}
			if(value.startsWith("0x")){
				return Byte.parseByte(value.replaceAll(",", "").substring(2), 16);
			}else{
				return Byte.parseByte(value.replaceAll(",", ""));
			}
		}catch(Exception e){
			return defaultVal;
		}
	}
	
	/**
	 * int -> byte, hex -> byte
	 * @param value : int 10진수 decimal int (0~255)
	 */
	public static Byte toUByte(String value, Byte defaultVal){
		try{
			if(value==null){return defaultVal;}
			if(value.startsWith("0x")){
				return (byte) Integer.parseUnsignedInt(value.replaceAll(",", "").substring(2), 16);
			}else{
				return (byte) Integer.parseUnsignedInt(value.replaceAll(",", ""));
			}
		}catch(Exception e){
			return defaultVal;
		}
	}
	
	public static Short toShort(String value, Short defaultVal){
		try{
			if(value==null){return defaultVal;}
			if(value.startsWith("0x")){
				return Short.parseShort(value.replaceAll(",", "").substring(2), 16);
			}else{
				return Short.parseShort(value.replaceAll(",", ""));
			}
		}catch(Exception e){
			return defaultVal;
		}
	}

	public static Short toUShort(String value, Short defaultVal){
		try{
			if(value==null){return defaultVal;}
			if(value.startsWith("0x")){
				return (short) Integer.parseUnsignedInt(value.replaceAll(",", "").substring(2), 16);
			}else{
				return (short) Integer.parseUnsignedInt(value.replaceAll(",", ""));
			}
		}catch(Exception e){
			return defaultVal;
		}
	}

	public static Integer toInt(String value, Integer defaultVal){
		try{
			if(value==null){return defaultVal;}
			if(value.startsWith("0x")){
				return Integer.parseInt(value.replaceAll(",", "").substring(2), 16);
			}else{
				return Integer.parseInt(value.replaceAll(",", ""));
			}
		}catch(Exception e){
			return defaultVal;
		}
	}

	public static Integer toUInt(String value, Integer defaultVal){
		try{
			if(value==null){return defaultVal;}
			if(value.startsWith("0x")){
				return Integer.parseUnsignedInt(value.replaceAll(",", "").substring(2), 16);
			}else{
				return Integer.parseUnsignedInt(value.replaceAll(",", ""));
			}
		}catch(Exception e){
			return defaultVal;
		}
	}

	public static Long toLong(String value, Long defaultVal){
		try{
			if(value==null){return defaultVal;}
			if(value.startsWith("0x")){
				return Long.parseLong(value.replaceAll(",", "").substring(2), 16);
			}else{
				return Long.parseLong(value.replaceAll(",", ""));
			}
		}catch(Exception e){
			return defaultVal;
		}
	}

	public static Long toULong(String value, Long defaultVal){
		try{
			if(value==null){return defaultVal;}
			if(value.startsWith("0x")){
				return Long.parseUnsignedLong(value.replaceAll(",", "").substring(2), 16);
			}else{
				return Long.parseUnsignedLong(value.replaceAll(",", ""));
			}
		}catch(Exception e){
			return defaultVal;
		}
	}
	
	public static String toString(byte value){
		return Byte.toString(value);
	}

	public static String toString(short value){
		return Short.toString(value);
	}

	public static String toString(int value){
		return Integer.toString(value);
	}

	public static String toString(long value){
		return Long.toString(value);
	}

	public static String toUnsignedString(byte value){
		return Integer.toString(Byte.toUnsignedInt(value));
	}

	public static String toUnsignedString(short value){
		return Integer.toString(Short.toUnsignedInt(value));
	}

	public static String toUnsignedString(int value){
		return Integer.toUnsignedString(value);
	}

	public static String toUnsignedString(long value){
		return Long.toUnsignedString(value);
	}
	
	public static String toHexString(byte value){
		String str = Integer.toString(Byte.toUnsignedInt(value), 16);
		return "0x" + PADDING_STRING.substring(0, 2 - str.length()) + str.toUpperCase();
	}
	
	public static String toHexString(short value){
		String str = Integer.toString(Short.toUnsignedInt(value), 16);
		return "0x" + PADDING_STRING.substring(0, 4 - str.length()) + str.toUpperCase();
	}
	
	public static String toHexString(int value){
		String str = Integer.toHexString(value);
		return "0x" + PADDING_STRING.substring(0, 8 - str.length()) + str.toUpperCase();
	}

	public static String toHexString(long value){
		String str = Long.toHexString(value);
		return "0x" + PADDING_STRING.substring(0, 16 - str.length()) + str.toUpperCase();
	}
	
	public static String toHexStr(byte value){
		String str = Integer.toString(Byte.toUnsignedInt(value), 16);
		return PADDING_STRING.substring(0, 2 - str.length()) + str.toUpperCase();
	}
	
	public static String toHexStr(short value){
		String str = Integer.toString(Short.toUnsignedInt(value), 16);
		return PADDING_STRING.substring(0, 4 - str.length()) + str.toUpperCase();
	}
	
	public static String toHexStr(int value){
		String str = Integer.toHexString(value);
		return PADDING_STRING.substring(0, 8 - str.length()) + str.toUpperCase();
	}

	public static String toHexStr(long value){
		String str = Long.toHexString(value);
		return PADDING_STRING.substring(0, 16 - str.length()) + str.toUpperCase();
	}
	
	public static byte[] toBigIpAddr(String value) {
		byte[] bytes = new byte[4];
		try {
			String[] arr = value.split("\\.");
			if (arr.length != bytes.length) {
				return bytes;
			}

			for (int i = 0; i < arr.length; i++) {
				String str = arr[i];
				bytes[i] = toUByte(str.trim(), (byte) 0);
			}
		} catch (Exception e) {
		}
		return bytes;
	}
	
	public static String toBigIpAddrString(byte[] value) {
		if (value == null || value.length != 4) {
			return "0.0.0.0";
		}

		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < value.length; i++) {
			byte b = value[i];
			sb.append(toUnsignedString(b));
			if (i < value.length-1) {
				sb.append(".");
			}
		}
		return sb.toString();
	}
	
	public static String toBigIpAddrString(ByteBuffer value) {
		if (value == null) {
			return "0.0.0.0";
		}
		
		byte[] tmpBytes = new byte[4];
		tmpBytes[0] = value.get();
		tmpBytes[1] = value.get();
		tmpBytes[2] = value.get();
		tmpBytes[3] = value.get();

		return toBigIpAddrString(tmpBytes);
	}

	public static byte[] toLittleIpAddr(String value) {
		byte[] bytes = new byte[4];
		try {
			String[] arr = value.split("\\.");
			if (arr.length != bytes.length) {
				return bytes;
			}

			for (int i = 0; i < arr.length; i++) {
				String str = arr[i];
				bytes[arr.length - i - 1] = toUByte(str.trim(), (byte) 0);
			}
		} catch (Exception e) {
		}
		return bytes;
	}
	
	public static String toLittleIpAddrString(byte[] value) {
		if (value == null || value.length != 4) {
			return "0.0.0.0";
		}

		StringBuffer sb = new StringBuffer();
		for (int i = value.length; i > 0; i--) {
			byte b = value[i - 1];
			if (i < value.length) {
				sb.append(".");
			}
			sb.append(toUnsignedString(b));
		}
		return sb.toString();
	}
	
	public static String toLittleIpAddrString(ByteBuffer value) {
		if (value == null) {
			return "0.0.0.0";
		}
		
		byte[] tmpBytes = new byte[4];
		tmpBytes[0] = value.get();
		tmpBytes[1] = value.get();
		tmpBytes[2] = value.get();
		tmpBytes[3] = value.get();

		return toLittleIpAddrString(tmpBytes);
	}

	public static byte[] toMacAddr(String value) {
		byte[] bytes = new byte[6];
		try {
			String[] arr = value.split("-");
			if (arr.length != bytes.length) {
				return bytes;
			}

			for (int i = 0; i < arr.length; i++) {
				String str = arr[i];
				bytes[i] = toUByte("0x" + str.trim(), (byte) 0);
			}
		} catch (Exception e) {
		}
		return bytes;
	}

	public static String toMacAddrString(byte[] value) {
		if (value == null || value.length != 6) {
			return "00-00-00-00-00-00";
		}

		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < value.length; i++) {
			byte b = value[i];
			if (i > 0) {
				sb.append("-");
			}
			sb.append(toHexString(b).substring(2));
		}
		return sb.toString();
	}

	public static String toMacAddrString(ByteBuffer value) {
		if (value == null) {
			return "00-00-00-00-00-00";
		}

		byte[] tmpBytes = new byte[6];
		tmpBytes[0] = value.get();
		tmpBytes[1] = value.get();
		tmpBytes[2] = value.get();
		tmpBytes[3] = value.get();
		tmpBytes[4] = value.get();
		tmpBytes[5] = value.get();

		return toMacAddrString(tmpBytes);
	}
	
	public static byte[] toShortLittleEndian(short value) {
	    return new byte[]{
	        (byte) value,
	        (byte) (value >> 8)
	    };
	}
	
	public static byte[] toShortLittleEndian(int value) {
	    return new byte[]{
	        (byte) value,
	        (byte) (value >> 8)
	    };
	}
	
	public static byte[] toLittleEndian(int value) {
	    return new byte[]{
            (byte) value,
            (byte) (value >> 8),
            (byte) (value >> 16),
            (byte) (value >> 24)
	    };
	}

	public static String hexToAsc(String hexStr) {
	    StringBuilder output = new StringBuilder();
	    
	    for(int i = 0; i < hexStr.length(); i += 2){
	        String str = hexStr.substring(i, i + 2);
	        output.append((char) Integer.parseInt(str, 16));
	    }
	    return output.toString();
	}

	public static String ascToHex(String ascStr) {
	    StringBuilder hex = new StringBuilder();
	    
	    char[] chars = ascStr.toCharArray();
	    for(char ch : chars){
	        hex.append(Integer.toHexString(ch));
	    }
	    return hex.toString();
	}
	
	public static byte bccByte(byte[] bytes, int start, int end){
		int idx=0;
		byte xorBcc = bytes[start]; 
		for(byte v : bytes){
			int a = v & 0xff;
			if(start<idx && idx<end){
		   		xorBcc ^= (byte) a; 
		   	}
	   		idx++;
		}
		return xorBcc;
	}
	
	public static void main(String[] args) {
		byte[] ips1 = toLittleIpAddr("192.168.219.111");
		System.out.println(toLittleIpAddrString(ips1));
		byte[] ips2 = toBigIpAddr("192.168.219.111");
		System.out.println(toBigIpAddrString(ips2));
	}
}
