/**
 *   
 */
package com.projectK.framework.util;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 * Parse 관련 함수를 정의한 Common Util
 * 
 * <p> 
 * <수정이력> <br /> 
 * 1. 수정일: 수정자: 수정사유: <br />
 * <p>
 * @since 2021. 7. 1.
 * @version 1.0
 * @author   
 */
public class ParseUtil {
	
	/**
	 * String -> org.json.simple.JSONObject
	 */
	public static JSONObject parse(String sJSON) throws ParseException {
		JSONParser parser = new JSONParser();
		JSONObject jObj = (JSONObject) parser.parse(sJSON);
		return jObj;
	}
	
	/**
	 * DataMap -> org.json.simple.JSONObject
	 */
	@SuppressWarnings("unchecked")
	public static JSONObject getJSON(DataMap dataMap) {
		JSONObject jObj = new JSONObject();
		
		for(Object key : dataMap.keyList()){
			Object obj = dataMap.get(key.toString());
			
			if(obj.getClass().getSimpleName().contentEquals("DataMap")){
			}else if(obj.getClass().getSimpleName().contentEquals("ArrayList")){
			}else{
				jObj.put(key.toString(), obj.toString());
			}
		}
		return jObj;
	}
	
	@SuppressWarnings("unchecked")
	public static JSONObject requestToJson(HttpServletRequest request) {
		JSONObject map = new JSONObject();
		Enumeration<String> paramKeys =  request.getParameterNames();
		String mapKey = "";
		
		while(paramKeys.hasMoreElements()){
			mapKey = paramKeys.nextElement();
			map.put(mapKey, request.getParameter(mapKey));
		}
		return map;
	}
	
	/**
	 * List<DataMap> -> org.json.simple.JSONArray
	 */
	@SuppressWarnings("unchecked")
	public static JSONArray getJSONArray(List<DataMap> list) {
		JSONArray jArray = new JSONArray();

		for(DataMap map : list){
			Iterator<String> iteratorData = map.keySet().iterator();
			JSONObject jObj = new JSONObject();
			while (iteratorData.hasNext()){
				String key = iteratorData.next();
				jObj.put(key, map.get(key));
			}
			jArray.add(jObj);
		}
		return jArray;
	}

	/**
	 * org.json.simple.JSONObject -> DataMap
	 */
	@SuppressWarnings("unchecked")
	public static DataMap getMapByJSONObject(JSONObject jObj) {
		DataMap dMap = new DataMap();
		Set<Map.Entry<String, Object>> set = jObj.entrySet();
		
		for(Map.Entry<String, Object> entry : set){
			String jsonKey = entry.getKey();
			dMap.put(jsonKey, jObj.get(jsonKey));
		}
		return dMap;
	}

	/**
	 * org.json.simple.JSONArray -> List<DataMap>
	 */
	public static List<DataMap> getMapListByJSONArray(JSONArray jArray){
		List<DataMap> list = new ArrayList<DataMap>();
		
		for(int intIdx = 0; intIdx < jArray.size(); intIdx++){
			JSONObject item = (JSONObject) jArray.get(intIdx);
			
			DataMap itemResult = getMapByJSONObject(item);
			list.add(itemResult);
		}
		return list;
	}
	
	/**
	 * DataMap -> net.sf.json.JSONObject
	 */
	public static net.sf.json.JSONObject getNsetSfJSON(DataMap dataMap) {
		net.sf.json.JSONObject retObj = new net.sf.json.JSONObject();
		
		for(Object key : dataMap.keyList()){
			Object obj = dataMap.get(key.toString());
			
			if(obj.getClass().getSimpleName().contentEquals("DataMap")){
			}else if(obj.getClass().getSimpleName().contentEquals("ArrayList")){
			}else{
				retObj.put(key.toString(), obj.toString());
			}
		}
		return retObj;
	}
	
	/**
	 * List<DataMap> -> net.sf.json.JSONArray
	 */
	@SuppressWarnings("unchecked")
	public static net.sf.json.JSONArray getNetSfJSONArray(List<DataMap> list) {
		net.sf.json.JSONArray jsonArrList = new net.sf.json.JSONArray();
		
		for(DataMap map : list){
			Iterator<String> iteratorData = map.keySet().iterator();
			net.sf.json.JSONObject jObj = new net.sf.json.JSONObject();
			while (iteratorData.hasNext()){
				String key = iteratorData.next();
				jObj.put(key, map.get(key));
			}
			jsonArrList.add(jObj);
		}
		return jsonArrList;
	}

	public static DataMap getResultMap(ResultSet rs) throws SQLException {
		if(rs == null){ return null; }
		
		DataMap map = new DataMap();

		ResultSetMetaData metaData = rs.getMetaData();
		int colCount = metaData.getColumnCount();
		
		while(rs.next()){
			for(int i=1; i<=colCount; i++){
				map.put(metaData.getColumnLabel(i), rs.getObject(i));
			}
			break;
		}
		return map;
	}
	
	public static List<DataMap> getResultList(ResultSet rs) throws SQLException {
		if(rs == null){ return null; }
		
		List<DataMap> list = new ArrayList<DataMap>();
		DataMap map = null;
		
		ResultSetMetaData metaData = rs.getMetaData();
		int colCount = metaData.getColumnCount();
		
		while(rs.next()){
			map = new DataMap();
			for(int i=1; i<=colCount; i++){
				map.put(metaData.getColumnName(i), rs.getObject(i));
			}
			list.add(map);
		}
/*
		String column;
		while(rs.next()){
			map = new DataMap();
			for(int i=1; i<=colCount; i++){
				column = metaData.getColumnName(i);
				map.put(column, rs.getObject(column));
			}
			list.add(map);
		}
*/
		return list;
	}
	
}