/**
 *   
 */
package com.projectK.framework.util;

import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.MessageSource;

/**
 * Message 및 Property 관련 Common Util
 * 
 * <p> 
 * <수정이력> <br /> 
 * 1. 수정일: 수정자: 수정사유: <br />
 * <p>
 * @since 2021. 7. 1.
 * @version 1.0
 * @author   
 */
public class MessageUtil {
	private static final Logger logger = LoggerFactory.getLogger(MessageUtil.class);
	
	private static final MessageSource messageSource = SpringUtil.getBean(MessageSource.class);
	
	public static String getString(String code, Locale locale) {
		return messageSource.getMessage(code, null, "", locale);
	}
	
	public static String getString(String code, Object[] objs, Locale locale) {
		return messageSource.getMessage(code, objs, "", locale);
	}
	
	public static String getString(String code, Object[] objs, String defaultMessage, Locale locale) {
		return messageSource.getMessage(code, objs, defaultMessage, locale);
	}
	
	public static String getString(String code) {
		String str=null;
		try{
			str=messageSource.getMessage(code, null, "", Locale.getDefault());
		}catch(IllegalStateException e){
			logger.error(e.getMessage());
		}
		if(str==null){str = "";}		
		return str;
	}
	
	public static int getInt(String code) {
		int str=0;
		try{
			str=Integer.parseInt(messageSource.getMessage(code, null, "0", Locale.getDefault()));
		}catch(IllegalStateException e){
			logger.error(e.getMessage());
		}
		return str;
	}
	
	public static long getLong(String code) {
		Long str=null;
		try{
			str=Long.parseLong(messageSource.getMessage(code, null, "0", Locale.getDefault()));
		}catch(IllegalStateException e){
			logger.error(e.getMessage());
		}
		if(str==null){str=Long.parseLong("0");}
		return str;
	}
	
	public static double getDouble(String code) {
		Double str=null;
		try{
			str=Double.parseDouble(messageSource.getMessage(code, null, "0", Locale.getDefault()));
		}catch(IllegalStateException e){
			logger.error(e.getMessage());
		}
		if(str==null){str=Double.parseDouble("0");}
		return str;
	}
	
	public static float getFloat(String code) {
		Float str=null;
		try{
			str=Float.parseFloat(messageSource.getMessage(code, null, "0", Locale.getDefault()));
		}catch(IllegalStateException e){
			logger.error(e.getMessage());
		}
		if(str==null){str=Float.parseFloat("0");}
		return str;
	}
	
}