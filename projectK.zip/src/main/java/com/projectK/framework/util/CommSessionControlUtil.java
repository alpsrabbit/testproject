package com.projectK.framework.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * 세션 컨트롤러 Util Class <br />
 * 세션 관련 함수를 정의한다. 
 * <p> 
 * <수정이력> <br /> 
 * 1. 수정일: 수정자: 수정사유: <br />
 * <p>
 * @since 2013. 8. 18.
 * @version 1.0
 * @author 김병찬
 */
public class CommSessionControlUtil {
	
	private static final Logger logger = LoggerFactory.getLogger(CommSessionControlUtil.class);
	
    /**
     * 세션 활성화 시간을 설정.
     * <pre>
     * SessionControlUtil.vSetSessionTime(session,60);  
     * </pre>       
     * @since 2010. 7. 5.
     * @param session HttpSession
     * @param time 세션타임
     * @throws Exception
     */
    public static void vSetSessionTime(HttpServletRequest request,int time) throws Exception{
    	HttpSession session = request.getSession(true);
    	session.setMaxInactiveInterval(time);
   }
    
    /**
     * 세션종료(비활성화) 설정.
     * @since 2010. 6. 3.
     * @param request 리퀘스트 
     * @throws Exception
     */
    public static void vSetSessionOut(HttpServletRequest request) throws Exception{
     	HttpSession httpSession = request.getSession(false);
    	if(httpSession != null ){
    		httpSession.invalidate();
    	}
    	
    }
    
    /**
     * 입력된 세션KEY에 대한 세션값을 설정.
     * @since 2010. 6. 3.
     * @param request 리퀘스트
     * @param sSessionKey 세션키
     * @param sSessionValue 세션값(입력된세션key)
     */
    public static void vSetSession(HttpServletRequest request,HttpServletResponse response, String sSessionKey,Object sSessionValue) throws Exception{
    	
    	HttpSession httpSession = request.getSession(false);

    	if(httpSession != null){
    		httpSession.setAttribute(sSessionKey, sSessionValue);
    	}
    	
    }
    
    /**
     * 입력된 세션KEY에 대한 세션값을 반환.
     * <pre>
     * String sReturn = SessionControlUtil.vGetSession(request,"member_id");  
	 * sReturn 결과 : "podo01" 
     * </pre>
     * @since 2010. 5. 12.
     * @param request
     * @param sSessionKey
     * @return null / 세션값(입력된세션key)
     * @throws Exception
     */
    public static String vGetSession(HttpServletRequest request,String sSessionKey) throws Exception{
    	
    	
    	HttpSession httpSession = request.getSession(false);
    	String sSessionValue = null;
    	
    	if(httpSession != null){
    		sSessionValue = (String)httpSession.getAttribute(sSessionKey);
    	}
    	
    	return sSessionValue;
    }
    
    /**
     * 세션 Timeout(활성화/비활성화) 체크.
     * <pre>
     * boolean sReturn =  SessionControlUtil.isSessionCheck(request);
	 * sReturn 결과 : true/false
     * </pre>  
     * @since 2010. 5. 12.
     * @param request
     * @return true(세션 활성화 경우)/false(세션 비활성화 경우)
     */
    public static boolean isSessionCheck(HttpServletRequest request) throws Exception{
    
    	//boolean isSessionCheck = request.isRequestedSessionIdValid();
    	boolean isSessionCheck = false;
    	
    	HttpSession httpSession = request.getSession(false);
    	
    	if(httpSession != null && httpSession.getAttribute("iuid") != null){
	    	isSessionCheck = true;
    	}
    	
    	return isSessionCheck;
    }
    
}

