package com.projectK.framework.util;

import java.io.File;
import java.io.InputStream;
import java.io.FileInputStream;


import com.projectK.framework.vo.FileDownloadInputVO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DirFileDownload extends FileDownload {
	private static final Logger logger = LoggerFactory.getLogger(DirFileDownload.class);

	public DirFileDownload() throws Exception {
		super();
		// TODO Auto-generated constructor stub
	}	
	
	public InputStream excuteFileDownload( DataMap fileInfo) throws Exception {
		InputStream is = null;
		
		try{
			
			//String filePath = fileDownLoadInputVO.getsFilePath();
			String filePath = fileInfo.getString("filePath");
			//String fileNm = fileDownLoadInputVO.getsRealFileNm();
			String fileNm = fileInfo.getString("fileName");
			
			
			logger.info("filePath : " + filePath);
			logger.info("fileNm : " + fileNm);
			String strFileFullPathName = filePath;
			if ( strFileFullPathName.endsWith(File.separator) ) {
				strFileFullPathName = strFileFullPathName.concat(fileNm);
			} else {
				strFileFullPathName = strFileFullPathName.concat(File.separator).concat(fileNm);
			}
			logger.info("fileDownLoadInputVO.getsFileFullNm() : " + strFileFullPathName);
			
			if(fileNm != null && !"".equals(fileNm)){
				
				int idx = fileNm.indexOf(".");
				
				if(idx > -1){
					fileNm = fileNm.substring(0, idx);
				}
				
				fileNm = fileNm.replaceAll("/", "");
				fileNm = fileNm.replaceAll("\\\\", "");
				fileNm = fileNm.replaceAll("[.]", "");
				fileNm = fileNm.replaceAll("&", "");
				
				File file = new File(strFileFullPathName);
				
				is = new FileInputStream(file);
			
			}
			
		} catch(Exception e){
			e.printStackTrace();
		} 
		
		return is;
	}

	public InputStream excuteFileDownload( FileDownloadInputVO fileInfo) throws Exception {
		InputStream is = null;

		try{

			String filePath = fileInfo.getsFilePath();
			//String filePath = fileInfo.getString("filePath");
			String fileNm = fileInfo.getsRealFileNm();
			//String fileNm = fileInfo.getString("fileName");


			logger.info("filePath : " + filePath);
			logger.info("fileNm : " + fileNm);
			String strFileFullPathName = filePath;
			if ( strFileFullPathName.endsWith(File.separator) ) {
				strFileFullPathName = strFileFullPathName.concat(fileNm);
			} else {
				strFileFullPathName = strFileFullPathName.concat(File.separator).concat(fileNm);
			}
			logger.info("fileDownLoadInputVO.getsFileFullNm() : " + strFileFullPathName);

			if(fileNm != null && !"".equals(fileNm)){

				int idx = fileNm.indexOf(".");

				if(idx > -1){
					fileNm = fileNm.substring(0, idx);
				}

				fileNm = fileNm.replaceAll("/", "");
				fileNm = fileNm.replaceAll("\\\\", "");
				fileNm = fileNm.replaceAll("[.]", "");
				fileNm = fileNm.replaceAll("&", "");

				File file = new File(strFileFullPathName);

				is = new FileInputStream(file);

			}

		} catch(Exception e){
			e.printStackTrace();
		}

		return is;
	}


}
