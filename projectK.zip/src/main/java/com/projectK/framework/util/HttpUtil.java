/**
 *   
 */
package com.projectK.framework.util;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.*;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Http 통신 관련 Common Util
 * 
 * <p> 
 * <수정이력> <br /> 
 * 1. 수정일: 수정자: 수정사유: <br />
 * <p>
 * @since 2021. 7. 1.
 * @version 1.0
 * @author   
 */
public class HttpUtil {
	private static final Logger logger = LoggerFactory.getLogger(HttpUtil.class);
	
	public static final String HEADER_USER_AGENT = "User-Agent";
	public static final String HEADER_CONTENT_ENCODING = "Content-Encoding";
	public static final String HEADER_CONTENT_TYPE = "Content-Type";
	public static final String HEADER_ACCEPT_CHARSET = "Accept-Charset";
	public static final String HEADER_ACCEPT_LANGUAGE = "Accept-Language";

	public static final String HTTP_METHOD_GET = "GET";
	public static final String HTTP_METHOD_POST = "POST";
	public static final String HTTP_METHOD_PUT = "PUT";
	public static final String HTTP_METHOD_DELETE = "DELETE";
	
	public static final String BASE_ENCODING = "utf-8";
	
	private static final int HTTP_CONNECT_TIME_OUT = 5000;
	private static final int HTTP_READ_TIME_OUT = 5000;
	
	/**
	 * HTTP POST 통신.
	 * 
	 * @param urlString
	 * @param headerParams
	 * @param dataParams
	 * @return 
	 */
	@SuppressWarnings("rawtypes")
	public static String get(String urlString, Map headerParams, Map dataParams) {
		return get(urlString, headerParams, dataParams, HttpUtil.HTTP_METHOD_POST);
	}
	
	/**
	 * HTTP 통신.
	 * 
	 * @param urlString
	 * @param headerParams
	 * @param dataParams
	 * @param method
	 * @return 
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static String get(String urlString, Map headerParams, Map dataParams, String method) {
		String data = "";
		if(dataParams != null){
			Iterator<String> iteratorData = dataParams.keySet().iterator();
			while (iteratorData.hasNext()) {
				String key = iteratorData.next();
				data = data + key;
				data = data + "=";
//					data = data + (String)dataParams.get(key);
				data = data + dataParams.get(key);
				data = data + "&";
			}
		}
		data = data + "param=https";

		return get(urlString, headerParams, data, method);
	}
	
	/**
	 * HTTP 통신.
	 * 
	 * @param urlString
	 * @param headerParams
	 * @param dataParams
	 * @param method
	 * @return 
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static String get(String urlString, Map headerParams, String dataParams, String method) {

		if(logger.isTraceEnabled()){
			logger.trace("urlString : " + urlString);
			logger.trace("method : " + method);
			logger.trace("headerParams : " + headerParams);
			logger.trace("dataParams : " + dataParams);
		}

		StringBuffer sb = new StringBuffer();
		String strResult = null;

		HttpURLConnection http = null;
		BufferedReader bufferedReader = null;
		OutputStreamWriter osw = null;
		
		try{
			URL url;
			
			if(HTTP_METHOD_GET.equals(method)){
				url = new URL(urlString + "?" + dataParams);
			}else{
				url = new URL(urlString);
			}
			
			dataParams = dataParams + "param=https";
			dataParams = dataParams.replaceAll("\\&param=https", "");
			dataParams = dataParams.replaceAll("param=https", "");

//			if(url.getProtocol().toLowerCase().equals("https")){
//				trustAllHosts();
//				HttpsURLConnection https = (HttpsURLConnection) url.openConnection();
//				https.setHostnameVerifier(DO_NOT_VERIFY);
//				http = https;
//			}else{
//				http = (HttpURLConnection) url.openConnection();
//			}

			http = (HttpURLConnection) url.openConnection();
			http.setRequestMethod(method);
			http.setDoOutput(true);
			http.setConnectTimeout(HTTP_CONNECT_TIME_OUT);
			http.setReadTimeout(HTTP_READ_TIME_OUT);

			http.setRequestProperty("Cache-Control", "no-cache");
			http.setRequestProperty("Connection", "keep-alive");
			http.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
			
			if(headerParams != null){
				Iterator<String> iteratorHeader = headerParams.keySet().iterator();
				while(iteratorHeader.hasNext()){
					String key = iteratorHeader.next();
					http.setRequestProperty(key, (String)headerParams.get(key));
				}
			}
			
			OutputStreamWriter wr;
			if(HTTP_METHOD_POST.equals(method)){
				wr = new OutputStreamWriter(http.getOutputStream(), HttpUtil.BASE_ENCODING);
				if(!HTTP_METHOD_GET.equals(method)){
					wr.write(dataParams);
				}
				wr.flush();
			}
			
			String line;
			int responseCode = http.getResponseCode();
			
			// 정상 호출
			if(responseCode ==200){
				bufferedReader = new BufferedReader(new InputStreamReader(http.getInputStream(), HttpUtil.BASE_ENCODING));
			}else{
				bufferedReader = new BufferedReader(new InputStreamReader(http.getErrorStream(), HttpUtil.BASE_ENCODING));
			}

			while((line = bufferedReader.readLine()) != null){
				sb.append(line + "\n");
			}
			
			strResult = sb.toString();
			
		}catch(Exception e){
			//e.printStackTrace();
			strResult = null;
		}finally{
			if(osw != null){ try{ osw.close(); }catch(Exception ignore){ }} 
			if(bufferedReader != null){ try{ bufferedReader.close();  }catch(Exception ignore){ }}
			if(http  != null){ try{ http.disconnect();  }catch(Exception ignore){ }}
		}
		return strResult;
	}
	
	/**
	 * Json Data 전달 시 사용할 수 있음.
	 */
	public static String sendUrl(String sendUrl, String data) throws IllegalStateException{
		String inputLiene = null;
		StringBuffer outResult = new StringBuffer();
		HttpURLConnection conn = null;
		OutputStream os = null;
		BufferedReader br = null;
		try {
			URL url = new URL(sendUrl);
			conn = (HttpURLConnection) url.openConnection();
			conn.setDoOutput(true);
			conn.setRequestMethod(HTTP_METHOD_POST);
			conn.setRequestProperty("Content-Type", "application/json");
//			conn.setRequestProperty("Accept-Charset", "UTF-8");
			conn.setConnectTimeout(5000);
			conn.setReadTimeout(5000);
			
			os = conn.getOutputStream();
//			os.write(data.getBytes("URT-8"));
			os.write(data.getBytes());
			os.flush();
			
//			br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF=8"));
			br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			while((inputLiene = br.readLine()) != null) {
				outResult.append(inputLiene);
			}
			
		}catch(Exception e){
			logger.error("error : " + sendUrl);
        }finally{
            //if(os   != null){try{ os.close();         }catch(Exception ignore){}}
            //if(br   != null){try{ br.close();         }catch(Exception ignore){}}
            if(conn != null){try{ conn.disconnect();  }catch(Exception ignore){}}
        }
		return outResult.toString();
	}
	
	/**
	 * HTTP 통신.
	 * 
	 * @param uri
	 * @param parameters
	 * @return
	 * @throws Exception 
	 */
	public static DataMap RentHttp(String uri, Map<String, Object> param) throws Exception{

		// 결과 객체 정의
		DataMap dataMap = new DataMap();
		//HashMap<String, Object> dataMap = new HashMap<String, Object>();
		//Object obj = null; // parameter : Class<?> OutClass 추가

		try {
			
			//HttpHeaders headers = new HttpHeaders();
			//headers.setContentType(MediaType.APPLICATION_JSON);
			
			HttpHeaders headers = new HttpHeaders();
			Charset utf8 = StandardCharsets.UTF_8;
			MediaType mediaType = new MediaType("application", "json", utf8);
			headers.setContentType(mediaType);

			ObjectMapper om = new ObjectMapper();

			String JSONInput = om.writerWithDefaultPrettyPrinter().writeValueAsString(param);

			HttpEntity<String> httpEntity = new HttpEntity<String>(JSONInput, headers);

			RestTemplate restTemplate = new RestTemplate();
			try {
				((SimpleClientHttpRequestFactory)restTemplate.getRequestFactory()).setReadTimeout(1000*30);
				((SimpleClientHttpRequestFactory)restTemplate.getRequestFactory()).setConnectTimeout(1000*30);
			}catch(Exception e){
				//e.printStackTrace();
			}
			
			String jsonNode = restTemplate.postForObject(uri, httpEntity, String.class);

			dataMap = om.readValue(jsonNode, new TypeReference<DataMap>(){});

			//HashMap<String, Object> map = om.readValue(jsonNode, new TypeReference<HashMap<String, Object>>(){});
			//Object obj = om.readValue(jsonNode, OutClass);

			//JsonNode jsonNode = restTemplate.postForObject(uri, param, JsonNode.class);
			//String resultCd = jsonNode.get("ResultCode").textValue();
			//String resultMsg = jsonNode.get("ResultMsg").textValue();
			//dataMap.put("errorCode", resultCd);
			//dataMap.put("errorMsg", resultMsg);

		}catch(Exception e){
		   dataMap.put("errorCode", "999");
		   dataMap.put("errorMsg", "내부서버오류");
		   e.printStackTrace();
		}

		return dataMap;
	}

	/**
	 * HTTP 통신.
	 *
	 * @param uri
	 * @param parameters
	 * @return
	 * @throws Exception
	 */
	public static List<DataMap> RentHttpGet(String uri) throws Exception{

		// 결과 객체 정의
		DataMap dataMap = new DataMap();
		List<DataMap> dataList = new ArrayList<>();

		try {
			HttpHeaders headers = new HttpHeaders();
			Charset utf8 = StandardCharsets.UTF_8;
			MediaType mediaType = new MediaType("application", "json", utf8);
			headers.setContentType(mediaType);

			ObjectMapper om = new ObjectMapper();

			RestTemplate restTemplate = new RestTemplate();
			try {
				((SimpleClientHttpRequestFactory)restTemplate.getRequestFactory()).setReadTimeout(1000*30);
				((SimpleClientHttpRequestFactory)restTemplate.getRequestFactory()).setConnectTimeout(1000*30);
			}catch(Exception e){
				//e.printStackTrace();
			}

			//String jsonNode = restTemplate.postForObject(uri, httpEntity, String.class);
			String jsonNode = restTemplate.getForObject(uri, String.class);


			dataList = om.readValue(jsonNode, new TypeReference<List<DataMap>>(){});

		}catch(Exception e){
			dataMap.put("errorCode", "999");
			dataMap.put("errorMsg", "내부서버오류");
			e.printStackTrace();
		}

		return dataList;
	}

	/**
	 * 클라이언트 IP 구하기.
	 * 
	 * WAS 는 보통 2차 방화벽 안에 있고 Web Server 를 통해 client 에서 호출되거나 cluster로 구성되어 load balancer 에서 호출되는데 
	 * 이럴 경우에서 getRemoteAddr() 을 호출하면 웹서버나 load balancer의 IP 가 나옴
	 * 
	 * WebLogic 의 Web Server 연계 모듈인 Weblogic connector 는
	 * 위 헤더를 사용하지 않고 Proxy-Client-IP 나 WL-Proxy-Client-IP 를 사용하므로
	 * weblogic 에서 도는 application 작성시 수정이 필요함
	 * 
	 * [참고 사이트]
	 * http://lesstif.com/pages/viewpage.action?pageId=20775886
	 * 
	 * @param request
	 * @return 
	 */
	public static String getRemoteAddr(HttpServletRequest request) {
		
		String clientIp = request.getHeader("X-Forwarded-For");
		if(!isEmpty(clientIp)){return getFirstIp(clientIp);}

		clientIp = request.getHeader("Proxy-Client-IP");
		if(!isEmpty(clientIp)){return getFirstIp(clientIp);}

		clientIp = request.getHeader("WL-Proxy-Client-IP");
		if(!isEmpty(clientIp)){return getFirstIp(clientIp);}

		clientIp = request.getHeader("HTTP_CLIENT_IP");
		if(!isEmpty(clientIp)){return getFirstIp(clientIp);}

		clientIp = request.getHeader("HTTP_X_FORWARDED_FOR");
		if(!isEmpty(clientIp)){return getFirstIp(clientIp);}
		
		return request.getRemoteAddr();
	}
	
	private static boolean isEmpty(String str) {
        return str == null || str.length() == 0 || "unknown".equalsIgnoreCase(str);
    }
	
	private static String getFirstIp(String ip) {
		if(ip==null){return null;}
		
		String[] split = ip.split(",");
		return split[0];
	}
	
	/**
	 * 헤더 정보 구하기.
	 * 
	 * @param request
	 * @param targetHeaderName
	 * @return 
	 */
	@SuppressWarnings("rawtypes")
	public static String getHeaderValue(HttpServletRequest request, String targetHeaderName) {
		if(targetHeaderName==null){return null;}
	  
		Enumeration enumeration = request.getHeaderNames();
		while(enumeration.hasMoreElements()){
			String headerName = (String) enumeration.nextElement();
			if(targetHeaderName.equalsIgnoreCase(headerName)){
				return request.getHeader(headerName);
			}
		}
		return null;
	}
	
}
