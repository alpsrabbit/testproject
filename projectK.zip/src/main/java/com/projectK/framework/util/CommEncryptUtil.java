package com.projectK.framework.util;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Base64.Encoder;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CommEncryptUtil {


    
    private static final Logger logger = LoggerFactory.getLogger(CommEncryptUtil.class);
    
    public static void main(String[] args) throws Exception {
    	String strPwd = "zhdlsvmfhwprxm1!";
    	String encPwd = sha256(strPwd);
    	logger.info("======" + encPwd);


    }
    
    public static String sha256(String msg)  throws NoSuchAlgorithmException {
    	MessageDigest md = MessageDigest.getInstance("SHA-256");
    	md.update(msg.getBytes());
    	return StringUtil.byteToHexString(md.digest());
    }
	
    public static String aesEncrypt(String plainText, String encKey, String encIv) throws Exception {
    	
    	byte[] key = StringUtil.hexStringToByteArray(encKey);
    	byte[] iv = StringUtil.hexStringToByteArray(encIv);
    	
    	SecretKeySpec skeySpec = new SecretKeySpec(key, "AES");
    	final Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
    	cipher.init(Cipher.ENCRYPT_MODE, skeySpec, new IvParameterSpec(iv));
    	byte[] encryptedText = cipher.doFinal(plainText.getBytes(StandardCharsets.UTF_8));
    	Encoder encoder = Base64.getEncoder();
    	return encoder.encodeToString(encryptedText);
    }
    
    public static String aesDecrypt(String encryptedText, String encKey, String encIv) throws Exception {
    	
    	byte[] key = StringUtil.hexStringToByteArray(encKey);
    	byte[] iv = StringUtil.hexStringToByteArray(encIv);
    	
    	SecretKeySpec skeySpec = new SecretKeySpec(key, "AES");
    	final Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
    	cipher.init(Cipher.DECRYPT_MODE, skeySpec, new IvParameterSpec(iv));
    	Decoder decoder = Base64.getDecoder();
    	byte[] plainText = cipher.doFinal(decoder.decode(encryptedText));
    	return new String(plainText, StandardCharsets.UTF_8);
    }
}
