package com.projectK.framework.util;

import org.apache.commons.codec.binary.Base32;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Date;
import java.util.Random;

public class OTPUtil {
    public static DataMap generate(String userName ) {
        DataMap dataMap = new DataMap();
        String hostName = PropertyFileUtil.getString("service.domain");
        byte[] buffer =new byte[5+5*5];
        new Random().nextBytes(buffer);

        Base32 codec = new Base32();

        byte[] secretKey = Arrays.copyOf(buffer,10);
        byte[] bEncodedKey = codec.encode(secretKey);

        String encodedKey = new String(bEncodedKey);
        String url = getQRBarcodeURL( userName, hostName, encodedKey);
        dataMap.put("encodedKey", encodedKey);
        dataMap.put("url", url);

        return dataMap;
    }

    public static String getGoogleOTPAuthURL(String secretKey, String userName, String hostName) {
        return "otpauth://totp/"
                + URLEncoder.encode(userName + ":" + hostName, StandardCharsets.UTF_8).replace("+", "%20")
                + "?secret=" + URLEncoder.encode(secretKey, StandardCharsets.UTF_8).replace("+", "%20");
    }

    public static String getQRBarcodeURL ( String userName, String hostName, String secret ) {
        return "https://www.google.com/chart?chs=400x400&chld=M|0&cht=qr&chl=".concat(getGoogleOTPAuthURL(secret, userName, hostName));
    }

    public static boolean checkCode(String userCode, String otpKey) {
        long otpNum = Integer.parseInt(userCode);
        long wave = new Date().getTime() / 30000;

        boolean result = false;
        try {
            Base32 codec = new Base32();
            byte[] decodedKey = codec.decode(otpKey);
            int window = 1; // 0 : 표시되는 순간만 유효함. window > 0 인 경우, 코드 재 사용 횟수. 2 인 경우 123 > 456 > 789 (789 인 상황에서 123, 456 도 유효함. )
            for ( int i = -window ; i <= 0 ; ++i ) {
//            for ( int i = -window ; i <= window ; ++i ) {
                long hash = verify_code(decodedKey, wave+i);
                if ( hash == otpNum ) result = true;
            }
        } catch (InvalidKeyException | NoSuchAlgorithmException e ) {
            e.printStackTrace();
        }
        return result;
    }
    private static int verify_code ( byte[] key, long t ) throws NoSuchAlgorithmException, InvalidKeyException {
        byte[] data = new byte[8];
        long value = t;
        for ( int i = 8 ; i-- > 0 ; value >>>= 8 ) {
            data[i] = (byte)value;
        }
        SecretKeySpec signKey = new SecretKeySpec(key, "HmacSHA1");
        Mac mac = Mac.getInstance("HmacSHA1");
        mac.init(signKey);
        byte[] hash = mac.doFinal(data);

        int offset = hash[20-1] & 0xF;

        long truncatedHash = 0;
        for ( int i = 0 ; i < 4 ; ++i ) {
            truncatedHash <<= 8;
            truncatedHash |= (hash[offset+i] &0xFF);
        }
        truncatedHash &= 0x7FFFFFFF;

        truncatedHash %= 1000000;
        return (int)truncatedHash;
    }
}
