/**
 *   
 */
package com.projectK.framework.util;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Session 관련 Common Util
 * 
 * <p> 
 * <수정이력> <br /> 
 * 1. 수정일: 수정자: 수정사유: <br />
 * <p>
 * @since 2021. 7. 1.
 * @version 1.0
 * @author   
 */
public class SessionUtil {
	private static final Logger logger = LoggerFactory.getLogger(SessionUtil.class);
	//public static final int MGR_SESSION_TIME_OUT = 60 * 60 * 24; // 세션 만료 시간 24 시간
	//public static final int MGR_SESSION_TIME_OUT = -1; // 세션 시간을 무제한으로 지정
	
	public static final int MGR_SESSION_TIME_OUT = 60 * 30; // 세션 만료 시간 30 분
	
	/**
	 * 세션 값 정의.
	 */
	public static void setSession(HttpSession session, DataMap dataMap) {
		session.setMaxInactiveInterval(SessionUtil.MGR_SESSION_TIME_OUT);
		session.setAttribute("suid", dataMap.get("suid"));
		session.setAttribute("iuid", dataMap.get("iuid"));
		session.setAttribute("name", dataMap.get("name"));
		session.setAttribute("levelFlag", dataMap.get("levelFlag"));
		session.setAttribute("last_login_datetime", dataMap.get("last_login_datetime"));
	}
	
	/**
	 * 입력된 세션 key에 대한 세션 값을 설정.
	 */
	public static void setSession(HttpSession session, String key, String value) throws Exception {
		if(session != null){
			session.setAttribute(key, value);
		}
	}
	
	/**
	 * 입력된 세션 key에 대한 세션 값을 설정.
	 */
	public static void setSession(HttpServletRequest request, String key, String value) throws Exception {
		HttpSession httpSession = request.getSession(false);
		if(httpSession != null){
			httpSession.setAttribute(key, value);
		}
	}
	
	/**
	 * 세션 값 반환.
	 */
	public static DataMap getSession(HttpSession session) {
		DataMap dataMap = new DataMap();

		String suid = (String)session.getAttribute("suid");

		if(session.getAttribute("suid") == null) {
			dataMap = null;
		} else {
			dataMap.put("mode", session.getAttribute("mode"));
			dataMap.put("suid", session.getAttribute("suid"));
			dataMap.put("iuid", session.getAttribute("iuid"));
			dataMap.put("name", session.getAttribute("name"));
			dataMap.put("levelFlag", session.getAttribute("levelFlag"));
			dataMap.put("last_login_datetime", session.getAttribute("lastLoginDatetime"));
		}

		return dataMap;
	}

	/**
	 * 세션 값 반환.
	 */
	public static DataMap getMemberSession(HttpSession session) {
		DataMap dataMap = new DataMap();
		dataMap.put("mode", session.getAttribute("mode"));
		dataMap.put("memberSuid", session.getAttribute("memberSuid"));
		dataMap.put("memberIuid", session.getAttribute("memberIuid"));
		dataMap.put("memberName", session.getAttribute("memberName"));
		dataMap.put("memberLevelFlag", session.getAttribute("memberLevelFlag"));
		dataMap.put("lastLoginDatetime", session.getAttribute("lastLoginDatetime"));
		return dataMap;
	}

	/**
	 * 세션 값 초기화.
	 */
	public static void initSession(HttpSession session) {
		try{
			session.removeAttribute("suid");
			session.removeAttribute("iuid");
			session.removeAttribute("name");
			session.removeAttribute("levelFlag");
			session.removeAttribute("last_login_datetime");
			session.invalidate();
		}catch(Exception e){
			logger.error("Session already invalidated.");
		}
	}
	
	/**
	 * 세션종료(비활성화) 설정.
	 */
	public static void initSessionOut(HttpServletRequest request) throws Exception {
	 	HttpSession httpSession = request.getSession(false);
		if(httpSession != null ){
			HttpSession session = request.getSession();
			session.removeAttribute("suid");
			session.removeAttribute("iuid");
			session.removeAttribute("name");
			session.removeAttribute("levelFlag");
			session.removeAttribute("last_login_datetime");
			httpSession.invalidate();
		}
	}
	
	/**
	 * 세션 필드 값 조회.
	 */
	public static String getString(HttpSession session, String key) {
		DataMap dataMap = getSession(session);
		if(dataMap == null){ return ""; }
		return dataMap.getString(key);
	}

	/**
	 * 세션 필드 값 조회.
	 */
	public static String getString(HttpServletRequest request, String key) throws Exception {
		HttpSession httpSession = request.getSession(false);
		if(httpSession != null){ return (String)httpSession.getAttribute(key); }
		return null;
	}
	
	/**
	 * 세션 활성화 시간을 설정.
	 */
	public static void setSessionTime(HttpSession session, int time) throws Exception {
		session.setMaxInactiveInterval(time);
	}
	
	/**
	 * 세션  체크.
	 */
	public static boolean isSessionCheck(HttpServletRequest request) throws Exception {
		//boolean isSessionCheck = request.isRequestedSessionIdValid();
		HttpSession session = request.getSession(false);
        return session != null && session.getAttribute("suid") != null && !"".equals(session.getAttribute("suid"));
    }
	
	/**
	 * 세션  체크.
	 */
	public static boolean isSessionCheck(HttpServletRequest request, HttpServletResponse response, boolean isApp) throws Exception {
		HttpSession session = request.getSession(false);
		if(session != null && session.getAttribute("suid") != null && !"".equals(session.getAttribute("suid"))){
			return true;
		}
		
		if(isApp){response.sendRedirect("/monitoring.do");}
		return false;
	}
	
}
