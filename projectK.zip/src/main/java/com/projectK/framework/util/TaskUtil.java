/**
 *   
 */
package com.projectK.framework.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

/**
 * 
 * <p> 
 * <수정이력> <br /> 
 * 1. 수정일: 수정자: 수정사유: <br />
 * <p>
 * @since 2021. 7. 1.
 * @version 1.0
 * @author   
 */
public class TaskUtil {

	public static JSONObject getResultParams(int errorCode) {
		return getResultParams("", errorCode);
	}
	
	@SuppressWarnings("unchecked")
	public static JSONObject getResultParams(String Command, int errorCode) {
		JSONObject params = new JSONObject();
		params.put("command", Command);
		params.put("errorCode", errorCode);
		return params;
	}
	
	public static String getParams(HttpServletRequest request, String sType) {
	    StringBuffer sb = new StringBuffer();
	    String line = null;
        BufferedReader reader;
		try{
			reader = request.getReader();
	        while((line = reader.readLine()) != null){
	        	sb.append(line);
	        }
		}catch(IOException e){
	        return "";
		}
        return sb.toString();
	}
	
	public static DataMap getParams(String sJsonObj, String sType) {
		
		DataMap dMap = new DataMap();
		dMap.put("errorCode", 0);
		try{
		    JSONObject jsonObjIn = null;
		    String sCommand = null;
		    JSONArray jsonArr = null;
		    List<DataMap> list = null;
		    
			if(sJsonObj == null || "".equals(sJsonObj)){ dMap.put("errorCode", -11); }
			
			if(dMap.getInt("errorCode") == 0){
				JSONParser parser = new JSONParser();
				jsonObjIn = (JSONObject) parser.parse(sJsonObj);
				if(jsonObjIn == null || "".equals(jsonObjIn)){ dMap.put("errorCode", -12); }
			}
			
			if(dMap.getInt("errorCode") == 0){
				sCommand = jsonObjIn.get("command").toString();
				if(sCommand == null || "".equals(sCommand)){ dMap.put("errorCode", -13); }
			}
			
			if(dMap.getInt("errorCode") == 0){
				dMap.put("command", sCommand);
				
				jsonArr = (JSONArray)jsonObjIn.get("data");
				if(jsonArr == null || jsonArr.size() == 0){ dMap.put("errorCode", -14); }
			}
			
			if(dMap.getInt("errorCode") == 0){
				list = ParseUtil.getMapListByJSONArray(jsonArr);
				if(list == null || list.size() == 0){ dMap.put("errorCode", -15); }
			}
			
			if(dMap.getInt("errorCode") == 0){
				dMap.put("type", sType);
				dMap.put("list", list);
			}
			
		}catch(Exception ignore){
			dMap.put("errorCode", -16); 
		}finally{}
		
		return dMap;
	}
	
}