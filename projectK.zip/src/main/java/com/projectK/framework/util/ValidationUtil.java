/**
 *   
 */
package com.projectK.framework.util;

import com.projectK.framework.vo.ResultVO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * Validation Common Util
 * 
 * <p> 
 * <수정이력> <br /> 
 * 1. 수정일: 수정자: 수정사유: <br />
 * <p>
 * @since 2021. 7. 1.
 * @version 1.0
 * @author   
 */
public class ValidationUtil {
	private static final Logger logger = LoggerFactory.getLogger(ValidationUtil.class);
	
	private static final String msgPrefix = "msg.error.";
	
	public static ResultVO validation(String[] strArr, String[] intArr, String[] posArr, DataMap dataMap) {
		return  ValidationUtil.validation(strArr, intArr, posArr, ".", 4, dataMap);
	}
	
	public static ResultVO validation(String[] strArr, String[] intArr, String[] posArr, String pos, int len, DataMap dataMap) {
		ResultVO result = new ResultVO(0,"정상 처리 되었습니다.");
		
		if(strArr != null && strArr.length > 0){
			result = validationStr(strArr, dataMap);
			if(result.getErrorCode() == -1){ return result; }
		}
		
		if(intArr != null && intArr.length > 0){
			result = validationInt(intArr, dataMap);
			if(result.getErrorCode() == -1){ return result; }
		}
		
		if(posArr != null && posArr.length > 0){
			result = validationPos(posArr, pos, len, dataMap);
			if(result.getErrorCode() == -1){ return result; }
		}
		
		return result;
	}

	public static ResultVO validationStr(String[] arr, DataMap dataMap) {
		ResultVO result = new ResultVO(0,"정상 처리 되었습니다.");
		
		try {
			String msg = "";
			String[] arrList = arr;
			
			for(String key : arrList) {
				if("".equals(dataMap.getString(key))){
					msg = MessageUtil.getString(msgPrefix+key);
					logger.info("key : " + key + " msg : " + msg);
					result = new ResultVO(-1, msg, key);
					break;
				}
			}
		}catch(Exception e){
			logger.error(StringUtil.getPrintStackTrace(e));
			result = new ResultVO(-1,MessageUtil.getString("msg.cmmn.9998"), "error : "  + e); // 오류가 발생했습니다.
		}
		return result;
	}
	
	public static ResultVO validationInt(String[] arr, DataMap dataMap) {
		ResultVO result = new ResultVO(0,"정상 처리 되었습니다.");
		
		try {
			String msg = "";
			String[] arrList = arr;
			
			for(String key : arrList) {
				if(dataMap.getInt(key) == 0){
					msg = MessageUtil.getString(msgPrefix+key);
					logger.info("key : " + key + " msg : " + msg);
					result = new ResultVO(-1, msg, key);
					break;
				}
			}
		}catch(Exception e){
			logger.error(StringUtil.getPrintStackTrace(e));
			result = new ResultVO(-1,MessageUtil.getString("msg.cmmn.9998"), "error : "  + e); // 오류가 발생했습니다.
		}
		return result;
	}
	
	/**
	 * key + "_pos"
	 */
	public static ResultVO validationPos(String[] arr, String pos, int len, DataMap dataMap) {
		ResultVO result = new ResultVO(0,"정상 처리 되었습니다.");
		
		try {
			String _pos = "_pos";
			String val = "";
			String msg = "";
			String[] arrList = arr;
			
			for(String key : arrList) {
				val = dataMap.getString(key);
				if(val.indexOf(pos) > -1) {
					if(val.substring(0, val.indexOf(pos)).length() > len){
						msg = MessageUtil.getString(msgPrefix+key+_pos);
						logger.info("key : " + key + " msg : " + msg);
						result = new ResultVO(-1, msg, key);
						break;
					}
				}else {
					if(val.length() > len){
						msg = MessageUtil.getString(msgPrefix+key+_pos);
						logger.info("key : " + key + " msg : " + msg);
						result = new ResultVO(-1, msg, key);
						break;
					}
				}
			}
		}catch(Exception e){
			logger.error(StringUtil.getPrintStackTrace(e));
			result = new ResultVO(-1,MessageUtil.getString("msg.cmmn.9998"), "error : "  + e); // 오류가 발생했습니다.
		}
		return result;
	}
	
	public static ResultVO validationPos(String key, String val, int pos) {
		ResultVO result = new ResultVO(0,"정상 처리 되었습니다.");
		
		try {
			String msg = "";
			if(val.substring(0, val.indexOf(".")).length() > pos){
				msg = MessageUtil.getString(msgPrefix+key);
				logger.info("key : " + key + " msg : " + msg);
				result = new ResultVO(-1, msg, key);
			}
		}catch(Exception e){
			logger.error(StringUtil.getPrintStackTrace(e));
			result = new ResultVO(-1,MessageUtil.getString("msg.cmmn.9998"), "error : "  + e); // 오류가 발생했습니다.
		}
		return result;
	}
	
}
