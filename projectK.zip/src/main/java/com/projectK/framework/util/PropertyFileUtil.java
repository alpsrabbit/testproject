/**
 *
 */
package com.projectK.framework.util;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Properties;

import com.projectK.framework.constant.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

/**
 * Message 및 Property 관련 Common Util
 *
 * <p>
 * <수정이력> <br />
 * 1. 수정일: 수정자: 수정사유: <br />
 * <p>
 * @since 2021. 7. 1.
 * @version 1.0
 * @author Coder2
 */
public class PropertyFileUtil {
	private static final Logger logger = LoggerFactory.getLogger(PropertyFileUtil.class);

	public static String getConfig(String propName){
		return getProperty(propName, "config");
	}

	public static String getProperty(String propName, String type){
		String filePath = "";
		if(type == null || "".equals(type) || "config".equals(type)){
			filePath = Constants.configFile;
		}else{
			filePath = type;
		}
		return getString(propName, filePath);
	}

	/**
	 * configFile  (./config/config.properties)  Property 로 조회
	 * messageFile (./config/message.properties) Property 로 조회
	 */
	public static Properties getProperties(String filePath){
		Properties prop = new Properties();

		try {
			Resource resource = new ClassPathResource(filePath);
			BufferedReader reader = new BufferedReader(new InputStreamReader(resource.getInputStream()));
			prop.load(reader);
		} catch ( Exception e ) {
			e.printStackTrace();
		}
		return prop;
	}

	public static String getString(String propName) {
		return getString(propName, Constants.configFile);
	}


	/**
	 * configFile  (./config/config.properties)  Property 로 조회
	 * messageFile (./config/message.properties) Property 로 조회
	 */
	public static String getString(String propName, String filePath){
		String result = null;
		logger.info("filePath :::: >>>> [{}]", filePath);

		//ClassPathResource res = new ClassPathResource(filePath);

		try {
			Properties properties = getProperties(filePath);

			if(properties != null){
				byte[] b = properties.getProperty(propName).getBytes(StandardCharsets.ISO_8859_1);
				result = new String(b, StandardCharsets.UTF_8);
			}
		} catch ( Exception e ) {
			e.printStackTrace();
		}
		return result; //properties.getProperty(propName);
	}

	/**
	 * configFile  (./config/config.properties)  Property 로 조회
	 * messageFile (./config/message.properties) Property 로 조회
	 */
	public static String getString(Properties properties, String propName){
		String result = null;
		if(properties != null){
			byte[] b = properties.getProperty(propName).getBytes(StandardCharsets.ISO_8859_1);
			result = new String(b, StandardCharsets.UTF_8);
		}
		return result; //properties.getProperty(propName);
	}

//	public static void main(String args[]) {
//		MessageUtil ini = new MessageUtil();
//		ini.fileWriter("");
//		ini.fileReader();
//		ini.setMessage("msg.5", "한글 테스트 입니다. aaa AAA 123"); //System.out.println(">>>>>>>>>>>>>"+ini.getMessage(key));
//	}

}