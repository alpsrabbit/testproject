/**
 *   
 */
package com.projectK.framework.util;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

/**
 * applicationContext 의 Bean 을 이용해서 비지니스 Interface 의 Transaction 을 사용할 수 있도록한다.
 * 
 * ex)
 * private static CommunicationService communicationService = SpringUtil.getBean(CommunicationService.class);
 * 
 * <p> 
 * <수정이력> <br /> 
 * 1. 수정일: 수정자: 수정사유: <br />
 * <p>
 * @since 2021. 7. 1.
 * @version 1.0
 * @author   
 */
@Component
public class SpringUtil implements ApplicationContextAware {
	private static ApplicationContext applicationContext;
	
	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		if(SpringUtil .applicationContext == null){
			SpringUtil .applicationContext = applicationContext;
		}
	}
	
	public static ApplicationContext getApplicationContext(){
		return applicationContext;
	}
	
	public static Object getBean(String beanName){
		return applicationContext.getBean(beanName);
	}
	
	public static <T> T getBean(Class<T> clazz){
		return applicationContext.getBean(clazz);
	}

}