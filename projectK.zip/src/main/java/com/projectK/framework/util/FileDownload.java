package com.projectK.framework.util;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.projectK.framework.vo.FileDownloadInputVO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class FileDownload {
	private static final Logger logger = LoggerFactory.getLogger(FileDownload.class);
	
	public void excutefileDownload(HttpServletRequest request, HttpServletResponse response, DataMap fileInfo) {
		OutputStream out = null;
		InputStream is = null;
		try {
			String filePath = fileInfo.getString("filePath");
			String fileNm = fileInfo.getString("fileName");
			
			logger.info("filePath : " + filePath);
			logger.info("fileNm : " + fileNm);
			
			String sRealFileNm = filePath;
			if ( sRealFileNm.endsWith(File.separator) ) {
				sRealFileNm = sRealFileNm.concat(fileNm);
			} else {
				sRealFileNm = sRealFileNm.concat(File.separator).concat(fileNm);
			}
			logger.info("fileDownloadInputVO.getsFileFullNm() : " + sRealFileNm);
			
			if(sRealFileNm == null || "".equals(sRealFileNm)){
				return;
			}
			File file = new File ( sRealFileNm);
			if ( !file.exists() ) {
				return;
			}
			
			long fileSize = file.length();
			
			String dwnlFileNm = fileNm;
			if(request.getHeader("User-Agent").contains("MSIE") || request.getHeader("User-Agent").contains("rv:11.0")) { 

				sRealFileNm = URLEncoder.encode(sRealFileNm, StandardCharsets.UTF_8);
				
				response.setContentType("application/vnd.ms-excel"); 
				
				dwnlFileNm = URLEncoder.encode(dwnlFileNm, StandardCharsets.UTF_8).replaceAll("\\+", "%20");
				logger.info("dwnlFileNm IE >>>> [{}]/[{}]", fileNm, dwnlFileNm);

				response.setHeader("Content-Disposition", "attachment;filename=\"" + dwnlFileNm + "\";"); 
				//response.setHeader("Content-Disposition", "attachment;filename=\"" + fileNm + "\";");
				
				response.setHeader("Content-Transfer-Encoding", "binary"); 
				response.setHeader("Content-Length", Long.toString(fileSize)); 
				response.setHeader("Connection", "close"); 
			} else { 
				dwnlFileNm = new String(dwnlFileNm.getBytes(StandardCharsets.UTF_8), StandardCharsets.ISO_8859_1);
				logger.info("dwnlFileNm NOT IE >>>> [{}][{}]",fileNm, dwnlFileNm);
				
				response.setContentType("application/octet-stream");
				
				response.setHeader("Content-Disposition", "attachment; filename=\"" + dwnlFileNm + "\";");
				//response.setHeader("Content-Disposition", "attachment; filename=\"" + fileNm + "\";");
				
				response.setHeader("Content-Transfer-Encoding", "binary");
				response.setHeader("Content-Length", Long.toString(fileSize)); 
				response.setHeader("Connection", "close"); 
			} 
			
			
			is = excuteFileDownload(fileInfo);
			
			byte[] b = new byte[1024]; // 파일 크기
			int read = 0;
		
			out = response.getOutputStream();
//			System.out.println("fileDownloadInputVO.getlFileSize()===>"+fileDownloadInputVO.getlFileSize());
			while((read=is.read(b)) != -1){
				out.write(b, 0, read);
			}
			
			out.flush();
			
		} catch (Exception e) {

			String sENm = e.getClass().getName();
			if(sENm.equals("org.apache.catalina.connector.ClientAbortException")){
				//System.out.println("사용자 다운로드 취소");
			}else{
				e.printStackTrace();
			}

		} finally{
			if (out != null) {
				try {
					out.close();
				} catch (IOException e) {
				e.printStackTrace();
				}
			}
			if (is != null) {
				try {
					is.close();
				} catch (IOException e) {
				e.printStackTrace();
				}
			}
		}
	}

	/**
	 * 파일다운로드
	 * @since 2010. 10. 1.
	 * @param request
	 * @param response
	 * @param fis 경로+파일명 스트림
	 * @param sRealFileNm 실제 파일명
	 * @param iFileLength 파일사이즈
	 */
	public void excutefileDownload(HttpServletRequest request, HttpServletResponse response, FileDownloadInputVO fileDownloadInputVO) {
		OutputStream out = null;
		InputStream is = null;
		try {
			String sRealFileNm = fileDownloadInputVO.getsRealFileNm();
			String fileNm = null;

			if(sRealFileNm == null || "".equals(sRealFileNm)){
				return;
			}

			if(request.getHeader("User-Agent").contains("MSIE") || request.getHeader("User-Agent").contains("rv:11.0")) {

				sRealFileNm = URLEncoder.encode(sRealFileNm, StandardCharsets.UTF_8);

				response.setContentType("application/vnd.ms-excel");
				response.setHeader("Content-Disposition", "attachment;filename=\"sRealFileNm\"".replace("sRealFileNm", sRealFileNm).replaceAll("\r", "").replaceAll("\n", "").replaceAll(" ","_"));
				response.setHeader("Content-Transfer-Encoding", "binary");
				response.setHeader("Content-Length", Long.toString(fileDownloadInputVO.getlFileSize()));
				response.setHeader("Connection", "close");
			} else {

				response.setContentType("application/octet-stream");
				response.setHeader("Content-Disposition", "attachment; filename=\"sRealFileNm\"".replace("sRealFileNm", new String(sRealFileNm.getBytes(StandardCharsets.UTF_8), StandardCharsets.ISO_8859_1).replaceAll("\r", "").replaceAll("\n", "").replaceAll(" ","_")));
				response.setHeader("Content-Transfer-Encoding", "binary");
				response.setHeader("Content-Length", Long.toString(fileDownloadInputVO.getlFileSize()));
				response.setHeader("Connection", "close");
			}


			is = excuteFileDownload(fileDownloadInputVO);

			byte[] b = new byte[1024]; // 파일 크기
			int read = 0;

			out = response.getOutputStream();
//			System.out.println("fileDownloadInputVO.getlFileSize()===>"+fileDownloadInputVO.getlFileSize());
			while((read=is.read(b)) != -1){
				out.write(b, 0, read);
			}

			out.flush();

		} catch (Exception e) {

			String sENm = e.getClass().getName();
			if(sENm.equals("org.apache.catalina.connector.ClientAbortException")){
				//System.out.println("사용자 다운로드 취소");
			}else{
				e.printStackTrace();
			}

		} finally{
			if (out != null) {
				try {
					out.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if (is != null) {
				try {
					is.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}


	public abstract InputStream excuteFileDownload(DataMap fileInfo) throws Exception;
	public abstract InputStream excuteFileDownload(FileDownloadInputVO fileInfo) throws Exception;

}
