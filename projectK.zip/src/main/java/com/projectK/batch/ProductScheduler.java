package com.projectK.batch;

import com.projectK.framework.constant.Constants;
import com.projectK.framework.util.DateUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

@SpringBootApplication
@EnableScheduling
public class ProductScheduler {
    private static final Logger logger = LoggerFactory.getLogger(ProductScheduler.class);

    /**
     * @throws Exception
     */
    @Scheduled(cron = "30 0/5 * * * ?")
    public void productMining() throws Exception {
        if ( Constants.SERVER_MODE_REAL.equalsIgnoreCase( Constants.serverMode ) ) {
            if (Constants.detailLog)logger.info("productScheduler productMining>>>>[{}]", DateUtil.getToday(Constants.DATETIME_MIN_FORMAT));
            //구현
        } else {

        }
    }

}
